from pathlib import Path
import json,subprocess
root=Path(__file__).resolve().parents[3];out=Path(__file__).parent
for row in ['m5','m6','l1','l2']:
 records=json.loads((out/(row+'-resume-run.json')).read_text())
 assert records[-1]['step']=='ctest' and records[-1]['exit']==0,row
report=root/'docs/stage_reports/stages/stage-07/diagnostic-formalization/2026-10-10-n3-verification-and-exit.md'
s=report.read_text(encoding='utf-8')
s=s.replace('状态：验收整理中；剩余平台硬门禁尚未全部返回，不宣告N3退出。','状态：N3独立退出；N1合同、N2迁移及全部本地硬门禁通过，冻结完整工作树快照，未提交/未发行。')
s=s.replace('| l2-resume-run；实际sanitizer，不用MSVC代替 | pending |','| l2-resume-run完整282；实际ASan/UBSan，生产编译flag、Judgement15及公共Gameplay27、安装完整错误/回执通过 | pass |')
s=s.replace('当前pending硬项完成、最终文档/version/format/diff检查通过并冻结源码身份后，才能填写N3退出。','N3独立退出：N1预定八行本地硬矩阵均pass；D01–D16及适用安装消费者通过；完整源码身份、diff、新增文件、配置、原始日志和新证据包已冻结并核验。')
s=s.replace('最终format、文档414/20、status/section/target 4/5/2、version updater和diff门禁需在封存前再核对。','最终format、文档414/20、status/section/target 4/5/2、version updater和diff门禁通过，封存检查见n3-final-checks-run。')
s=s.replace('五公共input/timebase直返','五公共input/timebase直返')
report.write_text(s,encoding='utf-8')
plan=root/'docs/stage_plans/active/stage-07/plan-diagnostic-formalization.md'
s=plan.read_text(encoding='utf-8').replace('状态：active；独立前置工作包，方案方向已接受；N0差异刷新完成，N1已退出，N2已落地，N3硬矩阵运行中','状态：active；所属Stage7未关闭；独立诊断前置N0–N3已退出，SDK0.7.5未提交/未发行')
if '独立退出证据：[' not in s:s=s.replace('更新日期：2026-10-10','更新日期：2026-10-10\n\n独立退出证据：[N3真实验证与冻结工作树](../../../stage_reports/stages/stage-07/diagnostic-formalization/2026-10-10-n3-verification-and-exit.md)。\n本次任务到N3退出为止，不自动启动RPA，不授权提交/推送/PR/合并/发行。',1)
plan.write_text(s,encoding='utf-8')
status=root/'docs/CURRENT_STATUS.md'
s=status.read_text(encoding='utf-8')
old='Debug/Release、ON/OFF、static/shared、MinGW/Linux硬矩阵正在运行；尚未声称N3退出。'
assert old in s
s=s.replace(old,'Debug/Release、ON/OFF、static/shared及MSVC/MinGW/Linux ASan/UBSan本地硬矩阵均通过；\n[N3独立退出与冻结证据](stage_reports/stages/stage-07/diagnostic-formalization/2026-10-10-n3-verification-and-exit.md)成立，未提交/未发行。')
s=s.replace('完整平台矩阵仍在验证','本地完整平台矩阵已通过，退出证据按工作树快照冻结')
status.write_text(s,encoding='utf-8')
records=[]
for name,cmd in [('docs',['python','-B','tools/check_docs.py']),('status-contract',['python','-B','tools/check_docs_status_contract_tests.py']),('section-contract',['python','-B','tools/check_docs_section_contract_tests.py']),('target-contract',['python','-B','tools/check_docs_target_contract_tests.py']),('version',['python','-B','tools/update_version.py','--check']),('diagnostic-gate',['python','-B','tools/check_gameplay_diagnostic_formalization.py','--self-test']),('diff',['git','diff','--check'])]:
 result=subprocess.run(cmd,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (out/('n3-final-'+name+'.log')).write_bytes(result.stdout)
 records.append(dict(name=name,command=cmd,exit=result.returncode))
 (out/'n3-final-checks-run.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
 print(name,result.returncode,flush=True)
 assert result.returncode==0,name
