# Cuexis Versioning

状态：已接受

更新日期：2026-10-10

## 格式

规范版本：

```text
yy.mm.dd-v
```

日期使用 UTC。`v` 是同一 UTC 日期内从 1 开始人工递增的构建号。

构建后缀：

```text
正式      无后缀
开发      -dev
测试      -test
内部      -internal
实验      -exp.<name>
```

## 单一来源

`cmake/CuexisVersion.cmake` 保存年、月、日和 build。其他 CMakeLists 不重复手写版本。
`tools/update_version.py` 是人工更新入口，负责在一次事务中同步该文件与 `vcpkg.json`。

CMake `project(VERSION)` 使用无前导零的三段数字，例如 `26.8.1`。完整显示版本单独生成，例如 `26.08.01-1-dev`。

`vcpkg.json` 的 `version-string` 保存不带构建类型后缀的规范版本，例如 `26.08.01-1`，因为同一源码可以同时构建 Debug 和 Release。

## 更新流程

```text
取得目标 UTC yy/mm/dd
-> 若日期变化，将 build 设为 1
-> 若同一日期再次发布构建，人工递增 build
-> 运行 python -B tools/update_version.py yy.mm.dd-v
-> configure 生成 version.hpp
-> 运行版本一致性测试
```

只检查当前文件而不写入：

```powershell
python -B tools/update_version.py --check
```

## 生成头

`${binaryDir}/generated/cuexis/version.hpp` 至少提供完整字符串、三段日期、build 和 suffix。
旧的公开 `cuexis::version::hour` 为保持 0.5.x 源码兼容暂时保留，并固定为 `0`；它不再属于
构建身份。生成头不提交源码控制。

## 验证

测试检查：

```text
CMake 三段版本与版本配置一致
月份、日期和 build 合法
vcpkg version-string 与规范版本一致
suffix 只来自允许集合或 exp.<name>
窗口标题和启动日志使用完整显示版本
```

版本错误必须使 configure 或测试失败，不能只产生警告。

## SDK、ABI 与内容版本

项目显示版本不替代独立的兼容性版本：

```text
Cuexis display version     仓库/发行构建身份
C++ SDK API version        CMake package 与源码兼容版本；当前 static/shared preview 为 0.7.0
C ABI version              稳定 shared-library 二进制契约，阶段 12 首次冻结
Chart/Project/Asset format 各自持久化 format + version
ReplayData format          阶段 11 冻结的独立持久化版本
simulationVersion          粒子等确定性算法版本
```

当前 `CUEXIS_SDK_API_VERSION` 是 CMake package version 的唯一来源，生成头通过
`cuexis::version::sdkApi` 暴露，package config 同时设置 `Cuexis_VERSION` 和
`Cuexis_API_VERSION`。`Cuexis_VERSION_DISPLAY` 继续保存完整构建身份。preview 使用
`SameMinorVersion`：`0.7.x` 内允许满足不高于已安装版本的请求，minor 或 major 变化必须由
consumer 显式接受。日期构建号变化不改变 `find_package` 兼容性。

阶段 1D 的 SourceClockSample、RuntimeTimeline、Prepared Playback 和 Audio package components
曾将 preview 提升到 `0.2.0`。阶段 1E 的 PlaybackSource 构造边界、FrameDigest 与 static/shared
package linkage 契约进一步把 `CUEXIS_SDK_API_VERSION`、package version、生成头和 external
consumer 同步提升到 `0.3.0`；后续不兼容修改必须再次提升 minor，禁止只修改其中一个版本来源。

ADR 0033 已将同工具链 C++ shared preview 纳入阶段 1E。`0.3.0` 已实现 Playback 的 source
构造边界与 package linkage 契约；static/shared 使用同一 API minor 和公共 target 名，但不能在
一个 install prefix 混装。`vcpkg.json` 继续只记录日期构建版本，不复制 `0.3.0`。

阶段 2 的 `FrameSnapshot` Visibility/Material 字段、FrameDigest version 2、capability 查询和
Chart v3 可观察合同是不兼容的公共结构变化，因此 ADR 0036 将 static/shared preview 提升到
`0.4.0`。`CUEXIS_SDK_API_VERSION`、生成头、package version 与 external consumer 必须保持
同步；`vcpkg.json` 仍不复制 SDK API 版本。

阶段 3B 新增 Portable Presentation Profile v1 public values、candidate manifest/token 和 owning
resource acquisition，因此 preview 已提升到 `0.5.0`。阶段 3C 已在同一 public minor 中补齐
FrameSnapshot resource refs 与 FrameDigest v3，没有重复提升版本。

Stage Chart Format Update 的 CFU-E0 接受了 owning project-document source、CXC file/memory factory、
prepare options 和 semantic identity observation 的 additive API 方向。CFU-E1 首次落下 public source
type/factory 并将 preview、生成头、package config、version rejection 与 static/shared consumer 同步
提升到 `0.6.0`；E2/E3 将在同一已批准 minor 中完成其余冻结 surface。Stage 5 S5-C 新增公开
Presentation 类型 `Shader` / `ParameterizedMaterial`，因此 preview 提升到 `0.7.0`。

shared `0.x` 只支持使用匹配 SDK minor、编译器工具链、标准库、运行时、架构和 Debug/Release
配置重新构建的 consumer。CMake `SameMinorVersion` 继续表达源码/package 请求兼容，绝不表示
可以替换一个已部署 shared binary 而不重新编译 host。C ABI version 仍不存在，直至阶段 12 在
Judgement/Replay 和完整生命周期证据基础上冻结。

升级项目显示版本不得隐式升级 SDK API、内容格式或 ABI。安装包必须提供可查询的显示版本、
SDK API 版本和已启用组件；稳定 C ABI 在阶段 12 建立后再提供独立可查询版本。不兼容 API/ABI、
未来内容版本和不支持的 ReplayData 版本必须稳定失败。

## SDK 版本递增规范

Stage 7 prepares SDK `0.7.1` as an unreleased compatible patch candidate for explicit Entry
factories and experimental package isolation. This repair preserves installed public layouts,
signatures, vtables and default production source selection. `0.7.0` consumers rebuild against
the new package; new Entry consumers request at least `0.7.1`. Owner approval and trusted-base
bootstrap remain release prerequisites.

2026-10-08 S7A-7/8 actual diff review retains this patch under the 0.x policy below:
production declarations of installed PlaybackSession/PlaybackSource equal PR base
5472c463640cf3b66a03dd86fe87bd87239b2659 after excluding explicit candidate blocks;
the original 0.7.0 consumer is unchanged. New Gameplay names/types require candidate opt-in.
No production signature, layout, enum semantics or default selection changed. This is a
source compatibility decision; shared consumers must rebuild and package validation must
pass. Date identity is independently updated by update_version.py; owner release approval,
trusted bootstrap and hosted evidence remain open.


### S7A-8.4 owner approval record

A same-author PR uses an owner GitHub issue-comment record because GitHub does not accept
self-Approve reviews. The record starts with `cuexis-sdk-api-approval-v1` on its own line
using LF or CRLF, followed by one JSON object with exactly: `repository`, integer `pr`, full `base_sha`, full
`candidate_sha`, full `candidate_tree_sha`, `from`, `to`, `utc_date`. The API-observed actor
must be a human owner in `.github/sdk-api-owners.json` at the trusted base. The record must
be unedited and created on that UTC release date. Missing approval, wrong actor, stale date,
changed SHA/base/version/tree or an unavailable API denies permission. The newest owner record
supersedes older records; an invalid newer record revokes permission. Candidate files, labels
and `--allow-sdk-api-change` cannot grant permission. Owner approval requires explicit owner
authorization; the owner may invoke the double-click assistant below to publish through their
authenticated account. Routine agent builds, tests and pushes do not authorize approval posting.
Both comment selection and JSON parsing accept LF/CRLF line endings; normalization does not
change the API-observed comment or its raw size bound.

The metadata-only `pull_request` and `pull_request_target` gates check out the base and fetch
the actual PR head as data; neither executes PR code. Keeping `pull_request` also makes the
PR-head check reachable while the target-event workflow has not yet been installed on master.
This trigger bridge does not bootstrap the trusted checker or grant owner approval; a missing
trusted baseline still fails explicitly. The latest event base must be an ancestor of the PR head, so outdated
branches need updating. Merge-group approval binds the actual queue tree. Post-merge audit
permits a different merge/squash SHA only for the identical approved tree, actual previous-master
base and SDK transition. Only single-PR queues are supported; combined queues are rejected even
with an approval for their final tree. Historical checks
are evidence, not new release authorization.

The checker, tests, registry and workflow must first exist on trusted master. Missing baseline
files produce `version.bootstrap.required`, never candidate fallback. CODEOWNERS records owners
but does not activate protection. Initial bootstrap and activation of a trusted required workflow
remain owner operations. A protected first installation may use two steps: an SDK-unchanged
bootstrap installs the reviewed checker and owner registry while retaining compatible trusted
tests and workflow; a later PR installs the new tests/workflow and requests SDK authorization.
The first candidate must pass the actual old trusted checker/tests; the next workflow must use
only installed base tools. This deployment sequence never grants SDK approval, disables a
required check or permits candidate fallback. A separate bootstrap PR needs explicit owner
authorization where the task excludes additional PRs. The current classic required-check context alone does not prove an
unforgeable workflow source; protection and same-SHA hosted evidence remain acceptance items,
subject to the explicitly accepted single-maintainer exception below.

Personal repositories can enforce PRs and App-bound required checks through branch rulesets, but
GitHub configures required-workflow rules at organization/enterprise scope. A named check from
the GitHub Actions App does not distinguish workflow, matrix or event provenance. If the
platform rejects a workflow-source rule, keep that acceptance item open unless the owner
explicitly accepts and records an exception. Protection changes may be explicitly delegated by the owner.

### 单人维护仓库的检查来源例外（2026-10-10）

owner明确接受本仓库由本人单独维护时不强制指定可信workflow来源；这是治理要求修订，
不声明App/context绑定具有workflow来源锁定能力。范围仅为 `l-zilch-l/Cuexis` 当前个人仓库，
适用于S7A-8.4及后续普通PR；merge queue不在本例外内，继续保持禁用。

保留以下合并条件：master必须通过PR更新；`Version advancement (pre-merge)`需绑定
GitHub Actions App15368并通过strict检查；禁止强推/删除，无bypass；SDK变化仍要求真实
owner未编辑评论准确绑定base/head/tree、版本及UTC日期。checker仍从可信base读取，
不能回退候选代码、伪造status或接受CLI布尔授权。

每次交付核对门禁文件差异（workflows、checker/tests/updater、owners与CODEOWNERS），
并查看最终SHA实际Version Gate日志，确认base/head/UTC/审批comment ID以及真实校验步骤。
自动助手或代理可完成材料核对；owner仍决定合并和发行。新SHA不沿用旧审批/日志。
新增有写权限的维护者、改变检查App/执行方式、启用queue或转换仓库归属时，重新审查本例外，
不得把本次单人风险接受扩为多人维护承诺。

该例外接受同名Actions检查可被替换且平台无法强制锁定workflow的剩余风险；
人工/代理核对日志是补偿措施，不是不可伪造保证。裁定及配置证据见
[接受记录](../stage_reports/stages/stage-07/decisions/2026-10-10-single-maintainer-workflow-source-exception.md)。

### Windows double-click approval assistant

Windows用户可直接双击仓库内的 `tools/prepare_sdk_approval.cmd`（默认本仓库PR #32）。
需要已安装并登录GitHub CLI；当前账号须在可信base的owner名单中。助手会读取**线上当前PR**的
base、head、tree、SDK版本及UTC日期，核对版本递增，再生成LF-only UTF-8文本到
`out/sdk-approval/`，并以当前登录的owner账号直接发布新审批评论，随后读取API核验结果。
双击即表示本人授权发布该次线上当前候选的审批；无需复制粘贴或再打开PowerShell。

最新owner记录已完整匹配时不重复发布；较新的无效记录不会被较早有效记录掩盖。同一PR的本机
并发运行会被阻止。助手在当前进程固定使用 `http://127.0.0.1:7890` 代理，并清空代理绕过列表；
退出时恢复环境变量，不修改Windows或Git的全局代理设置。
读取连接失败最多尝试三次。POST失败不自动重发，而是读取评论确认是否已被GitHub接收；无法确认
时保留错误，请检查PR后重试。

发布后在该PR的Actions中重跑失败的Version Gate。每次推送后可以重新双击，文本按线上最新提交
生成；本地未提交改动不在审批范围。发布前后均检查分支与UTC日期；若发布后发生变更，评论
仅绑定原候选，需重新运行。候选日期过期或账号不符时停止，不以旧文件继续审批。

只生成文件的命令行模式为 `powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools/prepare_sdk_approval.ps1 -PrepareOnly`；
可通过 `-Repository owner/repository -PullRequest number` 选择其他适用仓库/PR。
离线测试：`powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools/check_sdk_approval_assistant_tests.ps1`。
助手不替代可信Version Gate或发行验收。CMD启动器使用持久窗口，成功或报错后均保留，
需本人关闭窗口；不再依赖按任意键暂停。每次执行在 `out/sdk-approval/run-日期时间-进程号.log`
记录输出、错误位置和调用栈。双击 `.cmd`，不要直接运行 `.ps1`。

### Recovering a stale owner approval

`version.sdk_api.approval_mismatch` requires comparing the newest owner record with the
actual PR base, final head commit and tree, SDK transition and UTC date. An earlier approval
does not cover later code or documentation commits. Finish the intended changes and push
the final candidate before preparing its approval text; avoid another report-only commit
after approval, since that changes the tuple again.

Prepare the LF-only record from the final Git objects and have the owner post it as a new,
unedited comment on the existing PR, either manually or by explicitly invoking the assistant.
The agent needs explicit owner authorization to publish approval; ordinary implementation
authorization does not suffice. Comment creation alone does not trigger this workflow: after the
comment exists, rerun the failed pre-merge check for that same candidate and inspect its
result. A fresh push requires a fresh tuple; a new UTC date requires the normal version/date
validation too. Do not reuse an old record, weaken exact binding, or execute candidate tools
as trusted code to make this rejection disappear.

### SDK version selection

本节是 SDK 版本选择和更新流程的统一规范；阶段计划引用本节，不为后续阶段预留版本号。
SDK 使用 `major.minor.patch` 三个非负整数，不是小数；例如
`0.9.0 -> 0.10.0 -> 0.11.0`，minor 和 patch 不设一位数字上限。
SDK 版本与 Stage 编号、日期构建号及内容格式版本均不绑定。一个阶段可以不升级 SDK，
也可以包含多次已批准的 SDK 发行；不得为了等待 Stage 14 而压低 minor。

### 0.x preview 的选择规则

| 变化 | SDK 版本处理 |
|---|---|
| 仅文档、内部重构、测试或构建身份变化，公开合同未变 | 通常不改 SDK 版本；显示版本仍遵守其自身规则 |
| 恢复既有合同的兼容修复，或经审查确认兼容的新增名字 API/类型 | 可递增 patch；必须保持旧 consumer 的源码及可观察合同兼容 |
| 不兼容的公开布局、签名、虚表、枚举语义、默认入口/行为或 capability 合同变化 | 必须递增 minor，patch 归零；先批准合同和迁移决策，再实现/发行 |
| 一组经批准的公共合同发行，即使全部为 additive | 可递增 minor，patch 归零；记录发行边界与理由，不强制所有新增 API 都升 minor |
| 正式稳定 SDK | 仅在 Stage 14 稳定性与 ABI 验收后进入 `1.0.0` |

以上是本项目 **0.x preview** 政策，不宣称 additive API 使用 patch 符合稳定 1.x 的版本规则。
“additive”不能只按名字或字段数量判断：必须验证重载解析、聚合初始化、继承实现、
默认行为和旧 consumer 的可观察结果；无法证明兼容时不得用 patch 掩盖风险。
已经发行的版本号及其合同不得重新分配，不得回退版本，也不要求每次提交都增加 SDK 版本。
同一已批准发行的分批实现可以共用目标版本，但不得修改已经发行的该版本合同。

`SameMinorVersion` 只检查 package 请求，不检测功能是否存在。例如使用 `0.7.1` 新 API 的
consumer 必须请求至少 `0.7.1`，不能仅以 `find_package(Cuexis 0.7 ...)` 声称满足最低要求。
内容能力仍须按 capability/格式合同检查；experimental 构建标记不代表正式支持。
preview 的源码兼容不代表 shared binary 可直接替换，旧 host 仍须按受支持配置重新构建。

### SDK 更新流程与验收

1. 以实际集成基线和最近已发行合同盘点公共差异，包含期间其他阶段交付；列出最低 consumer
   版本、兼容性结论和迁移影响。不能从旧计划中的历史版本直接推算目标。
2. 在对应阶段版本决策中记录具体目标、patch/minor 理由和验收矩阵，经 owner 接受；
   不兼容变更须先接受相应 ADR。若偏离已冻结目标，先重开该决策并同步依赖计划。
3. 在 API 实现及门禁落地时更新 `cmake/CuexisVersion.cmake` 的
   `CUEXIS_SDK_API_VERSION`，同步 API 文档、consumer 最低版本和版本拒绝测试。
   package config 和版本头从单一来源生成，不另设手写版本副本。
   `tools/update_version.py` 只更新日期构建身份；`vcpkg.json` 不填写 SDK API 版本。
4. 版本变更使用 fresh configure 和 clean build；验证生成头、安装 package version 一致，
   static/shared clean staged consumer 通过，并覆盖旧源码重建、最低版本请求、
   过高 patch 和跨 minor/major 请求拒绝。breaking minor 的旧 consumer 按批准的迁移合同验收，
   不伪造“无需迁移”的兼容承诺。
5. 发行记录写明实际 SDK 版本、显示版本、对应 SHA、兼容/迁移结论和验证证据；
   更新当前状态及后续阶段接手基线。不能仅因版本号已改就宣称阶段或 ABI 已完成。

以上是规范与验收要求，不表示全部已由自动化强制执行。
Stage 14 必须另行冻结 `1.x` 的 API/ABI 兼容、弃用和版本递增政策及其测试；
在此之前，`0.x` minor 可以持续增长，不能从 `0.9.x` 自动进位到 `1.0.0`。

### 2026-10-10诊断正式化版本裁定

owner明确指定[独立诊断正式化工作包](../stage_plans/active/stage-07/plan-diagnostic-formalization.md)
目标SDK API为`0.7.5`，同时保留此前已接受的新Recovery版本拒绝旧版本方向。
这是本工作包的具体版本裁定，尚未更新实现、发行或完成N1/N3；版本文件在N2版本集成时同步。
N1仍需盘点production/candidate公共差异及迁移影响，不将patch数字当作可观察合同兼容证明。
若实际差异属于常规规则要求升minor的不兼容公开变化，本工作包按owner指定的`0.7.5`
记录限定例外及具体影响，不反向放宽Reader来制造兼容，也不推广为其他阶段可使用breaking patch。
该版本裁定不替代具体SHA的审批、安装消费者、内容版本拒绝或发行门禁。

## Stage 6 已冻结的版本方向（阶段已于 2026-09-27 关闭并归档）

[ADR 0042](../adr/0042-stage-6-productization-boundaries.md) 将 Stage 6 SDK 目标冻结为
`0.7.1`，仅用于新名字的源兼容增量 API；不得改变已有公开布局、签名、虚表、枚举含义或
默认入口语义。现有实现仍为 `0.7.0`，版本代码在对应 API 实现及 consumer 门禁落地时同步更新。
旧 consumer 需要重新构建，patch 号不承诺 shared binary 可替换。需要不兼容变更时必须重新
裁定 minor 和 Stage 8 接手版本，不能在 `0.7.1` 内偷偷破坏契约。`0.7.1` 是以当前
`0.7.0` 基线及上述兼容条件为前提的目标，不是可以覆盖其他已发行版本的固定配额。
Stage 8 不预留 `0.8.0`；正式 v5 发行版本按届时实际基线（包括 Stage 7A）与公共合同差异
重新裁定，并在发行前落实为具体版本、consumer 要求和验收记录。

experimental candidate 是独立构建/安装标识，不是 SDK minor 或正式内容能力。
生产与实验安装树不能混用；具体 opt-in 和 consumer 配置规则见 ADR 0042。
同一 ADR 固定 Stage 6 的显示版本门禁方向：受保护 `master` 最新 SHA、UTC 日期、
同日 build 精确加一、跨日归一、docs-only 不豁免和历史 SHA 复验分离。
S6-B1 已落下 `tools/check_version_gate.py`、独立 focused tests 和
`.github/workflows/version-gate.yml`。比较器负责规范四元组、trusted UTC、祖先关系、
manifest/CMake 一致性和 SDK API 不变性；workflow 在 PR、merge queue、合并后 push 与历史复验
中从 trusted baseline materialize checker，不从候选树回退使用 checker。首次装配若基线缺少
checker/test/workflow 文件会明确失败并记录 `version.bootstrap.required`，必须由 owner 审查
bootstrap 例外及保护规则后才能建立受保护基线。

### S6-B1 合并与发行 checklist

本地只证明脚本合同和当前文件一致，不能替代 hosted 保护证据：

```powershell
python -B tools/check_version_gate_tests.py
python -B tools/check_version_gate.py --check-current
python -B tools/update_version.py --check
```

受保护 `master` 的 PR/merge queue 检查使用事件提供的目标分支基线和 `github.sha` 候选最终树，
要求完整历史、trusted baseline checker 和同日精确递增；合并后 push 只作防漏审计。docs-only
也必须更新日期版本。历史复验必须传入已记录的 baseline、candidate 和 UTC 日期，只证明历史门禁，
不产生新的发行版本。

发布前还必须记录对应 SHA、显示版本、SDK API 版本、静态/共享安装 consumer 和 fresh
configure/clean build 证据；版本变化不隐式升级 SDK API、内容格式或 ABI。仓库保护未启用时，
只能报告“脚本完成、门禁未启用”，不能把本地通过写成 B1 退出证据。

### 升级示例：从 `0.7.0` 基线重建宿主

`examples/reference_host/` 是当前唯一可执行的升级示例，也是 `0.7.0` 基线的写法样本：

```cmake
find_package(Cuexis 0.7.0 CONFIG REQUIRED COMPONENTS Playback)
```

它显式声明自己编写时对齐的 API 版本，并在安装包记录的 API minor 不兼容时于 configure 阶段失败，
而不是留到运行期。从旧基线升级到当前构建的最小流程是：

1. 用新版本重新配置并安装 SDK（`cmake --install <build> --prefix <new-prefix>`）。
2. 把宿主指向新前缀（`-DCuexis_DIR=<new-prefix>/lib/cmake/Cuexis`）。
3. 干净重建宿主（新构建目录），不要在旧构建目录上增量链接。

`0.7.0` 与当前实现之间**没有源不兼容变更**：C4 只新增了示例宿主与打包目标，没有改动任何已发布
的公开头、签名、枚举语义或默认入口，也没有提升 SDK API 版本。因此从 `0.7.0` 基线重建宿主不需要
迁移步骤。shared 预览仍不承诺 binary 可替换：升级必须重新构建 consumer，不能只替换 `.so`/`.dll`。

配置存储的升级与回滚边界（[STAGE6_CONFIG_AND_MEDIA.md](../formats/STAGE6_CONFIG_AND_MEDIA.md) §1）：
`cuexis.player-preferences` 与 `cuexis.audio-device-profile` 目前都只有 v1，实现**不发明** v0
迁移。遇到更高或更低版本的既有文件时，加载会退回文档化默认值、保留原文件并给出
`player.preferences.unsupported_version` / `player.audio_profile.unsupported_version`，保存路径
拒绝覆盖该文件。因此“升级”不会静默改写用户文件，回滚到旧构建也仍然可读；这是当前可验证的迁移
安全边界，而不是迁移实现。
