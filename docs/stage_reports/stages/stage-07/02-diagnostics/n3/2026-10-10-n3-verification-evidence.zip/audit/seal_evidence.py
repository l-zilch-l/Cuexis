import pathlib,subprocess,json,hashlib,zipfile,datetime,re
root=pathlib.Path(__file__).resolve().parents[3];out=pathlib.Path(__file__).parent
bundle=root/'docs/stage_reports/stages/stage-07/diagnostic-formalization/2026-10-10-n3-verification-evidence.zip'
sha=lambda data:hashlib.sha256(data).hexdigest()
# Exit requires all predetermined hard rows, plus the corrected M1 and later tests.
for row in ['m2','m3','m4']:
 records=json.loads((out/(row+'-run.json')).read_text())
 assert records[-1]['step']=='ctest' and records[-1]['exit']==0,row
for row in ['m5','m6','l1','l2']:
 records=json.loads((out/(row+'-resume-run.json')).read_text())
 assert records[-1]['step']=='ctest' and records[-1]['exit']==0,row
for name in ['final-windows-run.json','final-linux-run.json','n3-final-checks-run.json']:
 assert all(x['exit']==0 for x in json.loads((out/name).read_text())),name
assert '100% tests passed, 0 tests failed out of 210' in (out/'m1-final-judgement.log').read_text()
for row in ['m1','m2','m3','m6','l1']:
 assert '100% tests passed, 0 tests failed out of 1' in (out/(row+'-final-installed-receipt.log')).read_text(),row
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()
assert head=='2ddbcafe22bd3facc63b4917cf99eeccc3d81cd1'
files=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=root).decode().split('\0')
relative_bundle=bundle.relative_to(root).as_posix()
source_files=sorted({name for name in files if name and name!=relative_bundle and (root/name).is_file()})
manifest={'baseHead':head,'branch':'stage-7','identityKind':'complete uncommitted worktree snapshot; not a new behavior commit SHA','sdkApi':'0.7.5','dateVersion':'26.10.10-1','excludedDerivedArtifact':relative_bundle,'files':[]}
with zipfile.ZipFile(out/'closing-source-snapshot.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name in source_files:
  data=(root/name).read_bytes();manifest['files'].append(dict(path=name,bytes=len(data),sha256=sha(data)));z.writestr(name,data)
manifest['sourceFingerprint']=sha(json.dumps(manifest['files'],sort_keys=True,separators=(',',':')).encode())
(out/'source-manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
(out/'closing-worktree.diff').write_bytes(subprocess.check_output(['git','diff','--binary','HEAD'],cwd=root,stderr=subprocess.DEVNULL))
(out/'closing-status.txt').write_bytes(subprocess.check_output(['git','status','--short'],cwd=root))
for directory in ['diagnostic-debug','diagnostic-release','diagnostic-shared','diagnostic-off-debug','diagnostic-off-release','diagnostic-mingw','diagnostic-linux-gcc','diagnostic-linux-sanitize']:
 build=root/'out/build'/directory
 (out/(directory+'-CMakeCache.txt')).write_bytes((build/'CMakeCache.txt').read_bytes())
 cmd=['ctest','--test-dir',str(build),'--show-only=json-v1']
 if directory.startswith('diagnostic-linux'):
  cmd=['wsl','-d','Ubuntu','--exec','ctest','--test-dir','/mnt/d/Cuexis-worktree/out/build/'+directory,'--show-only=json-v1']
 result=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,cwd=root)
 assert result.returncode==0,directory
 discovery=json.loads(result.stdout);assert discovery['tests']
 (out/(directory+'-final-discovery.json')).write_bytes(result.stdout)
index=[]
inputs=sorted(p for p in out.rglob('*') if p.is_file() and p.name not in ['evidence-package-sha256.json','evidence-index.json','exit-summary.json'])
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in inputs:
  name='audit/'+p.relative_to(out).as_posix();data=p.read_bytes();z.writestr(name,data);index.append(dict(path=name,bytes=len(data),sha256=sha(data)))
 z.writestr('evidence-index.json',json.dumps(index,indent=2).encode())
with zipfile.ZipFile(bundle) as z:
 for item in index:
  assert sha(z.read(item['path']))==item['sha256'],item['path']
for item in manifest['files']:
 assert sha((root/item['path']).read_bytes())==item['sha256'],item['path']
summary={'N3':'exited','sourceFingerprint':manifest['sourceFingerprint'],'sourceFileCount':len(manifest['files']),'bundle':relative_bundle,'bundleSha256':sha(bundle.read_bytes()),'bundleBytes':bundle.stat().st_size,'archiveEntriesVerified':len(index),'baseHead':head,'SDK':'0.7.5','noCommitPushPRPublishMergeRelease':True}
(out/'evidence-package-sha256.json').write_text(json.dumps(summary,indent=2))
(out/'exit-summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
