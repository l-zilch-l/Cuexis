import argparse,subprocess,json,pathlib,re,sys,time,os
root=pathlib.Path(__file__).resolve().parents[3]; out=pathlib.Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('rows',nargs='+');p.add_argument('--extra-only',action='store_true');p.add_argument('--resume',action='store_true');p.add_argument('--tests-only',action='store_true');args=p.parse_args()
configs={
'M1':('candidate-debug','diagnostic-debug','ON','Debug','STATIC'),
'M2':('candidate-debug','diagnostic-release','ON','Release','STATIC'),
'M3':('candidate-headless-debug','diagnostic-shared','ON','Debug','SHARED'),
'M4':('headless-debug','diagnostic-off-debug','OFF','Debug','STATIC'),
'M5':('headless-release','diagnostic-off-release','OFF','Release','STATIC'),
'M6':('mingw-headless-debug','diagnostic-mingw','ON','Debug','STATIC'),
'L1':('', 'diagnostic-linux-gcc','ON','Release','SHARED'),
'L2':('', 'diagnostic-linux-sanitize','ON','Debug','STATIC')}
for key in args.rows:
 preset,name,candidate,mode,library=configs[key]; build=root/'out/build'/name; records=[]
 prefix=key.lower()+'-resume'
 if key.startswith('L'):os.environ['CMAKE_PREFIX_PATH']='/mnt/d/Cuexis-worktree/out/build/wsl-gcc/vcpkg_installed/x64-linux'
 if key=='M6':os.environ['PATH']='C:/msys64/ucrt64/bin;'+os.environ['PATH']
 def run(label,cmd):
  log=out/(prefix+'-'+label+'.log');start=time.time()
  with log.open('w',encoding='utf-8') as f:r=subprocess.run(cmd,cwd=root,stdout=f,stderr=subprocess.STDOUT)
  records.append({'step':label,'command':cmd,'exit':r.returncode,'seconds':round(time.time()-start,2),'log':str(log)})
  (out/(prefix+'-run.json')).write_text(json.dumps(records,indent=2),encoding='utf-8')
  print(key,label,r.returncode,flush=True);return r.returncode==0
 if key!='M1' and not args.tests_only:
  cmd=['cmake','--fresh']
  if preset:cmd+=['--preset',preset]
  else:cmd+=['-S',str(root),'-G','Ninja']
  cmd+=['-B',str(build),'-DCUEXIS_ENABLE_CHART_V5_CANDIDATE='+candidate,'-DCMAKE_BUILD_TYPE='+mode,'-DCUEXIS_LIBRARY_TYPE='+library]
  if mode=='Release':cmd+=['-DCUEXIS_WARNINGS_AS_ERRORS=ON']
  if key=='M6':cmd+=['-DCMAKE_CXX_COMPILER=C:/msys64/ucrt64/bin/c++.exe','-DCMAKE_C_COMPILER=C:/msys64/ucrt64/bin/gcc.exe','-DCUEXIS_BUILD_DEVELOPER_TOOLS=ON','-DVCPKG_MANIFEST_INSTALL=OFF','-DVCPKG_INSTALLED_DIR=D:/Cuexis-worktree/out/build/mingw-headless-debug/vcpkg_installed']
  if key.startswith('L'):
   cmd+=['-DCUEXIS_IMPLEMENTATION_SHA=2ddbcafe22bd3facc63b4917cf99eeccc3d81cd1']
   cmd+=['-DCMAKE_CXX_COMPILER=/usr/bin/'+('g++' if key=='L1' else 'clang++'),'-DCUEXIS_BUILD_PLAYER=OFF','-DCUEXIS_BUILD_SDL_ADAPTER=OFF','-DCUEXIS_BUILD_AUDIO_SDL_ADAPTER=OFF','-DCUEXIS_BUILD_OPENGL_ADAPTER=OFF','-DCUEXIS_BUILD_DEVELOPER_TOOLS=ON','-DCMAKE_PREFIX_PATH=/mnt/d/Cuexis-worktree/out/build/wsl-gcc/vcpkg_installed/x64-linux','-DVCPKG_INSTALLED_DIR=/mnt/d/Cuexis-worktree/out/build/wsl-gcc/vcpkg_installed','-DVCPKG_TARGET_TRIPLET=x64-linux']
   if key=='L2':cmd+=['-DCUEXIS_ENABLE_SANITIZERS=ON']
  if not args.resume and not run('configure',cmd):continue
  if not run('build',['cmake','--build',str(build)]+([] if args.resume else ['--clean-first'])+['-j','4']):continue
 discover=subprocess.run(['ctest','--test-dir',str(build),'--show-only=json-v1'],capture_output=True,text=True)
 (out/(prefix+'-discovery.json')).write_text(discover.stdout,encoding='utf-8')
 if discover.returncode: print('discovery failed',flush=True);continue
 tests=json.loads(discover.stdout)['tests']; selected=[]; names=[]
 for i,t in enumerate(tests,1):
  labels=set(next((v['value'] for v in t.get('properties',[]) if v['name']=='LABELS'),[]))
  hit=bool(labels & {'judgement','package','candidate','gameplay','diagnostics'}) or bool(re.search(r'[Cc]andidate|[Gg]ameplay|[Pp]layer|cuexis_architecture|cuexis_contract_version',t['name']))
  if args.extra_only and 'judgement' in labels:hit=False
  if key!='M1' and t['name'].startswith('cuexis_external_consumer_') and t['name']!='cuexis_external_consumer_find_package_playback':hit=False
  if 'performance' in labels or re.search(r'performance|capacity',t['name'],re.I):hit=False
  if hit:selected.append(str(i));names.append(t['name'])
 if not selected:raise RuntimeError('zero discovered applicable cases')
 (out/(prefix+'-selected.json')).write_text(json.dumps(names,ensure_ascii=False,indent=2),encoding='utf-8')
 print(key,'discovered',len(tests),'selected',len(names),flush=True)
 run('ctest',['ctest','--test-dir',str(build),'-I','0,0,0,'+','.join(selected),'--output-on-failure','--no-tests=error','-j','4'])
