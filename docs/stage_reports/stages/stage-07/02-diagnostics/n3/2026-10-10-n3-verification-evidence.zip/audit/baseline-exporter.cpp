// Baseline export runs before producer migration. Fault Snapshot uses the internal DTO;
// the public snapshot verb continues to reject Faulted sessions.
TEST_CASE("diagnostic baseline exports healthy and fault recovery originals",
          "[recovery][diagnostic][baseline]") {
    std::string output;
#ifdef _MSC_VER
    char* value = nullptr;
    std::size_t size = 0;
    if (_dupenv_s(&value, &size, "CUEXIS_DIAGNOSTIC_BASELINE_OUTPUT") == 0 && value)
        output = value;
    std::free(value);
#else
    if (const auto* value = std::getenv("CUEXIS_DIAGNOSTIC_BASELINE_OUTPUT"))
        output = value;
#endif
    if (output.empty()) return;
    auto save = [&](std::string_view name, const std::vector<std::byte>& bytes) {
        std::ofstream file{std::filesystem::path{output} / name, std::ios::binary};
        REQUIRE(file);
        file.write(reinterpret_cast<const char*>(bytes.data()),
                   static_cast<std::streamsize>(bytes.size()));
        REQUIRE(file.good());
    };
    FoldFixture f{true};
    auto s = f.session();
    REQUIRE(s.submit({raw(900, 1), raw(1000, 2, InputAction::release)}));
    REQUIRE(s.advance(Tick{1103}));
    save("healthy.replay", *encodeReplay(*s.archive()));
    save("healthy.snapshot", *encodeSnapshot(*s.snapshot()));
    for (const auto point : {detail::KernelFailurePoint::beforeSeal,
                             detail::KernelFailurePoint::beforeFold}) {
        FoldFixture fault;
        fault.tap();
        auto session = fault.session();
        const detail::KernelTestControls controls{Tick{5}, point, {}, {}, {}};
        REQUIRE(detail::KernelTestAccess::inject(session, controls));
        REQUIRE(session.submit({raw(5, 1)}));
        REQUIRE_FALSE(session.advance(Tick{20}));
        REQUIRE_FALSE(session.snapshot());
        auto replay = *session.archive();
        auto encoded = encodeReplay(replay);
        REQUIRE(encoded);
        REQUIRE(decodeReplay(*encoded, fault.inputs()));
        auto evaluated = detail::ExecutionKernel::evaluate(replay, &controls);
        REQUIRE(evaluated);
        CHECK(sameKernelResult(*evaluated->result, session.query()->kernelView()));
        const auto name = point == detail::KernelFailurePoint::beforeSeal ? "kernel" : "fold";
        save(std::string{name} + ".replay", *encoded);
        auto dto = detail::KernelTestAccess::captureDTO(session);
        REQUIRE(dto);
        detail::wire::Writer header, body, payload, envelope;
        header(dto->kernel.judgementIdentity.canonicalBytes().bytes(),
               dto->kernel.effectiveFactSemanticRevision, std::uint32_t{1},
               static_cast<std::uint64_t>(dto->ingress.accepted.size()),
               static_cast<std::uint64_t>(dto->kernel.facts.size()),
               std::string{"canonical.discrete.le.v1"});
        body(*dto);
        auto section = [&](std::uint8_t id, const detail::wire::Writer& data) {
            payload(id, static_cast<std::uint64_t>(data.bytes.size()));
            payload.bytes.insert(payload.bytes.end(), data.bytes.begin(), data.bytes.end());
        };
        section(1, header);
        section(2, body);
        for (char c : std::string{"CXGREC01"}) envelope.bytes.push_back(static_cast<std::byte>(c));
        envelope(std::uint32_t{1}, std::uint8_t{2},
                 static_cast<std::uint64_t>(payload.bytes.size()), detail::wire::digest(payload.bytes));
        envelope.bytes.insert(envelope.bytes.end(), payload.bytes.begin(), payload.bytes.end());
        auto decoded = decodeSnapshot(envelope.bytes, fault.inputs());
        REQUIRE(decoded);
        CHECK(sameSnapshot(*dto, decoded->state()));
        save(std::string{name} + ".snapshot", envelope.bytes);
    }
}
