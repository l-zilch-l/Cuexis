import pathlib,subprocess,json,time,os
root=pathlib.Path(__file__).resolve().parents[3];out=pathlib.Path(__file__).parent;build=root/'out/build/diagnostic-linux-gcc'; records=[]
os.environ['CMAKE_PREFIX_PATH']='/mnt/d/Cuexis-worktree/out/build/wsl-gcc/vcpkg_installed/x64-linux'
for name,cmd in [('l1-final-playback-build',['cmake','--build',str(build),'--target','cuexis_playback_tests','-j','4']),('l1-final-playback-gameplay',[str(build/'bin/cuexis_playback_tests'),'[candidate][gameplay]']),('l1-final-judgement-diagnostic',[str(build/'bin/cuexis_judgement_tests'),'[diagnostic]'])]:
 start=time.time()
 with (out/(name+'.log')).open('w',encoding='utf-8') as f:r=subprocess.run(cmd,cwd=root,stdout=f,stderr=subprocess.STDOUT)
 records.append(dict(name=name,command=cmd,exit=r.returncode,seconds=round(time.time()-start,2)))
 (out/'final-linux-run.json').write_text(json.dumps(records,indent=2))
 print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
