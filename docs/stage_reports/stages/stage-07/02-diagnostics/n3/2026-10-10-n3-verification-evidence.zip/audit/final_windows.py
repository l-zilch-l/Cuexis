import subprocess,pathlib,json,time
root=pathlib.Path(__file__).resolve().parents[3];out=pathlib.Path(__file__).parent;records=[]
def run(name,cmd):
 start=time.time()
 with (out/(name+'.log')).open('w',encoding='utf-8') as f:r=subprocess.run(cmd,cwd=root,stdout=f,stderr=subprocess.STDOUT)
 records.append(dict(name=name,command=cmd,exit=r.returncode,seconds=round(time.time()-start,2)))
 (out/'final-windows-run.json').write_text(json.dumps(records,indent=2))
 print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
for row,directory in [('m1','diagnostic-debug'),('m2','diagnostic-release'),('m3','diagnostic-shared')]:
 build=root/'out/build'/directory
 run(row+'-final-playback-build',['cmake','--build',str(build),'--target','cuexis_playback_tests','-j','4'])
 run(row+'-final-playback-gameplay',[str(build/'bin/cuexis_playback_tests.exe'),'[candidate][gameplay]'])
 run(row+'-final-diagnostic-gates',['ctest','--test-dir',str(build),'-R','cuexis_gameplay_diagnostic','--no-tests=error','--output-on-failure','-j','4'])
 if row=='m1':run('m1-final-judgement',['ctest','--test-dir',str(build),'-L','judgement','--no-tests=error','--output-on-failure','-j','4'])
run('final-format-check',['cmake','--build',str(root/'out/build/diagnostic-debug'),'--target','cuexis_format_check'])
