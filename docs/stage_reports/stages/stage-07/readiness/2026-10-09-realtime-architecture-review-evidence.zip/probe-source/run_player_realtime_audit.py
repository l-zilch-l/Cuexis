"""Build a standalone probe from an existing MSVC candidate build, without editing it.

Run in a VS Developer shell. The existing target is incrementally rebuilt first.
Only probe outputs are written under --output; no production executable is replaced.
This is a local characterization runner, not a portable build target or CI gate.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if sys.platform != "win32":
        parser.error("This runner requires Windows MSVC and its Developer shell")
    build, output = args.build.resolve(), args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    root = Path(__file__).resolve().parents[2]
    source = root / "tools/research/player_realtime_audit.cpp"
    records = []

    def run(command, name, env=None):
        value = subprocess.run(command, cwd=build, env=env, stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT, text=True, errors="replace")
        (output / name).write_text(value.stdout, encoding="utf-8")
        records.append({"command": command, "cwd": str(build), "exit": value.returncode,
                        "output": name})
        (output / "commands.json").write_text(json.dumps(records, indent=2), encoding="utf-8")
        if value.returncode:
            raise RuntimeError(f"{name}: exit={value.returncode}; see {output / name}")
        return value.stdout

    run(["cmake", "--build", str(build), "--target", "cuexis_player_control_tests",
         "cuexis_playback_tests", "-j", "3"], "build.log")
    run([str(build / "bin/cuexis_playback_tests.exe"), "[.candidate-gameplay-fixture]"],
        "fixture.log")
    run([str(build / "bin/cuexis_player_control_tests.exe")], "player-tests.log")
    entries = json.loads((build / "compile_commands.json").read_text(encoding="utf-8"))
    entry = next(x for x in entries if x["file"].endswith("/player_gameplay_tests.cpp"))
    compile_command = re.sub(r" /Fo\S+", lambda _: f' /Fo"{output / "probe.obj"}"', entry["command"])
    compile_command = re.sub(r" /Fd\S+", lambda _: f' /Fd"{output / "compile.pdb"}"', compile_command)
    compile_command = re.sub(r" -c .+$", lambda _: f' -c "{source}"', compile_command)
    run(compile_command, "compile.log")
    commands = run(["ninja", "-t", "commands", "cuexis_player_control_tests"], "ninja-commands.log")
    line = next(x for x in commands.splitlines() if "vs_link_exe" in x and
                "/out:bin\\cuexis_player_control_tests.exe" in x)
    link = line.split(" -- ", 1)[1].split(" && ", 1)[0]
    link = re.sub(r"\btests\\player\\\S+_tests\.cpp\.obj\s*", "", link)
    link = re.sub(r" /out:\S+", lambda _: f' /out:"{output / "probe.exe"}"', link)
    link = re.sub(r" /implib:\S+", lambda _: f' /implib:"{output / "probe.lib"}"', link)
    link = re.sub(r" /pdb:\S+", lambda _: f' /pdb:"{output / "probe.pdb"}"', link)
    link += f' "{output / "probe.obj"}"'
    run(link, "link.log")
    env = os.environ.copy()
    env["PATH"] = str(build / "bin") + os.pathsep + env["PATH"]
    run([str(output / "probe.exe")], "measurements.csv", env)
    files = [source, Path(__file__).resolve(), build / "CMakeCache.txt",
             build / "s7a78-public-fixture/main.packed",
             build / "s7a78-public-fixture/configuration.json"]
    manifest = {"sourceHead": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root,
                                                       text=True).strip(),
                "files": {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(output)


if __name__ == "__main__":
    main()
