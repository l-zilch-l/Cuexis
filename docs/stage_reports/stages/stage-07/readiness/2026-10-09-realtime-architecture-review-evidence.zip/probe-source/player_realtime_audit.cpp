// Read-only characterization of the current Player bridge and public Playback path.
// This is a measurement input, not a production budget or an independent oracle.
#include "player_gameplay.hpp"
#include <cuexis/playback/content_provider.hpp>

#include <chrono>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>

namespace {
using namespace cuexis;
template <class T> auto take(core::Result<T> value) -> T {
    if (!value)
        throw std::runtime_error(std::string{value.error().code()});
    return std::move(*value);
}
void take(core::Result<void> value) {
    if (!value)
        throw std::runtime_error(std::string{value.error().code()});
}
using Clock = std::chrono::steady_clock;
auto milliseconds(Clock::time_point start) -> double {
    return std::chrono::duration<double, std::milli>(Clock::now() - start).count();
}
void measure(int repeat, int count, bool adapterPath, bool gameplayOnly) {
    const auto root = std::filesystem::path{CUEXIS_BUILD_DIR} / "s7a78-public-fixture";
    player::PlayerOptions options;
    options.gameplayConfiguration = root / "configuration.json";
    options.gameplayBudget = "131072,64,8192,16384,8192";
    options.gameplayHStep = "5";
    options.gameplayTStep = "7";
    auto profile = take(player::readPlayerGameplay(options));
    std::ifstream input{root / "main.packed", std::ios::binary};
    if (!input)
        throw std::runtime_error("Missing public fixture");
    const std::string packed{std::istreambuf_iterator<char>{input}, {}};
    std::vector<std::byte> bytes;
    for (const unsigned char c : packed)
        bytes.push_back(std::byte{c});
    auto provider = take(playback::MemoryContentProvider::create({}));
    auto source = take(playback::PlaybackSource::fromGameplayPacked(
        "realtime-audit", "compiled/main.packed", std::move(bytes), profile.configuration, {},
        provider, gameplayOnly ? playback::GameplayPrepareIntent::GameplayOnly
                               : playback::GameplayPrepareIntent::Presentation));
    playback::PlaybackSession session;
    auto prepared = take(session.prepareLoad(std::move(source), playback::PlaybackMode::ChartClock));
    take(session.commit(std::move(prepared)));
    player::PlayerGameplay adapter{std::move(profile)};
    const auto start = Clock::now();
    for (int i = 0; i < count; ++i) {
        // Each script spans exactly 1000 ms of *presentation* time. The current bridge
        // ignores that time when advancing H. No real device or frame pacing is simulated.
        const double position = static_cast<double>(i) * 1000.0 / (count - 1);
        const playback::RuntimeFrame frame{position, i == 0 ? 0.0 : 1000.0 / (count - 1), 0};
        if (adapterPath) {
            static_cast<void>(take(adapter.step(session, {}, frame)));
        } else {
            take(session.advanceGameplay({5LL * (i + 1)}, {7LL * (i + 1)}, frame));
            const auto result = take(session.queryGameplay());
            static_cast<void>(take(result.score()));
        }
    }
    const auto elapsed = milliseconds(start);
    const auto result = take(session.queryGameplay());
    const auto endStart = Clock::now();
    const auto archive = take(session.archiveGameplay());
    const auto replay = take(session.evaluateGameplayReplay(archive));
    const bool same = replay.evidenceValid && take(result.sameResult(replay.result));
    const auto endElapsed = milliseconds(endStart);
    if (!same)
        throw std::runtime_error("Complete Replay mismatch");
    if (adapterPath && adapter.horizon().value != 5LL * count)
        throw std::runtime_error("Unexpected characterization H");
    const auto score = take(result.score());
    std::cout << repeat << ',' << count << ','
              << (adapterPath ? "player_each_replay" : "public_end_replay") << ','
              << (gameplayOnly ? "gameplay_only" : "presentation") << ',' << elapsed << ','
              << endElapsed << ',' << 5LL * count << ',' << take(result.factCount()) << ','
              << score.score << ',' << same << '\n';
}
} // namespace

int main() try {
    // Warm up code and allocators; all warm-up rows remain visible in the output.
    std::cout << "repeat,count,path,intent,advance_ms,end_replay_ms,H,facts,score,complete_same\n";
    measure(-1, 16, true, false);
    measure(-1, 16, false, false);
    measure(-1, 16, false, true);
    for (int repeat = 0; repeat < 3; ++repeat) {
        for (int count : {30, 60, 256, 1024}) {
            measure(repeat, count, true, false);
            measure(repeat, count, false, false);
            measure(repeat, count, false, true);
        }
    }
    return 0;
} catch (const std::exception& error) {
    std::cerr << error.what() << '\n';
    return 1;
}
