Realtime architecture review evidence, 2026-10-09
Baseline: stage-7 d33c64b15575a945e50948ad70acb88f05117dce, existing PR32.
Diagnostic evidence only: not a shipped probe, new implementation, independent
oracle, device validation, owner acceptance or production budget.

Original sources: tools/research/player_realtime_audit.cpp and
 tools/research/run_player_realtime_audit.py; moved unchanged after scope narrowed
to out/realtime-architecture-audit/probe-source/, archived under probe-source/.
Runner assumes original tools/research location. Reproduction: restore both files
there in a disposable checkout with existing MSVC candidate builds, then in a VS
Developer shell run python -B tools/research/run_player_realtime_audit.py
 --build out/build/candidate-debug --output out/realtime-architecture-audit/debug
This is a reconstructed invocation recipe. Exact child commands, cwd and exits
are original commands.json. Release used out/build/s7a78-candidate-release;
its missing compile database entry is recorded; the runner has not been repaired.

39 CSV rows include 3 warmups and 3 repeats per mode/count. Each run compares
its own live query result with ReplayEvaluation.result using sameResult, and
checks evidenceValid. Other evaluation metadata and cross-mode results were not compared.
Debug values are not Release performance or hardware FPS. Existing regressions
passed in both builds; Release measurement stopped before probe compilation.
Failure note is reconstructed, not a verbatim captured console traceback.

CMakeCache/fixtures preserve build configuration and input bytes. Historical
manifest paths map to probe-source/, debug/fixture/, debug/CMakeCache.txt.
SDL excerpts retain local paths, line numbers and SHA256. No executable, object,
PDB or ILK is included. SHA256SUMS.json covers every other archive entry.
checks/ contains subsequent documentation-only verification logs.

Not executed: new realtime implementation/prototypes, independent timing oracle,
GPU/window/physical keyboard/audio accuracy/underrun experiments, new MinGW,
Linux or shared behavior matrices, S7A-9 closure or production thresholds.
