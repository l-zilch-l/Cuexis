# N0 public projection and carrier impact audit

Date: 2026-10-10. Baseline: stage-7, HEAD 2ddbcafe22bd3facc63b4917cf99eeccc3d81cd1. Read-only production audit. No N1 compatibility decision, version selection, implementation change, or N3 pass is asserted.

## Public projection boundary

- engine/playback/src/gameplay_internal.hpp:9-52 is the central projectGameplayError path. graph.* is returned with category/severity/faulted context. Only judgement.s7a2.* and judgement.s7a3.* are selected for category projection (line 23).
- Lines 25-29 retain five public input codes verbatim: judgement.s7a2.timebase.tick_overflow, judgement.s7a2.timebase.time_reversal, judgement.s7a2.input.amount_out_of_range, judgement.s7a2.input.amount_narrowed, judgement.s7a2.input.same_tick_collision.
- Lines 35-45 project the other selected codes onto nine registered category outputs; late_policy_incomplete currently projects to judgement.s7a4.late.parameters_invalid (line 39). Lines 46-52 preserve message/context and add sourceCode. The implementation does not reconstruct the original cause chain.
- judgement.s7a4.* bypasses the selected-family filter and is returned verbatim. Merely removing s7a2/s7a3 from producer names changes public observable codes and loses sourceCode projection behavior unless the selection is migrated.
- Calls exist in gameplay_candidate.cpp:73,94,114,119,126,175,273-277,369,391; gameplay_entry.cpp:43; playback_session.cpp:2787 onward (including fault receipt 2969 and recovery 3313).

## Carrier influence matrix

| Carrier | Verified existing representation and gates | Migration influence |
| --- | --- | --- |
| core::Error and public API Result | projectGameplayError above; Diagnostic toError in engine/judgement/src/diagnostic.cpp:29-51 | Code/message/context are owning observable values. Public/internal split must survive formal names. sourceCode is itself observable. |
| GameplayAdvanceReceipt.error | public gameplay_candidate.hpp:269; playback_session.cpp:2969 | Owning projected fault diagnostic persists after advancement; stage4 is currently direct-return. |
| KernelProjection.faultDiagnostic | kernel_types.hpp:217; execution_kernel.cpp:139,150,155,1361 | Stores kernel or Fold error and fault state. Kernel producer prefixes error suffix with stage4; Fold remains ruleset.transaction_failed. |
| Kernel result equality / GameplayResult | recovery.cpp:5-31 recursively compares code, message, context size/order/values and causes; gameplay_candidate.cpp:353 delegates sameResult | Renaming embedded faults changes complete-result equality even if score/facts/state are unchanged. |
| ReplayArchive / ReplayRecord / ReplayEvaluation | recovery.hpp:39-97 records shared owning KernelProjection; recovery.cpp:66-84 compares histories; execution_kernel.cpp:1992 checks sameKernelResult; 2140 also checks during seeking | Old fault diagnostic content participates in evidence validation and checkpoint/seek. Decoder success alone does not establish execution validity. |
| SnapshotDTO / SnapshotPayload | recovery.hpp:23-33; recovery.cpp:37-57; execution_kernel.cpp:1483-1498 validates exact kernel stage4 or ruleset fault code, no cause, exactly 3 ordered contexts | Old faulted Snapshot may fail restore following rename unless policy is explicit; healthy cases need separate verification. Do not loosen complete error checks. |
| ReplayCheckpoint | recovery.hpp:74-89 owns archive and state; execution_kernel.cpp:2086,2101 compare sameReplayHistory / sameSnapshot | May retain old archive/state diagnostic and therefore same complete-result sensitivity. |
| Public GameplayReplay / GameplaySnapshot / GameplayCheckpoint / GameplayReplayEvaluation | gameplay_candidate.hpp:223-260; gameplay_internal.hpp:69-121 wraps corresponding judgement owning values | Public opaque handles preserve affected internals; representation opacity does not remove behavioral compatibility influence. |
| Recovery wire Replay/Snapshot | recovery_wire.hpp:160-163 carries faultDiagnostic,184 carries ReplayRecord.result; 322-333 encodes code/message/ordered context/cause,426-449 decodes unchanged | Error text participates in bytes and encoded string lengths. Reader currently keeps exact decoded values, without aliases or rewrite. |
| Recovery envelope and payload digest | recovery_codec.cpp:11-28 magic CXGREC01, envelope uint32 version 1; 95-98 stateSchema=1 and canonical.discrete.le.v1; 57-58,104-105 reject unsupported version;165-166,250-251 validate digest; recovery_wire.hpp:454-460 FNV-style uint64 payload digest | Renamed embedded error changes payload and digest. No separate diagnostic-code revision field exists in this wire header. Blank diagnostic/healthy paths must be measured; no byte stability conclusion made here. |
| Prepared judgement identity | gameplay_assembler.cpp:1997-2075 writes engine/ruleset/chart/session revisions and runtime mapping/late/calibration tokens; explicitly excludes Snapshot schema at2016-2017 | Diagnostic strings are not a dedicated identity field in this construction. Changing semantic/profile revision changes identity; N1 must decide required revision separately from wire schema. |
| Gameplay Packed/Capsule/Graph | gameplay_capsule.hpp:18,46,56 default candidateRevision=2; gameplay_capsule.cpp:1498-1515 explicitly supports revision2/3 and checks execution-profile agreement | Source/capsule stores execution and identity declarations; direct recovery fault data is not shown here. DiagnosticMap is source declaration/path attribution (gameplay_assembler.cpp:2301-2302), not an error-code registry. No diagnostic rename implies automatic Capsule bump in this audit. |

## Revision and additional naming review inputs

execution_kernel.cpp:91-100 hard accepts gameplay.execution.t4-k4.v1, judgement.t4-k4.v1, coordination.six-eight.t4-k4.v1, late.window.logical.v1, fact.semantic.phase-local.v1, fixed-point.none.v1. gameplay_prepare.cpp:199-207 validates matching declarations. Runtime preparation may append gameplay.fold.finite.v1 (execution_kernel.cpp:845) and grade.signed-interval.v1 (861). These t4-k4 identifiers are opaque profile/semantic identity tokens containing design-option labels: potential formal naming review inputs, NOT automatic diagnostic rename candidates. Renaming them changes identity and accepted profile checks.

Three additional registered public diagnostic naming inconsistencies exist: presentation-target-missing and partial-group use unqualified kebab tokens (schemas code table:628,649; playback_session.cpp:3101,3085), identity_closure_incomplete is an unqualified snake token matching a category (schema:608; gameplay_internal.hpp:38). Schema notes explicitly say these strings were frozen by existing rulings. They should be recorded as review candidates, not treated as newly invalid or renamed within stage-prefix-only scope without N1 review.

Central code-table status contains registered-pending-owner-review (schema:25) alongside owner-ruled notes. srcOnlyPolicyNote references thirteen judgement.s7a2 strings and non-public policy (24). Keep policy/visibility meaning distinct from historical code spelling; historical provenance is not a blanket live rename requirement.

## Verification points and evidence limits

- Ran: cmake -DCUEXIS_SOURCE_DIR=D:/Cuexis-worktree -P cmake/VerifyGameplayDiagnosticsCodes.cmake. Exit 0: 69 public codes, 3 frozen input/geometry, 9 categories, 3 severities, 2 faulted behaviors, 19 rejection entries, 20 pending entries including 13 src-only.
- cmake/VerifyGameplayDiagnosticsCodes.cmake:108 checks table schemaVersion=2;247 onward enforces code uniqueness and metadata; frozen input/geometry family check remains restrictive. Gate verifies table internal integrity and public/pending split, not producer coverage or category projection semantics; do not use baseline pass to certify migration.
- CMakeLists.txt:273-280 registers cuexis_gameplay_diagnostics_codes with gameplay;judgement;diagnostics;schemas labels. CMakeLists.txt:462-479 registers installed candidate consumer; cmake/VerifyGameplayInstalledConsumer.cmake:51 sets Cuexis_ALLOW_EXPERIMENTAL=ON.
- tests/external/gameplay_consumer.cpp:20,26 surfaces errors by code/message;97-116 exercises snapshot/replay owning, encode/decode, evaluation and restore. It exercises healthy successful fixtures, not all renamed fault/negative-code compatibility cases.
- tools/gameplay_assembler/src/assembler_cli.cpp:151-152,266-267,307 prints observable diagnostic code/message without code translation.
- tests/judgement/execution_kernel_tests.cpp:308 asserts exact old kernel.transaction_failed; tests/judgement/fold_recovery_tests.cpp:317,1160 assert Fold ruleset.transaction_failed;540,546,554 assert unsupported wire version/digest mismatch/budget-unaccepted. Existing test locations are verification inputs, not test execution evidence.
- No compile, CTest suite, external consumer, or byte-equivalence migration test ran during this read-only N0 audit. No production/contract/version files were changed.

