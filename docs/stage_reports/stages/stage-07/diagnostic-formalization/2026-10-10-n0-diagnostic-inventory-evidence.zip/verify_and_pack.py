import pathlib,json,csv,hashlib,zipfile,subprocess
root=pathlib.Path.cwd(); out=root/'out/audit/rpa-n0-20261010'
inv=json.loads((out/'inventory/inventory.json').read_text(encoding='utf-8')); entries=inv['entries']
rows=list(csv.DictReader((out/'inventory/inventory.csv').open(encoding='utf-8-sig')))
assert len(entries)==len(rows)==67
names=[e['proposed_name'] for e in entries if e['disposition']=='rename_candidate'];assert len(names)==len(set(names))==66
literal=json.loads((out/'independent-phase-literals.json').read_text(encoding='utf-8'))
extras=set(literal['unique_codes'])-{e['code'] for e in entries}
assert extras=={'judgement.s7a2.input','judgement.s7a2.late','judgement.s7a2.timebase'}
findings=json.loads((out/'naming/findings.json').read_text(encoding='utf-8'));assert len(findings['new_code_candidates'])==2;assert len(findings['multi_reason_review'])==2
baseline=json.loads((out/'baseline-files.json').read_text(encoding='utf-8'));changes=[]
for name,sha in baseline.items():
    p=root/name;cur=hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
    if cur!=sha:changes.append(name)
expected={'docs/CURRENT_STATUS.md','docs/stage_plans/active/stage-07/plan-rpa.md','docs/stage_reports/stages/stage-07/README.md'}
assert set(changes)==expected,changes
result={'head':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'inventory_rows':67,'unique_phase_targets':66,'additional_development_code_candidates':2,'same_code_multiple_reason_reviews':2,'baseline_existing_file_count':len(baseline),'baseline_existing_files_changed':changes,'product_files_changed':[],'limits':'Static audit only; N1 compatibility/versions not decided; no runtime/build checks.'}
(out/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
archive=root/'docs/stage_reports/stages/stage-07/rpa/2026-10-10-n0-diagnostic-inventory-evidence.zip'
def pack():
    files=sorted(p for p in out.rglob('*') if p.is_file() and p.name!='SHA256SUMS.json')
    hashes={p.relative_to(out).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    (out/'SHA256SUMS.json').write_text(json.dumps(hashes,indent=2),encoding='utf-8')
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for p in files+[out/'SHA256SUMS.json']:z.write(p,p.relative_to(out).as_posix())
pack()
checks=[]
for key,cmd in [('docs',['python','-B','tools/check_docs.py']),('status-contract',['python','-B','tools/check_docs_status_contract_tests.py']),('section-contract',['python','-B','tools/check_docs_section_contract_tests.py']),('target-contract',['python','-B','tools/check_docs_target_contract_tests.py']),('diff',['git','diff','--check'])]:
    p=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8',errors='replace')
    (out/(key+'.log')).write_text(p.stdout+p.stderr,encoding='utf-8');checks.append({'check':key,'command':cmd,'exit_code':p.returncode});print(key,'exit',p.returncode);print(p.stdout+p.stderr)
result['checks']=checks;(out/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
pack()
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    sums=json.loads(z.read('SHA256SUMS.json'));assert all(hashlib.sha256(z.read(n)).hexdigest()==sha for n,sha in sums.items())
print('Evidence ZIP members',len(sums)+1,'sha256',hashlib.sha256(archive.read_bytes()).hexdigest())
assert all(x['exit_code']==0 for x in checks)
