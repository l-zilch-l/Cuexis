# RPA-N0 当前诊断码清单复核

证据日期：2026-10-10（Asia/Shanghai）。只读源代码审计；未实施重命名或运行新码验证。

当前 HEAD 为 `2ddbcafe22bd3facc63b4917cf99eeccc3d81cd1`，历史基线为
`d33c64b15575a945e50948ad70acb88f05117dce`。扫描 git 跟踪及非忽略工作区文本，保留未提交文档。

## 当前清单

`inventory.json` 是逐码权威机器结果，`inventory.csv` 是同范围 Excel 可读版本；
`summary.json` 为计数及差分，`scanned-files.txt` 保留覆盖路径，`build_inventory.py` 可重跑。

- 当前阶段诊断声明/构造仍为67项：s7a2=18、s7a3=41、s7a4=8，与历史清单无增删。
- 66条改名候选，1条无调用 second_half 占位；正式目标字符串彼此唯一，当前产品字符串未占用。
- 集中表13条公共、13条明确 src-only、41条未登记内部，不能由正式名推断公开性。
- 63条有活动生产者；3条常量没有产品生产者/消费者；1条只被无调用辅助函数引用。
- 生产者动态构造覆盖 `execution_profile.cpp:12` 与 `execution_kernel.cpp:14` 的完整前缀及所有字面 suffix 调用。
- 集中表中 `judgement.s7a2.input` / `late` / `timebase` 是 family 元数据，不另计3个诊断。
  前缀判断、family 元数据与完整码一样需要在迁移时同步检查。

历史 ZIP 读取但未改写，SHA256 为
`bb95958a0ae2946aca73e5ee8e4dae6f0824d834c7236c317e975daa475f1f63`。

## 新识别的存活与类别问题

1. `judgement.s7a2.late.queue_hop_exceeded` / `kQueueHopExceededCode`
   仅见 `source_codes.hpp:107` 和集中表 pendingRegistration（1658、1661）；没有活动生产者/测试消费者。
   声明注释说 declared-range failure，但没有实际 category 赋值，也未注册 category；清单明确标为
   `not_assigned_no_active_producer`，不把名称中的 late 当作类别依据。N1应决定保留改名还是删除死常量。
2. `judgement.s7a3.grace.quantization_mismatch` / `kGraceQuantizationMismatchCode`
   仅见 `source_codes.hpp:423–424`，没有活动生产者/测试消费者；其预算类别是注释意图，不是运行证据。
3. `judgement.s7a3.resource.state_transition_invalid` / `kResourceStateTransitionInvalidCode`
   仅见 `source_codes.hpp:439–440`，没有活动生产者/测试消费者；invalid_relation同样是注释意图。
4. `secondHalfError` 只见 `gameplay_assembler.cpp:147` 函数定义，码常量只在149行使用；
   对应 `kSecondHalfRemediation/Section/Path` 也只由此无调用函数使用。当前文本范围无消费者。
   尚未删除任何占位。
5. `content.unsupported_form` 真实有两类：`gameplay_assembler.cpp:381–382` 的
   boundedRelationInstance 使用 non_terminating_source；420–421 fallback 使用 capability_disabled。
   不能把同码归并为单类别并改变行为。
6. `grace.chart_supply_not_allowed` 真实有两类：3870行调用 declarationInvalidError
   （chartDuration与candidate同时提供）产生 invalid_relation；3876行 valueError
   （allowChartGrace=false）产生 budget_exceeded。清单保留实际分支。
7. `late.rejected` 经 profile动态构造及 kernel直接构造都属于 late_policy_incomplete，
   不套用 kernel通用 error helper的 invalid_relation。

## 公共投影与持久化证据

`gameplay_internal.hpp:22–27` 以阶段前缀识别内部来源并保留5个公开输入/时基码；
39行将 late_policy_incomplete 投影成 s7a4码，53行附加 sourceCode。
改名后若不替换前缀分流，会意外透传内部错误。13条公共登记与这5条透传不是同一个集合。

`execution_kernel.cpp:1485–1489` 精确比较 Snapshot faultDiagnostic 的 kernel.transaction_failed。
`recovery.cpp:5–20` 比较完整 Error 的 code/message/context/cause；30行把其纳入同kernel结果。
`recovery_wire.hpp:161` 序列化 faultDiagnostic，322行写入 Error，426行读取 Error；
`recovery_codec.cpp:27/165/250` 生成和校验 payload digest。
这些共享载体位置写入 JSON 的 shared_serialization_digest_references。
kernel fault码直接影响故障 Snapshot/Replay/Recovery；其他错误虽是 owning可观察结果，
本轮不假设每个错误都能进入成功归档，也未测量无诊断正常归档字节。

## 范围扩展注意

`session.cpp:24–25` 还有两个 provisional诊断；这属于扩大候选而非历史阶段67项。
特别是 provisional.session.lifecycle_order 去段会与阶段码正式目标
`judgement.session.lifecycle_order` 重合，须结合不同Session入口语义单独决策。
算法版本 token、fixture ID、测试标签、Stage计划名称、历史报告/ZIP不做批量去阶段名。

## 验证限制

本轮是源级逐码审计，不执行 C++构建/CTest、不证明公共新码或兼容revision。
category_evidence 与 production_status 区分真实生产、无活动生产者声明、无调用占位；
severity/faulted对无生产者常量是意图记录。扫描不能证明未来分支或外部宿主不存在旧owning值。
正式命名、三条死常量处置、公开/持久化兼容及版本裁定属于后续N1，未在本轮实施。
