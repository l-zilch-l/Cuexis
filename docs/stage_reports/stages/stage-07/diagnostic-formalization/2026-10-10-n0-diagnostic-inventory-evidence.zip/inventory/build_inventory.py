from pathlib import Path
import re, json, csv, zipfile, subprocess, hashlib, collections

ROOT=Path('D:/Cuexis-worktree')
OUT=ROOT/'out/audit/rpa-n0-20261010/inventory'
OUT.mkdir(parents=True,exist_ok=True)
ZIP=ROOT/'docs/stage_reports/stages/stage-07/rpa/2026-10-09-diagnostic-phase-name-audit-evidence.zip'
history=json.loads(zipfile.ZipFile(ZIP).read('inventory.json'))
paths=subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=ROOT).decode().split('\0')
texts={p:(ROOT/p).read_text(encoding='utf-8-sig',errors='replace') for p in sorted(set(paths)) if p and (ROOT/p).is_file() and Path(p).suffix in {'.hpp','.cpp','.h','.c','.cmake','.json','.md','.py','.txt','.ps1','.yml','.yaml'} and not p.startswith('out/')}
def ref(p,start,kind,token):
    t=texts[p]; n=t.count('\n',0,start)+1
    return {'path':p,'line':n,'kind':kind,'token':token,'snippet':t.splitlines()[n-1].strip()}
header=texts['engine/judgement/src/source_codes.hpp']
constants={m[1]:m[2] for m in re.finditer(r'(k\w+)\s*\{\s*"([^"]+)"\s*\}',header)}
definitions={m[2]:ref('engine/judgement/src/source_codes.hpp',m.start(),'definition',m[1]) for m in re.finditer(r'(k\w+)\s*\{\s*"(judgement\.s7a\d\.[^"]+)"\s*\}',header)}
stage_pat=re.compile(r'judgement\.(?:s\d+[a-z]?\d*|stage\d+)\.[a-z_]+\.[a-z_]+')
def strip_comments(t):
    return re.sub(r'/\*.*?\*/|//[^\n]*',lambda m:'\n'*m[0].count('\n'),t,flags=re.S)
current=set(definitions)
dynamic=[]
for p,t in texts.items():
    if not p.startswith(('engine/','app/','tools/')) or Path(p).suffix not in {'.cpp','.hpp'}:continue
    clean=strip_comments(t)
    current.update(stage_pat.findall(clean))
    if '"judgement.s7a4." + std::string{suffix}' in clean:
        for m in re.finditer(r'\b(error|rejection)\(\s*"([a-z_]+\.[a-z_]+)"',clean):
            code='judgement.s7a4.'+m[2];current.add(code)
            # Locate in original by call spelling, retaining accurate original line.
            needle=m[0]; occurrences=list(re.finditer(re.escape(needle),t))
            for v in occurrences:dynamic.append((code,ref(p,v.start(),'dynamic_suffix',m[2])))
dynamic=list({(c,r['path'],r['line']):(c,r) for c,r in dynamic}.values())
table=json.loads(texts['schemas/cuexis.gameplay-diagnostics.v2.codes.json'])
registered={e['code']:e for e in table['codes']}
pending={e['code']:e for e in table['pendingRegistration'] if e.get('code')}
oldentries={e['old']:e for e in history['entries']}
helpers={'declarationInvalidError':'invalid_relation','valueError':'budget_exceeded','versionError':'ambiguous_migration','amountValueError':'budget_exceeded','lateRejectionError':'late_policy_incomplete','capabilityUnsupportedError':'capability_disabled','capabilityRejection':'capability_disabled'}
entries=[]
for code in sorted(current):
    symbol=definitions.get(code,{}).get('token')
    refs=[]; producers=[]; cats=[]; cat_evidence=[]
    for p,t in texts.items():
        if p.startswith(('docs/stage_reports/','docs/archive/')):continue
        needles=[(code,'literal')]+([(symbol,'symbol')] if symbol else [])
        for needle,kind in needles:
            for m in re.finditer(re.escape(needle),t):
                r=ref(p,m.start(),kind,needle);refs.append(r)
                if p.startswith(('engine/','app/','tools/')) and Path(p).suffix=='.cpp':
                    producers.append(r)
                    pre=t[max(0,m.start()-180):m.start()]; post=t[m.start():m.start()+400]
                    h=re.search(r'(declarationInvalidError|valueError|versionError|amountValueError|lateRejectionError|capabilityUnsupportedError|capabilityRejection)\(\s*(?:codes::)?$',pre)
                    cat=helpers[h[1]] if h else None
                    if not cat:
                        h=re.search(r'codes::(k\w+Category)',post)
                        if h:cat=constants.get(h[1])
                    if not cat:
                        h=re.search(r'\.category\s*=\s*codes::(k\w+Category)',pre)
                        if h:cat=constants.get(h[1])
                    if cat:cats.append(cat);cat_evidence.append(dict(r,category=cat))
    drefs=[r for c,r in dynamic if c==code]
    producers+=drefs;refs+=drefs
    pub=registered.get(code)
    if pub:cats.append(pub['category'])
    # Fixed dynamic helper semantics, independently readable in producer source.
    if code.startswith('judgement.s7a4.'):
        cats = [{'execution.profile_incomplete':'identity_closure_incomplete','execution.profile_unsupported':'capability_disabled','late.parameters_invalid':'late_policy_incomplete','late.rejected':'late_policy_incomplete'}.get(code.removeprefix('judgement.s7a4.'),'invalid_relation')]
    if code.endswith('second_half.not_implemented'):cats=['capability_disabled','invalid_relation']
    inactive={'judgement.s7a2.late.queue_hop_exceeded':'not_assigned_no_active_producer','judgement.s7a3.grace.quantization_mismatch':'budget_exceeded','judgement.s7a3.resource.state_transition_invalid':'invalid_relation'}
    if code in inactive:
        cats=[inactive[code]]
        cat_evidence.append({'path':'engine/judgement/src/source_codes.hpp','line':definitions[code]['line'],'category':inactive[code],'basis':'declaration/comment intention only; no active producer or code/symbol consumer found'})
    categories=sorted(set(cats))
    refs=list({(r['path'],r['line'],r['kind']):r for r in refs}.values())
    producers=list({(r['path'],r['line'],r['kind']):r for r in producers}.values())
    category=categories[0] if len(categories)==1 else categories
    carrier='Owning core::Error / Diagnostic value changes; Playback projection may retain generic public code and change sourceCode. '
    if code=='judgement.s7a4.kernel.transaction_failed':carrier+='Snapshot faultDiagnostic accepted by strict code check; faulted ReplayEvaluation embeds diagnostic; RecoveryArchive wire serializes Error(code,message,context), payload digest changes. Old values must not be mutated.'
    else:carrier+='Failure results observable. Error wire can carry arbitrary owning values, but persisted successful Snapshot/Replay paths are not proven to contain this code; do not infer digest change for healthy archives.'
    # Strict fault expected-code comparison is a consumer, not a literal producer.
    producers=[r for r in producers if not (r['path']=='engine/judgement/src/execution_kernel.cpp' and r['line']==1485)]
    entries.append({'code':code,'proposed_name':None if 'second_half' in code else re.sub(r'\.s7a\d+\.', '.',code),'disposition':'delete_unused_placeholder' if 'second_half' in code else 'rename_candidate','production_status':'unused_placeholder_helper' if 'second_half' in code else 'declared_without_active_producer' if code in inactive else 'active_producer','symbol':symbol,'definition':definitions.get(code),'publicity':'registered_public' if pub else 'explicit_src_only' if code in pending else 'unregistered_internal','category':category,'category_evidence':cat_evidence,'category_table':pub.get('category') if pub else None,'severity':'error','severity_basis':'source_codes.hpp kErrorSeverity / producer Diagnostic or dynamic error helpers; registered table corroborates public codes; for unused declarations this is intended severity only','faulted':'session_faulted' if code.endswith('kernel.transaction_failed') else 'session_unaffected','producers':producers,'dynamic_construction':drefs,'consumer_references':[r for r in refs if r['path'].startswith(('engine/playback/','cmake/','tools/')) or ('execution_kernel.cpp' in r['path'] and r['kind']=='literal')],'serialization_digest_impact':carrier,'test_references':[r for r in refs if r['path'].startswith('tests/')],'contract_references':[r for r in refs if r['path'].startswith(('docs/','schemas/'))],'references':refs,'historical_category':oldentries.get(code,{}).get('category')})
targets=collections.defaultdict(list)
for e in entries:
    if e['proposed_name']:targets[e['proposed_name']].append(e['code'])
other_active_strings=set()
for p,t in texts.items():
    if p.startswith(('engine/','tools/','app/')) and Path(p).suffix in {'.cpp','.hpp'}:other_active_strings.update(re.findall(r'"([a-z][a-z0-9_-]*(?:\.[a-z0-9_-]+)+)"',strip_comments(t)))
collisions={k:v for k,v in targets.items() if len(v)>1 or k in other_active_strings}
old=set(oldentries); summary={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'historical_head':history['baseline'],'count':len(entries),'migration_candidates':sum(e['disposition']=='rename_candidate' for e in entries),'unused_placeholders':sum(e['disposition']=='delete_unused_placeholder' for e in entries),'family_counts':dict(collections.Counter(e['code'].split('.')[1] for e in entries)),'publicity_counts':dict(collections.Counter(e['publicity'] for e in entries)),'production_status_counts':dict(collections.Counter(e['production_status'] for e in entries)),'added':sorted(current-old),'removed':sorted(old-current),'target_collisions':collisions,'category_unresolved':[e['code'] for e in entries if not e['category']],'multi_category_codes':{e['code']:e['category'] for e in entries if isinstance(e['category'],list) and len(e['category'])>1},'historical_zip_sha256':hashlib.sha256(ZIP.read_bytes()).hexdigest(),'text_files_scanned':len(texts),'coverage':'Git tracked and nonignored working-tree text paths engine/app/tools/tests/schemas/cmake/docs; C++ comments excluded for active definition discovery; constant and two dynamic stage prefix generators audited; static read-only evidence, no build/runtime verification.'}
shared_refs=[]
for p,t in texts.items():
    if p in {'engine/judgement/src/recovery.cpp','engine/judgement/src/recovery_wire.hpp','engine/judgement/src/recovery_codec.cpp'}:
        for m in re.finditer(r'\bsameError\b|\bfaultDiagnostic\b|std::is_same_v<T, core::Error>|\bdigest\(',t):shared_refs.append(ref(p,m.start(),'shared_error_carrier',m[0]))
    if p in {'engine/judgement/src/execution_kernel.cpp','engine/judgement/src/execution_profile.cpp'}:
        for m in re.finditer(re.escape('"judgement.s7a4." + std::string{suffix}'),t):shared_refs.append(ref(p,m.start(),'dynamic_prefix',m[0]))
result={'summary':summary,'shared_serialization_digest_references':shared_refs,'entries':entries}
(OUT/'inventory.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
with (OUT/'inventory.csv').open('w',newline='',encoding='utf-8-sig') as f:
    keys=['code','proposed_name','disposition','production_status','symbol','publicity','category','severity','faulted','definition','producers','dynamic_construction','consumer_references','serialization_digest_impact','test_references','contract_references']
    w=csv.DictWriter(f,fieldnames=keys);w.writeheader()
    for e in entries:w.writerow({k:json.dumps(e[k],ensure_ascii=False) if isinstance(e[k],(dict,list)) else e[k] for k in keys})
(OUT/'scanned-files.txt').write_text('\n'.join(texts),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=True,indent=2))
