import os
from pathlib import Path
import subprocess
import sys
import time
ROOT = Path('D:/Cuexis-worktree')
BASE = Path(__file__).resolve().parent
BUILD = ROOT / 'out/build/r4/owning-20261107/normal-release-v2'
sys.path.insert(0, str(ROOT))
from tools.verification.execution_acceptance.binding import artifact, write_once

output = BASE / 'static-checks'
output.mkdir(exist_ok=False)
environment = os.environ.copy()
setup = BASE / 'build-normal-release-v2/developer-environment.cmd'
for line in subprocess.check_output(['cmd.exe', '/d', '/c', str(setup)]).decode('utf-8', errors='replace').splitlines():
    if '=' in line:
        key, value = line.split('=', 1)
        if key:
            environment[key] = value
environment.update(VCPKG_ROOT='D:/vcpkg', VSLANG='1033', HTTPS_PROXY='http://127.0.0.1:7890',
                   HTTP_PROXY='http://127.0.0.1:7890', ALL_PROXY='http://127.0.0.1:7890', NO_PROXY='')
commands = [
    ('architecture-version', ['ctest', '--test-dir', str(BUILD), '--no-tests=error', '--output-on-failure',
                              '-R', 'cuexis_architecture|cuexis_version']),
    ('format', ['cmake', '--build', str(BUILD), '--target', 'cuexis_format_check']),
    ('python-tools', [sys.executable, '-B', '-m', 'unittest', 'discover', '-s',
                     'tools/verification/execution_acceptance', '-t', '.', '-p', 'test_*.py']),
    ('version', [sys.executable, '-B', 'tools/update_version.py', '--check']),
    ('documentation', [sys.executable, '-B', 'tools/check_docs.py']),
    ('diff', ['git', 'diff', '--check'])]
results = []
for name, command in commands:
    log = output / (name + '.log')
    started = time.monotonic()
    with log.open('xb') as stream:
        process = subprocess.run(command, cwd=ROOT, env=environment, stdout=stream,
                                 stderr=subprocess.STDOUT, timeout=300)
    row = {'check': name, 'command': command, 'exit_code': process.returncode,
           'elapsed_seconds': time.monotonic()-started, 'log': artifact(log)}
    write_once(output / (name + '.json'), row)
    results.append(row)
    process.check_returncode()
    print(name, 'passed', flush=True)
write_once(output / 'summary.json', results)
