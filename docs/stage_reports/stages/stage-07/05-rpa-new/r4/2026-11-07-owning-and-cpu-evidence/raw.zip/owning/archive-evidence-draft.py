"""Package completed evidence without launching or modifying a workload."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path('D:/Cuexis-worktree')
BASE = ROOT / 'out/evidence/r4/owning-20261107'
DEST = ROOT / 'out/evidence/r4/archive-staged-20261107-v6/2026-11-07-owning-and-cpu-evidence'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    if not (BASE / 'cpu-formal-run1/result.json').is_file():
        raise ValueError('complete CPU result required before packaging')
    DEST.mkdir(parents=True, exist_ok=False)
    members = {}
    for path in sorted(BASE.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            members['owning/' + path.relative_to(BASE).as_posix()] = path.read_bytes()
    read_cost = ROOT / 'out/evidence/r4/read-cost-20261107'
    for path in sorted(read_cost.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            members['read-cost/' + path.relative_to(read_cost).as_posix()] = path.read_bytes()
    matrix = ROOT / 'out/evidence/r4/final-20261107/20261107-130847-66b527cb'
    for path in sorted(matrix.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            members['matrix/' + path.relative_to(matrix).as_posix()] = path.read_bytes()
    for name, path in {
        'reports/report-draft.md': BASE / 'report-draft.md',
        'reports/o2-checklist-draft.md': BASE / 'o2-checklist-draft.md',
        'reports/f4-inventory-draft.md': BASE / 'f4-inventory-draft.md',
        'reports/read-failure-disposition-draft.md': BASE / 'read-failure-disposition-draft.md',
        'reports/reviews.json': BASE / 'reviews.json',
        'reports/object-code-review.json': BASE / 'object-code-review.json',
    }.items():
        members[name] = path.read_bytes()
    extra = {
        'tools/measurement.py': ROOT / 'tools/verification/playback_performance/measurement.py',
        'tools/results.py': ROOT / 'tools/verification/execution_acceptance/results.py',
        'tools/semantic_memory.py': ROOT / 'tools/verification/execution_acceptance/semantic_memory.py',
        'budget.json': ROOT / 'tools/verification/execution_acceptance/budget-proposal.v1.json',
        'o1-acceptance.json': ROOT / 'docs/stage_reports/stages/stage-07/05-rpa-new/r4/2026-11-05-o1-budget-acceptance.json',
        'execution-authorization.json': ROOT / 'docs/stage_reports/stages/stage-07/05-rpa-new/r4/2026-11-05-execution-authorization.json',
        'baseline/build-binding.json': ROOT / 'out/evidence/r4/post-o1/baseline-english-rebuild/cuexis_pd_baseline_probe-build-binding.json',
    }
    for unit in ('p0-legacy-release', 'p0-rpa-release'):
        for name in ('attempt-1.json', 'attempt-1.seal.json'):
            extra['ledger/' + unit + '/' + name] = ROOT / 'out/evidence/r4/attempt-ledger' / unit / name
    for name, path in extra.items():
        members[name] = path.read_bytes()
    staged_docs = ROOT / 'out/evidence/r4/docs-staged-20261107/docs'
    for path in sorted(staged_docs.rglob('*')):
        if path.is_file():
            members['docs/' + path.relative_to(staged_docs).as_posix()] = path.read_bytes()
    members['index.md'] = b'''# 2026-11-07 R4 Evidence Archive

Status: candidate C evidence bundle; not final acceptance.

Candidate SHA `24f0a914f306cbc20e05b1dccc9f82dac59a6024`, tree `0bc59434103671b403ffd3bebc77a3df2fee493a`, date build `26.11.07-1`, SDK `0.9.1`.

`raw.zip` includes owning diagnostics, allocator contract logs, 36 sealed P0 samples and warmups, immutable claims, all 11 local matrix rows, hosted run records, isolated read prototype build/correctness/object-code/diagnostic evidence, staged reports and review records. `manifest.json` binds each member's byte count and SHA-256 and the ZIP hash. `verify.py` checks members, reparses the 36 P0 samples, recomputes the six verdicts and memory deduplication, checks matrix and diagnostic dispositions, and verifies hosted SHAs without launching a native process.

Run `python -B verify.py` from this directory. Memory/P8 remain unadmitted, 40K was not run, and the formal read_long failures remain. This archive does not record O2/O3 owner acceptance.
'''
    with zipfile.ZipFile(DEST / 'raw.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for name, raw in sorted(members.items()):
            bundle.writestr(name, raw)
    manifest = {
        'schema': 'rpa.execution.owning-and-cpu-evidence.v1',
        'source_sha': '24f0a914f306cbc20e05b1dccc9f82dac59a6024',
        'source_tree': '0bc59434103671b403ffd3bebc77a3df2fee493a',
        'build_version': '26.11.07-1',
        'archive_sha256': digest((DEST / 'raw.zip').read_bytes()),
        'files': {name: {'bytes': len(raw), 'sha256': digest(raw)} for name, raw in sorted(members.items())},
        'native_processes_launched_by_packager': 0,
        'complete_memory_graph': False,
        'memory_formal_admitted': False,
        'p8_run': False,
    }
    (DEST / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    (DEST / 'verify.py').write_bytes((BASE / 'verify-archive-draft.py').read_bytes())
    print(json.dumps({'directory': str(DEST), 'members': len(members),
                     'compressed_bytes': (DEST / 'raw.zip').stat().st_size}, indent=2))


if __name__ == '__main__':
    main()
