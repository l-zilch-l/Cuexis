"""At most two preregistered single-variable rounds; never claims or replaces formal samples."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('D:/Cuexis-worktree')
sys.path.insert(0, str(ROOT))
from tools.verification.execution_acceptance import build_binding
from tools.verification.execution_acceptance.binding import artifact, clean_source, read, sha256, verify_artifact, write_once
from tools.verification.execution_acceptance.environment import capture_cpu, verify_cpu, verify_native, verify_warmup
from tools.verification.execution_acceptance.runtime_monitor import RuntimeMonitor, POLICY
from tools.verification.playback_performance import measurement, process_control

BASE = ROOT / 'out/evidence/r4/owning-20261107'
OUTPUT = ROOT / 'out/evidence/r4/read-cost-20261107/diagnostic-v2'
SOURCES = {'control': ROOT, 'prototype': ROOT / 'out/sources/r4/read-cost-20261107'}
BUILD_FILES = {
    'control': BASE / 'build-normal-release-v2/cuexis_pd_baseline_probe-build-binding.json',
    'prototype': ROOT / 'out/evidence/r4/read-cost-20261107/build-prototype-release-v1/cuexis_pd_baseline_probe-build-binding.json',
}
MATRIX = ROOT / 'out/evidence/r4/final-20261107/20261107-130847-66b527cb/manifest.json'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def run():
    plan = read(BASE / 'read-cost-diagnostic-plan.json')
    matrix = read(MATRIX)
    require('source_after' in matrix and len(matrix['rows']) == 11 and matrix['source_unchanged'],
            'complete unchanged-source matrix required before diagnostic')
    require(all(row['status'] == 'local_pass' for row in matrix['rows']),
            'resolve matrix failures before diagnostic')
    for side in SOURCES:
        require(clean_source(SOURCES[side])['sha'] == plan[side + '_sha'], 'source differs')
    sources = {side: clean_source(path) for side, path in SOURCES.items()}
    builds = {side: read(path) for side, path in BUILD_FILES.items()}
    for side, binding in builds.items():
        build_binding.verify(binding, sources[side], 'normal')
        require(binding['config'] == 'Release', 'Release required')
    require(builds['control']['toolchain_signature'] == builds['prototype']['toolchain_signature'] and
            builds['control']['options'] == builds['prototype']['options'], 'A/B build options differ')
    correctness = read(ROOT / 'out/evidence/r4/read-cost-20261107/correctness/summary.json')
    require(correctness['source_sha'] == sources['prototype']['sha'] and correctness['all_exit_zero'],
            'prototype correctness is not qualified')
    environment = capture_cpu()
    environment['foreground_policy'] = 'fixed-existing-foreground'
    affinity = environment['topology']['candidate_masks'][0]
    OUTPUT.mkdir(parents=True, exist_ok=False)
    write_once(OUTPUT / 'registration.json', {'schema': 'rpa.execution.read-cost-diagnostic.v1',
        'plan': artifact(BASE / 'read-cost-diagnostic-plan.json'), 'controller': artifact(__file__),
        'source': sources, 'builds': {side: artifact(path) for side, path in BUILD_FILES.items()},
        'matrix': artifact(MATRIX), 'correctness': correctness, 'cpu_environment': environment,
        'affinity': affinity, 'runtime_monitor_policy': POLICY, 'formal_sampling': False,
        'maximum_rounds': 2, 'maximum_measured_processes': 8, 'maximum_warmup_processes': 8})
    native, references, results = None, {}, []
    try:
        for round_index, order in enumerate(plan['round_orders'], 1):
            values = {}
            for position, item in enumerate(order, 1):
                profile, side = item.split('-')
                directory = OUTPUT / f'round-{round_index}' / f'{position}-{item}'
                directory.mkdir(parents=True, exist_ok=False)
                require(clean_source(SOURCES[side]) == sources[side], 'source changed')
                binary = verify_artifact(builds[side]['binary'])
                write_once(directory / 'environment-before.json', verify_cpu(environment))
                env = {key: value for key, value in os.environ.items()
                       if not key.startswith(('CUEXIS_PD_', 'CUEXIS_PD5_', 'CUEXIS_REDESIGN_'))}
                env.update(CUEXIS_PD_PROFILE=profile, CUEXIS_PD_FORMAL_PHASE='pilot', CUEXIS_PD_V2_READS='1048576')
                commands = [('warmup', [str(binary), 'PD machine CPU warmup', '--rng-seed', '1']),
                            ('sample', [str(binary), 'PD uninstrumented validated fixed workload', '--rng-seed', '1'])]
                for phase, command in commands:
                    log = directory / (phase + '.log')
                    monitor = RuntimeMonitor(environment['foreground_pid'], timeout=125)
                    started = time.monotonic()
                    try:
                        with log.open('xb') as stream, monitor:
                            process = process_control.run(command, affinity, cwd=ROOT, env=env,
                                                          output=stream, timeout=120)
                    finally:
                        monitored = monitor.result()
                        write_once(directory / (phase + '-runtime-environment.json'), monitored)
                    write_once(directory / (phase + '.json'), {'command': command,
                        'exit_code': process.returncode, 'elapsed_seconds': time.monotonic() - started,
                        'log': artifact(log)})
                    require(process.returncode == 0 and monitored['passed'], 'process/environment failed; no replacement')
                    raw = log.read_text(encoding='utf-8')
                    if phase == 'warmup':
                        verify_warmup(raw)
                native = verify_native(raw, affinity, native)
                parsed = measurement.parse_owner(raw, phase='pilot')
                rows = [row for row in parsed['samples'] if row['kind'] == 'read_long']
                require(len(rows) == 3 and all(row['operations'] == 1048576 and row['sample']['wall_us'] >= 100000
                                              for row in rows), 'fixed blocks differ')
                if profile in references:
                    for metric in ('validated_trace', 'playback_only', 'read_long'):
                        measurement.require_comparable(references[profile], parsed, metric)
                else:
                    references[profile] = parsed
                medians = parsed['statistics']['read_long']['median_us']
                noise = measurement.noise([row['sample']['wall_us'] / row['operations'] for row in rows])
                values.setdefault(profile, {})[side] = {'median_us': medians, 'noise': noise}
                write_once(directory / 'parsed.json', parsed)
                write_once(directory / 'environment-after.json', verify_cpu(environment))
                require(clean_source(SOURCES[side]) == sources[side] and
                        sha256(binary) == builds[side]['binary']['sha256'], 'source/binary changed')
                print(f'round {round_index} {item} complete', flush=True)
            result = {profile: {'prototype_control_ratio': sides['prototype']['median_us'] / sides['control']['median_us'],
                               'processes': sides} for profile, sides in values.items()}
            passed = all(value['prototype_control_ratio'] <= .95 and
                         all(side['noise'] <= .15 for side in value['processes'].values()) for value in result.values())
            row = {'round': round_index, 'results': result, 'fixed_effect_and_noise_conditions_met': passed}
            results.append(row)
            write_once(OUTPUT / f'round-{round_index}-result.json', row)
            if not passed:
                break
        write_once(OUTPUT / 'disposition.json', {'rounds': results, 'rounds_consumed': len(results),
            'bounded_effect_qualified': len(results) == 2 and all(row['fixed_effect_and_noise_conditions_met'] for row in results),
            'formal_claims_consumed': 0, 'formal_success': False, 'no_extra_capacity_processes': True})
    except Exception as error:
        write_once(OUTPUT / 'stopped.json', {'error': str(error), 'partial_completed_rounds': results,
                                           'no_replacement': True})
        raise


if __name__ == '__main__':
    run()
