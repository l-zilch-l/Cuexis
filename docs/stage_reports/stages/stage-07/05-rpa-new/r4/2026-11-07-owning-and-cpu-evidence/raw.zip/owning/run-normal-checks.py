import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('D:/Cuexis-worktree')
BASE = Path(__file__).resolve().parent
BUILD = ROOT / 'out/build/r4/owning-20261107/normal-release-v2'
sys.path.insert(0, str(ROOT))
from tools.verification.execution_acceptance.binding import artifact, clean_source, write_once

output = BASE / 'normal-checks'
output.mkdir(exist_ok=False)
source = clean_source(ROOT)
environment = os.environ.copy()
for key in list(environment):
    if key.startswith(('CUEXIS_PD_', 'CUEXIS_PD5_', 'CUEXIS_REDESIGN_')):
        del environment[key]
write_once(output / 'registration.json', {'source_sha': source['sha'],
    'scope': 'Unfiltered World/Runtime/Playback ordinary Release correctness executables; no performance workload.',
    'formal_sampling': False, 'binary_names': ['cuexis_world_tests', 'cuexis_runtime_tests', 'cuexis_playback_tests'],
    'maximum_seconds_each': 300, 'controller': artifact(__file__)})
results = []
for name in ('cuexis_world_tests', 'cuexis_runtime_tests', 'cuexis_playback_tests'):
    binary = artifact(BUILD / 'bin' / (name + '.exe'))
    command = [binary['path'], '--reporter', 'compact', '--rng-seed', '1']
    log = output / (name + '.log')
    started = time.monotonic()
    with log.open('xb') as stream:
        process = subprocess.run(command, cwd=ROOT, env=environment, stdout=stream,
                                 stderr=subprocess.STDOUT, timeout=300)
    row = {'command': command, 'exit_code': process.returncode, 'binary': binary,
           'elapsed_seconds': time.monotonic() - started, 'log': artifact(log)}
    write_once(output / (name + '.json'), row)
    results.append(row)
    process.check_returncode()
    print(name, 'passed', flush=True)
if clean_source(ROOT) != source:
    raise ValueError('source changed during correctness checks')
write_once(output / 'summary.json', {'source_sha': source['sha'], 'results': results,
    'all_exit_zero': True, 'formal_sampling': False})
