import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('D:/Cuexis-worktree')
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from tools.verification.execution_acceptance.binding import (
    accepted_budget, artifact, clean_source, read, sha256, write_once)
from tools.verification.execution_acceptance.build_binding import verify
from tools.verification.execution_acceptance.semantic_memory import analyze_workflow, collect


def qualified():
    source = clean_source(ROOT)
    authorization = read(BASE / 'coverage-plan.json')
    if source['sha'] != authorization['source_sha'] or source['tree'] != authorization['source_tree']:
        raise ValueError('coverage candidate changed')
    binding = read(BASE / 'build-memory-v1/cuexis_pd_host_probe-build-binding.json')
    verify(binding, source, 'memory')
    return source, binding


def contracts():
    source, binding = qualified()
    cases = [
        ('positive', 'Execution observer*,Execution semantic roots*,Execution semantic census*,Execution semantic buffer*'),
        ('unknown-root', 'Execution semantic observer rejects an unregistered owner'),
        ('root-capacity', 'Execution semantic observer rejects root table exhaustion'),
        ('page-overrun', 'Execution semantic observer rejects a page span beyond its backing allocation')]
    output = BASE / 'contracts'
    output.mkdir(exist_ok=False)
    write_once(output / 'registration.json', {'capacity_workflow': False, 'cases': cases,
        'maximum_processes': 4, 'timeout_per_process_seconds': 120,
        'source_sha': source['sha'], 'binary': binding['binary'], 'controller': artifact(__file__)})
    results = []
    for name, case in cases:
        command = [binding['binary']['path'], case, '--reporter', 'compact', '--rng-seed', '1']
        log = output / (name + '.log')
        started = time.monotonic()
        with log.open('xb') as stream:
            process = subprocess.run(command, cwd=ROOT, stdout=stream,
                                     stderr=subprocess.STDOUT, timeout=120)
        row = {'name': name, 'exit_code': process.returncode,
               'elapsed_seconds': time.monotonic() - started, 'log': artifact(log)}
        write_once(output / (name + '.json'), row)
        results.append(row)
        process.check_returncode()
    text = (output / 'positive.log').read_text(encoding='utf-8')
    proofs = collect(text)['censuses']
    totals = [row['proof']['lower_bound_requested_cpp_bytes'] for row in proofs]
    if len(proofs) != 5 or totals[:2] != [12841, 8192] or totals[-2:] != [161, 0]:
        raise ValueError('aligned/alias/string swap proofs differ: ' + str(totals))
    typed = [span['kind'] for row in proofs for span in row['spans']]
    if 'material_string' not in typed or 'transform_order' not in typed:
        raise ValueError('new typed contracts absent')
    if clean_source(ROOT) != source:
        raise ValueError('source changed during qualification')
    write_once(output / 'summary.json', {'source_sha': source['sha'], 'results': results,
        'proof_totals': totals, 'capacity_processes_used': 0})
    print(json.dumps({'contracts': 'passed', 'proof_totals': totals}, indent=2), flush=True)


def workflow(reuse):
    source, binding = qualified()
    qualification = read(BASE / 'contracts/summary.json')
    if qualification['source_sha'] != source['sha'] or any(row['exit_code'] for row in qualification['results']):
        raise ValueError('observer contracts are not qualified')
    prior = BASE / '64-high'
    if reuse == 'low':
        if not (prior / 'analysis.json').is_file() or read(prior / 'analysis.json')['rating']['failures']:
            raise ValueError('second process requires valid non-failing first process')
    budget_file = ROOT / 'tools/verification/execution_acceptance/budget-proposal.v1.json'
    acceptance_file = ROOT / 'docs/stage_reports/stages/stage-07/05-rpa-new/r4/2026-11-05-o1-budget-acceptance.json'
    budget = accepted_budget(artifact(acceptance_file), artifact(budget_file))
    profile = next(row for row in budget['profiles'] if row['id'] == 'r4-reference-n64-v1')
    output = BASE / ('64-' + reuse)
    output.mkdir(exist_ok=False)
    env = {key: value for key, value in os.environ.items() if not key.startswith('CUEXIS_PD5_')}
    workload = {'CUEXIS_PD5_ENTITIES': '64', 'CUEXIS_PD5_REUSE': reuse,
                'CUEXIS_PD5_CAPSULE_REVISION': '3'}
    env.update(workload)
    command = [binding['binary']['path'], 'PD5 full content Snapshot Seek Replay boundary',
               '--reporter', 'compact', '--rng-seed', '1']
    write_once(output / 'registration.json', {'schema': 'rpa.execution.owning-coverage.v1',
        'source_sha': source['sha'], 'source_tree': source['tree'],
        'source': artifact(BASE / 'build-memory-v1/source.json'),
        'build': artifact(BASE / 'build-memory-v1/cuexis_pd_host_probe-build-binding.json'),
        'controller': artifact(__file__), 'authorization': artifact(BASE / 'coverage-plan.json'),
        'budget': artifact(budget_file), 'o1_acceptance': artifact(acceptance_file),
        'profile': profile['id'], 'binary': binding['binary'], 'command': command,
        'workload_environment': workload, 'timeout_seconds': 120, 'maximum_processes': 1,
        'formal_sampling': False, 'p8': False, 'entities_40000': False,
        'change_under_test': 'Wider typed owning census, no product storage optimization beyond accepted page_size=128.',
        'non_comparability': 'Coverage is wider than the previous three-page witness; do not treat the change in lower bounds as a product regression.',
        'stop': ['process/tool/budget failure retains raw evidence and stops further capacity processes',
                 'low may run only after valid high with no proven over-budget result',
                 'at most these two N64 processes; never auto-admit formal memory/P8']})
    started, timed_out, code = time.monotonic(), False, None
    with (output / 'stdout.log').open('xb') as stdout, (output / 'stderr.log').open('xb') as stderr:
        try:
            code = subprocess.run(command, cwd=ROOT, env=env, stdout=stdout, stderr=stderr,
                                  timeout=120).returncode
        except subprocess.TimeoutExpired:
            timed_out = True
    write_once(output / 'process-result.json', {'source_sha': source['sha'], 'exit_code': code,
        'timed_out': timed_out, 'elapsed_seconds': time.monotonic() - started,
        'stdout': artifact(output / 'stdout.log'), 'stderr': artifact(output / 'stderr.log'),
        'formal_attempts_consumed': 0, 'p8_attempts_consumed': 0})
    if code != 0 or timed_out:
        raise ValueError('capacity process failed; no replacement')
    if clean_source(ROOT) != source or sha256(binding['binary']['path']) != binding['binary']['sha256']:
        raise ValueError('source/binary changed during capacity process')
    try:
        analysis = analyze_workflow((output / 'stdout.log').read_text(encoding='utf-8'), profile)
    except Exception as error:
        write_once(output / 'tool-invalid.json', {'error': str(error)})
        raise
    write_once(output / 'analysis.json', analysis)
    active = next(row for row in analysis['proofs']['censuses'] if row['proof']['phase'] == 'active')
    observed = sorted({span['kind'] for span in active['spans']})
    if not {'world_object', 'transform_cache', 'transform_order', 'appearance_page',
            'camera_page', 'world_transform_page'}.issubset(observed):
        raise ValueError('expected coverage absent from active proof: ' + str(observed))
    write_once(output / 'coverage.json', {'source_sha': source['sha'], 'active_proof': active['proof'],
        'observed_categories': observed, 'observed_span_count': len(active['spans']),
        'complete_world_graph': False, 'formal_acceptance': False,
        'unknown': ['EnTT unvisited constructor/private sparse and page directories',
                    'World TransformUpdate scratch and runtime transform transaction storage',
                    'Runtime ObjectEntityMap and other semantic domains',
                    'cross-domain shared ownership, prepare peaks, native/GPU/driver and observer perturbation']})
    print(json.dumps({'reuse': reuse, 'proof': active['proof'], 'observed_categories': observed,
                      'rating': analysis['rating']}, indent=2), flush=True)


if __name__ == '__main__':
    if sys.argv[1] == 'contracts':
        contracts()
    elif sys.argv[1] in ('high', 'low'):
        workflow(sys.argv[1])
    else:
        raise ValueError('unknown action')
