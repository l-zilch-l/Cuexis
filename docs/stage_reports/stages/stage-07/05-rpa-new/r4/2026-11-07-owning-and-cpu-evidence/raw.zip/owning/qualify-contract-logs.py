import sys
from pathlib import Path
ROOT = Path('D:/Cuexis-worktree')
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from tools.verification.execution_acceptance.binding import artifact, clean_source, read, verify_artifact, write_once
from tools.verification.execution_acceptance.semantic_memory import collect

source = clean_source(ROOT)
output = BASE / 'contracts'
results = [read(output / (name + '.json')) for name in
           ('positive', 'unknown-root', 'root-capacity', 'page-overrun')]
for result in results:
    verify_artifact(result['log'])
    if result['exit_code']:
        raise ValueError('native contract did not pass')
text = (output / 'positive.log').read_text(encoding='utf-8')
proofs = collect(text)['censuses']
totals = [row['proof']['lower_bound_requested_cpp_bytes'] for row in proofs]
if len(proofs) != 5 or not {0, 12841, 8192}.issubset(totals):
    raise ValueError('base contracts absent')
strings = [row for row in proofs if len(row['spans']) == 1 and
           row['spans'][0].get('kind') == 'material_string']
if len(strings) != 1 or strings[0]['proof']['lower_bound_requested_cpp_bytes'] < 161:
    raise ValueError('string-owning census absent')
swap = strings[0]
empty = next(row for row in proofs if row['proof']['census_id'] == swap['proof']['census_id'] + 1)
if empty['proof']['root_id'] != swap['proof']['root_id'] or empty['proof']['live_count'] != 0:
    raise ValueError('swapped-out allocation still charged')
buffers = [row for row in proofs if {span.get('kind') for span in row['spans']} ==
           {'material_string', 'transform_order'}]
if len(buffers) != 1 or 'All tests passed' not in text:
    raise ValueError('typed buffer contracts absent')
write_once(output / 'controller-invalid.json', {
    'native_contracts_exit_zero': True, 'capacity_processes_started': 0,
    'error': 'Controller assumed Catch2 test order despite --rng-seed=1; native cases all passed. The source collector assigned monotonic census IDs correctly.',
    'native_proof_totals_in_execution_order': totals,
    'remedy': 'Parse the existing raw logs by root/census/kind identity without relaunching contracts.',
    'readonly_verifier': artifact(__file__)})
write_once(output / 'summary.json', {'source_sha': source['sha'], 'results': results,
    'proof_totals': totals, 'capacity_processes_used': 0,
    'native_contracts_repeated': False, 'qualification_method': artifact(__file__)})
print('Qualified all four original native contract processes from their raw logs; no process repeated.')
