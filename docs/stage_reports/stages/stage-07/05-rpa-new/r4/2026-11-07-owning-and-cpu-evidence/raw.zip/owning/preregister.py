import subprocess
import sys
from pathlib import Path
ROOT = Path('D:/Cuexis-worktree')
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from tools.verification.execution_acceptance.binding import artifact, write_once
def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT).decode().strip()
if git('status', '--porcelain', '--untracked-files=all'):
    raise ValueError('clean source required')
write_once(BASE / 'coverage-plan.json', {
    'schema': 'rpa.execution.owning-coverage-plan.v1', 'date': '2026-11-07',
    'owner_instruction': '你继续进行剩余工作，在下一次推送前更新version',
    'source_sha': git('rev-parse', 'HEAD'), 'source_tree': git('rev-parse', 'HEAD^{tree}'),
    'build_version': '26.11.07-1', 'sdk_api': '0.9.1',
    'diagnostic_issue': 'Close missing actual World buffer/type coverage before memory admission; this is a wider lower-bound witness, not a repeat effectiveness measurement.',
    'maximum_capacity_processes': 2, 'workloads_in_order': ['64/high', '64/low'],
    'timeout_seconds_each': 120, 'second_process_requires_valid_non_over_budget_first': True,
    'contracts': {'maximum_processes': 4, 'timeout_seconds_each': 120, 'capacity_workflow': False},
    'formal_sampling': False, 'p8_authorized': False, 'entities_40000_authorized': False,
    'budget_changed': False, 'controller': artifact(BASE / 'run-census.py'),
    'stop': ['no process replacement, keep all raw failures', 'no third capacity process in this issue batch',
             'partial coverage cannot produce a formal memory pass', 'no P8 before independent admission']})
print('Coverage diagnostic preregistered before capacity execution.')
