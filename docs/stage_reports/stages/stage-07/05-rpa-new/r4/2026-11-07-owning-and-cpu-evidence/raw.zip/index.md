# 2026-11-07 R4 Evidence Archive

Status: candidate C evidence bundle; not final acceptance.

Candidate SHA `24f0a914f306cbc20e05b1dccc9f82dac59a6024`, tree `0bc59434103671b403ffd3bebc77a3df2fee493a`, date build `26.11.07-1`, SDK `0.9.1`.

`raw.zip` includes owning diagnostics, allocator contract logs, 36 sealed P0 samples and warmups, immutable claims, all 11 local matrix rows, hosted run records, isolated read prototype build/correctness/object-code/diagnostic evidence, staged reports and review records. `manifest.json` binds each member's byte count and SHA-256 and the ZIP hash. `verify.py` checks members, reparses the 36 P0 samples, recomputes the six verdicts and memory deduplication, checks matrix and diagnostic dispositions, and verifies hosted SHAs without launching a native process.

Run `python -B verify.py` from this directory. Memory/P8 remain unadmitted, 40K was not run, and the formal read_long failures remain. This archive does not record O2/O3 owner acceptance.
