import sys
from pathlib import Path
ROOT = Path('D:/Cuexis-worktree')
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from tools.verification.execution_acceptance import admission
from tools.verification.execution_acceptance.binding import artifact, read, write_once

preparation = BASE / 'cpu-pilot-v1/preparation.json'
document = admission.validate_preparation(read(preparation))
write_once(BASE / 'cpu-formal-declaration.json', {
    'schema': 'rpa.execution.cpu-formal-declaration.v1',
    'source_sha': document['source_binding']['sha'],
    'baseline_sha': document['baseline_sha'],
    'preparation': artifact(preparation), 'controller': artifact(__file__),
    'units': [unit['id'] for unit in document['units']],
    'maximum_measured_processes': 36, 'warmup_processes': 36,
    'windows': 3, 'pairs_per_unit_per_window': 3, 'gap_seconds': 600,
    'immutable_orders': document['orders'],
    'scope': 'Release CPU owner fixed traces only. Relative cost/repeatability; eight block-level samples cannot certify p99 endpoint budgets.',
    'no_builds_or_tests_during_sampling': True,
    'failure_policy': 'Keep first failure and partial results, no sample replacement or automatic new registration.',
    'memory_p8_device_admitted': False})
claims = admission.claim(document, document['attempt_ledger'])
admission.seal(preparation, claims, BASE / 'cpu-formal.seal.json')
print('Claimed and sealed first fixed formal CPU groups:', [unit['id'] for unit in document['units']], flush=True)
