from pathlib import Path
import sys
ROOT = Path('D:/Cuexis-worktree')
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from tools.verification.execution_acceptance.binding import artifact, read, write_once

old = (BASE / 'run-census.py').read_text(encoding='utf-8')
old_check = "if len(proofs) != 5 or totals[:2] != [12841, 8192] or totals[-2:] != [161, 0]:"
new_check = "if len(proofs) != 5 or totals[:2] != [12841, 8192] or totals[-1] != 0 or totals[-2] < 161:"
if old_check not in old:
    raise ValueError('controller amendment target absent')
new = old.replace(old_check, new_check).replace("BASE / 'coverage-plan.json'", "BASE / 'coverage-plan-v2.json'")
with (BASE / 'run-census-v2.py').open('x', encoding='utf-8') as stream:
    stream.write(new)
plan = read(BASE / 'coverage-plan.json')
plan.update(controller=artifact(BASE / 'run-census-v2.py'),
            supersedes_plan=artifact(BASE / 'coverage-plan.json'),
            amendment_reason='Before any contract/capacity execution: string capacity may exceed length on MSVC; do not assert length+1 as allocator request. Check actual span proof and disappearance instead.',
            capacity_processes_launched_before_amendment=0)
write_once(BASE / 'coverage-plan-v2.json', plan)
print('Preserved original preregistration; corrected only pre-execution controller capacity assumption.')
