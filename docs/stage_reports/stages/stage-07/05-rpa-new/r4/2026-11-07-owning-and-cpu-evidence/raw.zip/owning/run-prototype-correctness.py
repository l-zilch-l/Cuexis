"""Run unfiltered correctness executables for the isolated read-copy prototype."""
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('D:/Cuexis-worktree')
SOURCE = ROOT / 'out/sources/r4/read-cost-20261107'
BUILD = ROOT / 'out/build/r4/read-cost-20261107/prototype-release-v1'
OUTPUT = ROOT / 'out/evidence/r4/read-cost-20261107/correctness'
sys.path.insert(0, str(ROOT))
from tools.verification.execution_acceptance.binding import artifact, clean_source, write_once

source = clean_source(SOURCE)
OUTPUT.mkdir(parents=True, exist_ok=False)
environment = {key: value for key, value in os.environ.items()
               if not key.startswith(('CUEXIS_PD_', 'CUEXIS_PD5_', 'CUEXIS_REDESIGN_'))}
write_once(OUTPUT / 'registration.json', {'source_sha': source['sha'], 'controller': artifact(__file__),
    'scope': 'Unfiltered Runtime and Playback Release correctness; includes original R2 oracle and safety cases.',
    'formal_sampling': False, 'maximum_seconds_each': 300})
results = []
for name in ('cuexis_runtime_tests', 'cuexis_playback_tests'):
    binary = artifact(BUILD / 'bin' / (name + '.exe'))
    command = [binary['path'], '--reporter', 'compact', '--rng-seed', '1']
    log = OUTPUT / (name + '.log')
    started = time.monotonic()
    with log.open('xb') as stream:
        process = subprocess.run(command, cwd=SOURCE, env=environment, stdout=stream,
                                 stderr=subprocess.STDOUT, timeout=300)
    row = {'command': command, 'exit_code': process.returncode, 'binary': binary,
           'elapsed_seconds': time.monotonic() - started, 'log': artifact(log)}
    write_once(OUTPUT / (name + '.json'), row)
    results.append(row)
    process.check_returncode()
    print(log.read_text(encoding='utf-8'), flush=True)
if clean_source(SOURCE) != source:
    raise ValueError('prototype changed during correctness checks')
write_once(OUTPUT / 'summary.json', {'source_sha': source['sha'], 'results': results,
    'all_exit_zero': True, 'formal_sampling': False, 'original_oracle_changed': False})
