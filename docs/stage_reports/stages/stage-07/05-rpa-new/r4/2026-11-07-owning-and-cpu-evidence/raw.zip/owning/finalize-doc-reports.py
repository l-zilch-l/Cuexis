"""Materialize final dated R4 report/decision artifacts from validated raw evidence drafts."""
import json
from pathlib import Path

ROOT = Path('D:/Cuexis-worktree')
BASE = ROOT / 'out/evidence/r4/owning-20261107'
STAGED = ROOT / 'out/evidence/r4/docs-staged-20261107'
REPORT_DIR = STAGED / 'docs/stage_reports/stages/stage-07/05-rpa-new/r4'
ARCHIVE_INDEX = '''# 2026-11-07 R4 Evidence Archive

状态：evidence bundle；candidate C evidence, not final acceptance

日期：2026-11-07

候选 `24f0a914f306cbc20e05b1dccc9f82dac59a6024` / tree
`0bc59434103671b403ffd3bebc77a3df2fee493a`，日期构建 `26.11.07-1`，SDK `0.9.1`。

`raw.zip` 收录原始 owning diagnostics、allocator contract logs、36个CPU正式样本及热身、不可变claims、
11行本地矩阵日志/manifest、所有PR/push CI记录、隔离读取原型构建/正确性/对象码/诊断、O2/F4草案和审查记录。
`manifest.json` 列出每个成员的字节数和SHA-256并绑定ZIP；`verify.py` 只读校验归档成员，重新解析36个CPU样本，
重算六项固定组结论、内存span去重、矩阵状态、诊断停止和hosted SHA，不启动Cuexis进程。

预期验证：`python -B verify.py`。memory/P8仍未准入，正式40K未运行；read_long正式超界保留；此附件不代表O2/O3 owner接受。
'''


def write(relative, content):
    path = STAGED / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding='utf-8')


def main():
    report = (BASE / 'report-draft.md').read_text(encoding='utf-8')
    report = report.replace('只读核验器从475个归档成员', '只读核验器从751个归档成员')
    report = report.replace('## 5. F1/F2 平台与版本门',
                            '## 5. F1/F2 平台与版本门')
    report = report.replace('## 7. O2、F4 与剩余门',
                            '## 7. O2、F4 与剩余门')
    write('docs/stage_reports/stages/stage-07/05-rpa-new/r4/2026-11-07-owning-and-cpu.md', report)

    physical = (BASE / 'o2-checklist-draft.md').read_text(encoding='utf-8')
    write('docs/stage_reports/stages/stage-07/05-rpa-new/r4/2026-11-07-o2-physical-checklist.md', physical)

    handoff = (BASE / 'f4-inventory-draft.md').read_text(encoding='utf-8')
    handoff = handoff.replace('三窗固定组执行中；结果结束后按原 1.10/15% 逐指标填入',
        '首个三窗组已完成：两read_long超界，legacy另两项因重复性inconclusive')
    handoff = handoff.replace('待CPU正式组结束后运行11行fresh/clean-first未过滤矩阵',
        '候选C的11行fresh/clean-first未过滤矩阵已完成')
    handoff = handoff.replace('待CPU正式组结果结束后填入原始统计和逐指标裁定。',
        '三窗组已结束：RPA执行/Playback-only通过、legacy对应项因重复性inconclusive、两read_long超界；详见本轮报告。')
    handoff = handoff.replace('待完整本地矩阵及同SHA hosted结果填入。',
        '候选C的11行本地矩阵和同SHA Linux/MSVC/MinGW push与PR检查均通过；Version Gate因owner审批无效失败，保留。')
    handoff = handoff.replace('逐行记录失败/跳过，源身份前后相同；不能以定向269 cases代替',
        '候选C 11/11 local_pass、13,652项测试注册/0失败；26项skip逐项保留，不能以此替代正式单元')
    handoff = handoff.replace('已推送同一C至PR#32和R4分支，三平台检查执行中',
        '候选C已推送PR#32与R4分支；六个push与三个PR平台run均通过，Version Gate因SDK owner审批无效失败')
    handoff = handoff.replace('本候选CPU组结果待填；其余未取证',
        '本候选CPU组已完成，读取正式门超界；其余工作单元未取证')
    handoff = handoff.replace('日期版本已推进至26.11.07-1',
        '受测候选C日期版本26.11.07-1；报告提交E前已推进工作树版本至26.11.07-2')
    write('docs/stage_reports/stages/stage-07/05-rpa-new/r4/2026-11-07-f4-gate-and-handoff.md', handoff)

    disposition = (BASE / 'read-failure-disposition-draft.md').read_text(encoding='utf-8')
    disposition += '''
## 5. 已执行的单变量诊断

隔离候选`cbcd7fba5271b419c8f28563f69c72984c50e776`在Release正常allocator构建中仅替换完整
PresentationState复制/两个字段读取，保留内部窗口有效性检查、完整版本门及错误语义。两轴代码审查均0发现，
Runtime和Playback完整正确性程序通过。首次控制器在任何Cuexis进程启动前因缺少明确foreground policy停止，
0测量/0热身进程并保留失败；修正后以新登记运行一次。

一轮各profile一对的诊断显示prototype/control：legacy **1.01715**，RPA **1.05562**；read块noise低于1.2%，
但候选都更慢。未满足预登记“两个profile各改善至少5%”条件，因此不运行第二轮、不采用代码、
不消费正式重开额度。该小样本不改变正式结果，也不构成置信区间或完整根因解释。
'''
    write('docs/stage_reports/stages/stage-07/05-rpa-new/r4/2026-11-07-read-long-over-budget-disposition.md', disposition)

    write('docs/stage_reports/stages/stage-07/05-rpa-new/r4/2026-11-07-owning-and-cpu-evidence/index.md', ARCHIVE_INDEX)

    plan = (STAGED / 'docs/stage_plans/active/stage-07/05-rpa-new/r4/plan.md').read_text(encoding='utf-8')
    plan = plan.replace('状态：active；O1 方案 B 已接受；首个固定 CPU 正式组已完成，其他取证与最终接受未完成',
        '状态：active；O1方案B已接受；P0首组完成且read_long超界，11行F1及同SHA hosted已完成，其余证据/接受未完成')
    plan = plan.replace('首个P0 legacy/RPA正式三窗组已结束，读取门超界、部分\nlegacy重复性inconclusive；旧失败保留，不自动补样。',
        '首个P0 legacy/RPA正式三窗组已结束，读取门超界、部分legacy重复性inconclusive；\n隔离单变量首轮未改善而停止。旧失败保留，不自动补样；11行矩阵及三平台CI通过。')
    plan = plan.replace('本轮推进日期构建为26.11.07-1，',
        '本轮推进日期构建为26.11.07-1；下次推送前需按日期版本规则再推进构建号，')
    footer = '''

2026-11-07 技术收尾与未关闭门见
[本轮报告](../../../../../stage_reports/stages/stage-07/05-rpa-new/r4/2026-11-07-owning-and-cpu.md)、
[读取超界处置](../../../../../stage_reports/stages/stage-07/05-rpa-new/r4/2026-11-07-read-long-over-budget-disposition.md)、
[O2实体清单](../../../../../stage_reports/stages/stage-07/05-rpa-new/r4/2026-11-07-o2-physical-checklist.md)及
[F4/PD移交门账](../../../../../stage_reports/stages/stage-07/05-rpa-new/r4/2026-11-07-f4-gate-and-handoff.md)。
正式P0读取失败保留；本地/hosted平台范围仅认证候选24f0a914。memory/P8、其他单元、实体操作、生产目标、
最终退出以及精确SDK owner批准仍未完成。版本批准不是自动豁免项。
'''
    plan = plan.replace(footer, '')
    plan += footer
    (STAGED / 'docs/stage_plans/active/stage-07/05-rpa-new/r4/plan.md').write_text(plan, encoding='utf-8')

    index_path = STAGED / 'docs/stage_reports/stages/stage-07/05-rpa-new/README.md'
    index = index_path.read_text(encoding='utf-8')
    redundant = '''2026-11-07 的扩展 owning 覆盖、固定 CPU 组、平台核验与剩余门见
[本轮报告](r4/2026-11-07-owning-and-cpu.md)及[原始证据和只读复算](r4/2026-11-07-owning-and-cpu-evidence/index.md)。
实体参与和退出准备见[O2操作清单](r4/2026-11-07-o2-physical-checklist.md)与
[F4门账及PD移交](r4/2026-11-07-f4-gate-and-handoff.md)。
'''
    index = index.replace(redundant, '', 1)
    disposition_link = '[读取超界处置](r4/2026-11-07-read-long-over-budget-disposition.md)'
    if '2026-11-07 R4收尾报告：' in index:
        if disposition_link not in index:
            index = index.replace('[O2实体操作]', disposition_link + '、\n[O2实体操作]', 1)
        index_path.write_text(index, encoding='utf-8')
        print(STAGED)
        return
    anchor = '后续 R4 附件和阶段结论由本入口继续导航'
    if anchor not in index:
        anchor = '后续 R4 报告和阶段结论由本入口继续导航'
    position = index.index(anchor)
    links = '''2026-11-07 R4收尾报告：[owning/CPU/矩阵与状态](r4/2026-11-07-owning-and-cpu.md)、
[原始字节及只读复算](r4/2026-11-07-owning-and-cpu-evidence/index.md)、
[读取超界处置](r4/2026-11-07-read-long-over-budget-disposition.md)、
[O2实体操作](r4/2026-11-07-o2-physical-checklist.md)、
[F4/PD移交门账](r4/2026-11-07-f4-gate-and-handoff.md)。
'''
    index_path.write_text(index[:position] + links + index[position:], encoding='utf-8')
    print(STAGED)


if __name__ == '__main__':
    main()
