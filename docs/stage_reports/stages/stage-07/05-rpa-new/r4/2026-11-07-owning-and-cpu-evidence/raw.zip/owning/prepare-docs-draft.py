"""Prepare documentation edits in ignored staging; do not mutate the frozen checkout."""
from pathlib import Path

ROOT = Path('D:/Cuexis-worktree')
BASE = ROOT / 'out/evidence/r4/docs-staged-20261107'
REPORT = '2026-11-07-owning-and-cpu.md'
LINK = 'stage_reports/stages/stage-07/05-rpa-new/r4/' + REPORT


def stage(name, transform):
    path = ROOT / name
    old = path.read_text(encoding='utf-8')
    new = transform(old)
    if new == old:
        raise ValueError('no documentation change: ' + name)
    target = BASE / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(new, encoding='utf-8')


def status(text):
    begin = text.index('- **RPA 当前承接')
    end = text.index('- **R3 已关闭', begin)
    text = text[:begin] + '''- **RPA 当前承接为 R4 集成取证**：R1、R2、R3 已退出，O1 方案 B 的 reference 设计预算保持。
  本轮候选 `24f0a914` 已同步至 PR #32，日期版本为 `26.11.07-1`。
  原 128-slot 优化的同子集 71.04% 降幅保留；扩大拥有覆盖后，64/high 与 low 的 active World
  唯一下界均为 119,534 B，完整图仍为 unrated、正式 memory/P8 未准入，未改预算或运行40K。
  首个正式 CPU 三窗九对组已完整结束：RPA validated_trace/playback_only 通过；legacy 对应两项
  因重复性为 inconclusive；两种 read_long 均超出原 1.10 相对门，失败及重开额度分别保留。
  隔离读取原型首轮诊断反而变慢（legacy +1.7%、RPA +5.6%），依预注册停止、不采用。
  11行本地矩阵全部通过（13,652项测试注册、0失败、26项显式skip）；同SHA的六个push和三个PR检查通过。
  其他 P0–P7、Seek、完整内存、设备和生产接受未完成；O2 实体清单及 F4/PD 移交门账已准备。
  本地最终矩阵和同 SHA hosted 状态见[本轮报告](''' + LINK + ''')。
  Version Gate 仍缺 owner 针对所选候选的有效 SDK 批准，按 owner 要求暂不修、不代签或豁免。
  [实施方案](stage_plans/active/stage-07/05-rpa-new/r4/plan.md)及
  [固定运行登记](stage_plans/active/stage-07/05-rpa-new/r4/formal-registration.md)继续持有剩余门。
  实体操作及移交准备见[O2清单](stage_reports/stages/stage-07/05-rpa-new/r4/2026-11-07-o2-physical-checklist.md)
  和[F4门账](stage_reports/stages/stage-07/05-rpa-new/r4/2026-11-07-f4-gate-and-handoff.md)。
''' + text[end:]
    text = text.replace('更新日期：2026-11-06', '更新日期：2026-11-07', 1)
    text = text.replace('R4 O1 方案 B 有效，缩页后同一 World 拥有子集减少 71.04%，完整内存仍 unrated、正式 memory/P8 未准入；其他准入和最终接受未完成',
                        'R4 O1 有效；扩大 World 下界为119,534 B且仍unrated；首CPU组读取超界，其他正式/设备/生产门及最终接受未完成')
    begin = text.index('- **分域内存与上限接受缺证据**')
    end = text.index('- **真实设备与生产接受未完成**', begin)
    text = text[:begin] + '''- **分域内存仍缺完整拥有证据**：O1 接受的是 64/2048/40K reference 设计预算。
  已实现 `page_size=128`，旧同子集下界从358,241降至103,738 B的效果有效；本轮扩大覆盖后
  high/low均为119,534 B，增加来自World本体/cache/order等新覆盖，不是产品回归。
  完整EnTT backing、scratch/transaction、其他语义域、shared retained/prepare峰值及设备/observer
  扰动尚未闭合，不能以下界低于327,680 B当作预算通过。两容量诊断已用尽，正式memory/P8
  未准入，预算保持；证据与覆盖边界见[本轮报告](''' + LINK + ''')。
''' + text[end:]
    text = text.replace('**`26.11.05-2`**', '**`26.11.07-1`**')
    return text


stage('docs/CURRENT_STATUS.md', status)


def plan(text):
    text = text.replace('状态：active；O1 方案 B 已接受；正式取证与最终接受未登记',
                        '状态：active；O1 方案 B 已接受；首个固定 CPU 正式组已完成，其他取证与最终接受未完成')
    text = text.replace('更新日期：2026-11-06', '更新日期：2026-11-07', 1)
    needle = 'owner 同时指定后续提交推送至 PR #32'
    position = text.index(needle)
    text = text[:position] + '''2026-11-07 owner 要求继续并在下次推送前更新version；本轮推进日期构建为26.11.07-1，
SDK保持0.9.1。扩大owning覆盖的high/low诊断均为119,534 B下界，完整内存仍unrated，
O1与memory/P8停止边界保持。首个P0 legacy/RPA正式三窗组已结束，读取门超界、部分
legacy重复性inconclusive；旧失败保留，不自动补样。具体证据、平台与剩余门见
[本轮报告](../../../../../''' + LINK + ''')。
''' + text[position:]
    return text


stage('docs/stage_plans/active/stage-07/05-rpa-new/r4/plan.md', plan)


def registration(text):
    text = text.replace('# R4 固定取证预注册草案', '# R4 固定取证登记与剩余预注册')
    text = text.replace('状态：candidate；O1 已接受，技术准入进行中，formal_registration=false；没有正式运行',
                        '状态：active；O1 已接受；P0 legacy/RPA 首固定 CPU 组已登记并结束，其余单元未登记')
    text = text.replace('更新日期：2026-11-05', '更新日期：2026-11-07', 1)
    text = text.replace('最终候选的待绑定字段仍为待生成；草案不填虚构 SHA 或 0。原 pre-PD A 已合法重建并完成\n目标依赖绑定，后续每组仍需把该 A 与实际最终候选、对应 harness 及准入材料共同封存。',
    '''P0 legacy/RPA 首组已绑定候选24f0a914、原pre-PD d344088及匹配普通Release STATIC二进制，
正式claim/seal和三窗36个测量进程的字节归档见
[2026-11-07报告](../../../../../''' + LINK + ''')。该登记仅覆盖固定CPU trace相对成本与重复性，
不认证端点p99；两read_long超界，legacy另两指标因重复性inconclusive，RPA另两项通过。
其他单元字段保持待生成，不使用这一组身份或小夹具代替各自准入。''')
    text = text.replace('358,241 B 超过原 327,680 B，memory/P8 按停止条件保持未准入。其余域未完成语义闭合，',
                        '358,241 B 超过原 327,680 B，历史失败保留。128-slot效果已验证，2026-11-07扩大\nowning覆盖后high/low下界均119,534 B且仍unrated，memory/P8保持未准入。其余域未完成语义闭合，')
    return text


stage('docs/stage_plans/active/stage-07/05-rpa-new/r4/formal-registration.md', registration)


def tools_readme(text):
    return text.replace('Appearance/Camera nested strings, transform\nscratch, World object/member initialization and unvisited containers remain uncharged unknowns.\nActual Appearance/Camera/WorldTransform page spans are matched synchronously inside live',
    '''The typed census also observes actual current heap strings, all seven nonempty component
payload types, packed entity size ranges, World object, transform cache/children/order capacities.
Inline strings are excluded, and moving a heap string changes its instantaneous owner rather
than permanently attaching its allocation to the old root. Private EnTT backing, transform
scratch/transactions and unvisited containers remain unknown. Observed spans are matched synchronously inside live''')


stage('tools/verification/execution_acceptance/README.md', tools_readme)


def index(text):
    text = text.replace('更新日期：2026-11-06', '更新日期：2026-11-07', 1)
    position = text.index('后续 R4 附件和阶段结论由本入口继续导航')
    return text[:position] + '''2026-11-07 的扩展 owning 覆盖、固定 CPU 组、平台核验与剩余门见
[本轮报告](r4/''' + REPORT + ''')及[原始证据和只读复算](r4/2026-11-07-owning-and-cpu-evidence/index.md)。
实体参与和退出准备见[O2操作清单](r4/2026-11-07-o2-physical-checklist.md)与
[F4门账及PD移交](r4/2026-11-07-f4-gate-and-handoff.md)。
''' + text[position:]


stage('docs/stage_reports/stages/stage-07/05-rpa-new/README.md', index)
print(str(BASE))
