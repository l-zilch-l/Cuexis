@echo off
call "D:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b %errorlevel%
set "VCPKG_ROOT=D:\vcpkg"
D:\Cuexis-worktree\out\build\r4\final-20261107\20261107-130847-66b527cb\msvc-on-release\bin\cuexis_execution_host_tests.exe [measurement]
exit /b %errorlevel%
