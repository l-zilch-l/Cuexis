@echo off
call "D:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b %errorlevel%
set "VCPKG_ROOT=D:\vcpkg"
cmake --preset headless-shared-debug --fresh -B D:\Cuexis-worktree\out\build\r4\final-20261107\20261107-130847-66b527cb\msvc-off-shared-debug
exit /b %errorlevel%
