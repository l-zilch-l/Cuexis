import json
from pathlib import Path
import subprocess

ROOT = Path('D:/Cuexis-worktree')
SOURCE = ROOT / 'out/sources/r4/semantic-memory'
OUTPUT = ROOT / 'out/evidence/r4/post-o1/semantic-memory/static-checks'
OUTPUT.mkdir(exist_ok=False)
commands = {
    'python-tools': ['python', '-B', '-m', 'unittest', 'discover', '-s',
                     'tools/verification/execution_acceptance', '-t', '.'],
    'version': ['python', '-B', 'tools/update_version.py', '--check'],
    'format': ['clang-format', '--dry-run', '--Werror',
               'engine/core/internal/cuexis_internal/semantic_memory.hpp',
               'engine/runtime/internal/cuexis/runtime/transaction_access.hpp',
               'engine/world/src/world.cpp', 'engine/runtime/src/chart_world_instantiator.cpp',
               'engine/runtime/src/runtime_session.cpp', 'engine/playback/src/playback_session_prepare.cpp',
               'tests/pd/execution_memory_observer.cpp', 'tests/pd/execution_memory_tests.cpp'],
    'architecture': ['ctest', '--test-dir',
                     str(ROOT / 'out/build/r4/post-o1/semantic-memory-normal-debug'),
                     '-R', 'cuexis_architecture_tests', '--output-on-failure', '--no-tests=error'],
    'source-diff': ['git', 'diff', '--check'],
}
results = {}
for name, command in commands.items():
    with (OUTPUT / (name + '.log')).open('xb') as stream:
        process = subprocess.run(command, cwd=SOURCE, stdout=stream, stderr=subprocess.STDOUT)
    results[name] = {'command': command, 'exit_code': process.returncode}
    process.check_returncode()
    print(name, 'passed', flush=True)
(OUTPUT / 'summary.json').write_text(json.dumps(results, indent=2) + '\n', encoding='utf-8')
