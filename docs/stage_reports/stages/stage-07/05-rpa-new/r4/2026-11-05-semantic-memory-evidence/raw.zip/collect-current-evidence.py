import datetime
import json
from pathlib import Path
import subprocess

ROOT = Path('D:/Cuexis-worktree')
OUT = ROOT / 'out/evidence/r4/post-o1/semantic-memory/prior-c22-audit'
OUT.mkdir(exist_ok=False)
expected = '22a50762f697b64dd41b1355cb5ae649bd56a86b'
summary = {'source_sha': expected, 'formal_attempts_consumed': 0, 'hosted': [], 'local_rows': []}
for run_id in (42000574793, 42000574831, 42000574999):
    raw = subprocess.check_output(['gh', 'run', 'view', str(run_id), '--json',
                                   'status,conclusion,headSha,jobs'])
    (OUT / f'hosted-{run_id}.json').write_bytes(raw)
    data = json.loads(raw)
    if data['headSha'] != expected:
        raise ValueError('hosted identity mismatch')
    summary['hosted'].append({'run_id': run_id, 'status': data['status'],
                              'conclusion': data['conclusion'],
                              'jobs': [{'name': j['name'], 'status': j['status'],
                                        'conclusion': j['conclusion']} for j in data['jobs']]})
matrix = ROOT / 'out/evidence/r4/post-o1/final-matrix/20261105-171157-a26b312b'
data = json.loads((matrix / 'manifest.json').read_text(encoding='utf-8'))
for row in data['rows']:
    phases = row['phases']
    repetitions = [p for p in phases if '-budget-' in p['phase']]
    complete = (len(repetitions) == 10 and all(p['exit_code'] == 0 for p in phases)
                and row.get('source_unchanged') is True and 'source_after' in row)
    summary['local_rows'].append({'name': row['name'], 'manifest_status': row['status'],
                                  'ctest_pass': any(p['phase'] == 'ctest' and
                                                    p['exit_code'] == 0 for p in phases),
                                  'ctest_counts': row['test_counts'],
                                  'skipped_tests': row['skipped_tests'],
                                  'recorded_budget_repetitions': len(repetitions),
                                  'has_source_after': 'source_after' in row,
                                  'source_unchanged': row.get('source_unchanged'),
                                  'complete_row': complete})
summary['interpretation'] = ('The old runner sets local_pass before budget repetitions. '
                             'Only two rows are complete; shared Debug CTest passed but the '
                             'row was interrupted. None of this is new semantic-source qualification.')
summary['captured_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print(json.dumps(summary, indent=2, ensure_ascii=False))
