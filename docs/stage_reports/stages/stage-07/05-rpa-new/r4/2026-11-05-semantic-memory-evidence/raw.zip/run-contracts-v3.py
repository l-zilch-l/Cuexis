import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('D:/Cuexis-worktree')
SOURCE = ROOT / 'out/sources/r4/semantic-memory'
sys.path.insert(0, str(SOURCE))
from tools.verification.execution_acceptance.binding import artifact, clean_source, read, write_once
from tools.verification.execution_acceptance.build_binding import verify
from tools.verification.execution_acceptance.semantic_memory import collect

BASE = ROOT / 'out/evidence/r4/post-o1/semantic-memory'
OUTPUT = BASE / 'contracts-v3'
OUTPUT.mkdir(exist_ok=False)
source = clean_source(SOURCE)
binding = read(BASE / 'build-v3/cuexis_pd_host_probe-build-binding.json')
verify(binding, source, 'memory')
cases = [
    ('positive', 'Execution observer*,Execution semantic roots*,Execution semantic census*'),
    ('unknown-root', 'Execution semantic observer rejects an unregistered owner'),
    ('root-capacity', 'Execution semantic observer rejects root table exhaustion'),
    ('page-overrun', 'Execution semantic observer rejects a page span beyond its backing allocation'),
]
write_once(OUTPUT / 'registration.json', {'kind': 'allocator_contract_tests',
            'maximum_processes': 4, 'timeout_seconds_per_process': 120,
            'capacity_workflow': False, 'formal_sampling': False,
            'source': source['sha'], 'binary': binding['binary'], 'cases': cases,
            'controller': artifact(Path(__file__))})
results = []
for name, case in cases:
    command = [binding['binary']['path'], case, '--reporter', 'compact', '--rng-seed', '1']
    log = OUTPUT / (name + '.log')
    started = time.monotonic()
    with log.open('xb') as stream:
        process = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT,
                                 cwd=SOURCE, timeout=120)
    row = {'case': name, 'exit_code': process.returncode,
           'elapsed_seconds': time.monotonic() - started, 'log': artifact(log)}
    write_once(OUTPUT / (name + '.json'), row)
    results.append(row)
    process.check_returncode()
proofs = collect((OUTPUT / 'positive.log').read_text(encoding='utf-8'))
observed = {(row['proof']['lower_bound_requested_cpp_bytes'], row['proof']['live_count'])
            for row in proofs['censuses']}
if len(proofs['censuses']) != 2 or observed != {(12345 + 496, 2), (8192, 1)}:
    raise ValueError('C++ overlapping aliases or actual standard allocator census mismatch')
vector = next(row for row in proofs['censuses'] if row['proof']['live_count'] == 1)
if vector['proof']['backing_requested_cpp_bytes'] <= 8192 or not vector['spans'][0]['offset']:
    raise ValueError('MSVC interior-aligned allocation was not actually exercised')
if clean_source(SOURCE) != source:
    raise ValueError('source changed during contract verification')
write_once(OUTPUT / 'summary.json', {'source_sha': source['sha'], 'results': results,
            'unique_alias_census_verified': True, 'capacity_diagnostic_rounds_used': 0})
print(json.dumps({'source_sha': source['sha'], 'all_processes_exit_zero': True,
                  'unique_alias_census_verified': True, 'diagnostic_rounds_used': 0}, indent=2))
