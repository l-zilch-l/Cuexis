import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('D:/Cuexis-worktree')
SOURCE = ROOT / 'out/sources/r4/semantic-memory'
sys.path.insert(0, str(SOURCE))
from tools.verification.execution_acceptance.binding import artifact, clean_source, read, write_once
from tools.verification.execution_acceptance.build_binding import verify
from tools.verification.execution_acceptance.semantic_memory import collect

BASE = ROOT / 'out/evidence/r4/post-o1/semantic-memory'
OUTPUT = BASE / 'contracts-v2'
OUTPUT.mkdir(exist_ok=False)
source = clean_source(SOURCE)
binding = read(BASE / 'build-v2/cuexis_pd_host_probe-build-binding.json')
verify(binding, source, 'memory')
cases = [
    ('positive', 'Execution observer*,Execution semantic roots*'),
    ('unknown-root', 'Execution semantic observer rejects an unregistered owner'),
    ('root-capacity', 'Execution semantic observer rejects root table exhaustion'),
]
write_once(OUTPUT / 'registration.json', {'kind': 'allocator_contract_tests',
            'maximum_processes': 3, 'timeout_seconds_per_process': 120,
            'capacity_workflow': False, 'formal_sampling': False,
            'source': source['sha'], 'binary': binding['binary'], 'cases': cases,
            'controller': artifact(Path(__file__))})
results = []
for name, case in cases:
    command = [binding['binary']['path'], case, '--reporter', 'compact', '--rng-seed', '1']
    log = OUTPUT / (name + '.log')
    started = time.monotonic()
    with log.open('xb') as stream:
        process = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT,
                                 cwd=SOURCE, timeout=120)
    row = {'case': name, 'exit_code': process.returncode,
           'elapsed_seconds': time.monotonic() - started, 'log': artifact(log)}
    write_once(OUTPUT / (name + '.json'), row)
    results.append(row)
    process.check_returncode()
proofs = collect((OUTPUT / 'positive.log').read_text(encoding='utf-8'))
if len(proofs['censuses']) != 1:
    raise ValueError('expected exactly one alias contract census')
proof = proofs['censuses'][0]['proof']
if proof['requested_cpp_bytes'] != 12345 + 512 or proof['live_count'] != 2:
    raise ValueError('C++ unique alias census did not match contract sizes')
if clean_source(SOURCE) != source:
    raise ValueError('source changed during contract verification')
write_once(OUTPUT / 'summary.json', {'source_sha': source['sha'], 'results': results,
            'unique_alias_census_verified': True, 'capacity_diagnostic_rounds_used': 0})
print(json.dumps({'source_sha': source['sha'], 'all_processes_exit_zero': True,
                  'unique_alias_census_verified': True, 'diagnostic_rounds_used': 0}, indent=2))
