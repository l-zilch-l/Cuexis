import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('D:/Cuexis-worktree')
SOURCE = ROOT / 'out/sources/r4/semantic-memory'
sys.path.insert(0, str(SOURCE))
from tools.verification.execution_acceptance.binding import (
    accepted_budget, artifact, clean_source, read, sha256, write_once)
from tools.verification.execution_acceptance.build_binding import verify
from tools.verification.execution_acceptance.semantic_memory import analyze_workflow

BASE = ROOT / 'out/evidence/r4/post-o1/semantic-memory'
authorization = read(BASE / 'owner-authorization.json')
if (authorization['owner_choice'] != 'A' or authorization['maximum_rounds'] != 2 or
        authorization['entities'] != 64 or authorization['reuse'] != 'high' or
        authorization['maximum_processes_per_round'] != 1 or
        authorization['timeout_seconds'] != 120 or authorization['p8_authorized'] is not False):
    raise ValueError('diagnostic authorization mismatch')
prior = list(BASE.glob('round-*/registration.json'))
if prior != [BASE / 'round-1/registration.json'] or not (BASE / 'round-1/tool-invalid.json').is_file():
    raise ValueError('exactly one preserved invalid first round is required')
first_registration = read(prior[0])
first_result = read(BASE / 'round-1/process-result.json')
from tools.verification.execution_acceptance.binding import verify_artifact
verify_artifact(first_result['stdout'])
verify_artifact(first_result['stderr'])
if first_registration['round'] != 1 or first_result['diagnostic_rounds_consumed_this_batch'] != 1:
    raise ValueError('first diagnostic ledger mismatch')
contracts = read(BASE / 'contracts-v3/summary.json')
source = clean_source(SOURCE)
if contracts['source_sha'] != source['sha'] or any(
        row['exit_code'] != 0 for row in contracts['results']):
    raise ValueError('contract tests do not qualify this source')
binding = read(BASE / 'build-v3/cuexis_pd_host_probe-build-binding.json')
verify(binding, source, 'memory')
budget_path = SOURCE / 'tools/verification/execution_acceptance/budget-proposal.v1.json'
if sha256(budget_path) != authorization['budget_binding']['sha256']:
    raise ValueError('unchanged owner budget required')
acceptance_path = SOURCE / 'docs/stage_reports/stages/stage-07/05-rpa-new/r4/2026-11-05-o1-budget-acceptance.json'
budget = accepted_budget(artifact(acceptance_path), artifact(budget_path))
profile = next(p for p in budget['profiles'] if p['id'] == 'r4-reference-n64-v1')
environment = os.environ.copy()
for name in list(environment):
    if name.startswith('CUEXIS_PD5_'):
        del environment[name]
workload = {'CUEXIS_PD5_ENTITIES': '64', 'CUEXIS_PD5_REUSE': 'high',
            'CUEXIS_PD5_CAPSULE_REVISION': '3'}
environment.update(workload)
command = [binding['binary']['path'], 'PD5 full content Snapshot Seek Replay boundary',
           '--reporter', 'compact', '--rng-seed', '1']
output = BASE / 'round-2'
output.mkdir(exist_ok=False)
write_once(output / 'registration.json', {
    'schema': 'rpa.execution.semantic-memory-diagnostic.v1', 'round': 2,
    'maximum_processes': 1, 'timeout_seconds': 120, 'workload_environment': workload,
    'source_sha': source['sha'], 'source_tree': source['tree'], 'source': artifact(BASE / 'build-v3/source.json'),
    'binary': binding['binary'], 'build_binding': artifact(BASE / 'build-v3/cuexis_pd_host_probe-build-binding.json'),
    'controller': artifact(Path(__file__)), 'owner_authorization': artifact(BASE / 'owner-authorization.json'),
    'budget': artifact(budget_path), 'profile': profile['id'], 'command': command,
    'formal_sampling': False, 'p8': False, 'entities_40000': False,
    'preceding_invalid_round': artifact(BASE / 'round-1/process-result.json'),
    'correction': 'MSVC xmemory manually vector-aligned operator new prefix; conservative payload-only interval union.',
    'change_under_test': 'Repair MSVC interior-aligned page matching; charge only the union of actual payload spans, preserve full backing rows, aliases and original invalid first round.',
    'stop_conditions': ['Any process failure, timeout, range/partition invalidity: retain failure and stop.',
                        'Active unique World lower bound above unchanged ceiling: record proven failure, stop memory/P8; both authorized rounds are now consumed.',
                        'Otherwise remain unrated; stop this batch with no additional run. No formal acceptance or upper-bound claim.'],
    'legal_holders': 'Original capacity workflow and release ladder unchanged; no early handle release.'})
started = time.monotonic()
timed_out = False
with (output / 'stdout.log').open('xb') as stdout, (output / 'stderr.log').open('xb') as stderr:
    try:
        process = subprocess.run(command, cwd=SOURCE, env=environment, stdout=stdout,
                                 stderr=stderr, timeout=120)
        exit_code = process.returncode
    except subprocess.TimeoutExpired:
        timed_out = True
        exit_code = None
result = {'exit_code': exit_code, 'timed_out': timed_out,
          'elapsed_seconds': time.monotonic() - started, 'source_sha': source['sha'],
          'stdout': artifact(output / 'stdout.log'), 'stderr': artifact(output / 'stderr.log'),
          'formal_attempts_consumed': 0, 'diagnostic_rounds_consumed_this_batch': 2,
          'remaining_diagnostic_rounds': 0}
write_once(output / 'process-result.json', result)
if timed_out or exit_code != 0:
    raise RuntimeError('diagnostic process failed; do not retry or replace')
if clean_source(SOURCE) != source or sha256(Path(binding['binary']['path'])) != binding['binary']['sha256']:
    raise ValueError('source/binary changed during diagnostic')
text = (output / 'stdout.log').read_text(encoding='utf-8')
try:
    analysis = analyze_workflow(text, profile)
except Exception as error:
    write_once(output / 'tool-invalid.json', {'error': str(error), 'formal_acceptance': False})
    raise
write_once(output / 'analysis.json', analysis)
write_once(output / 'disposition.json', {
    'status': analysis['rating']['status'], 'formal_acceptance': False,
    'memory_admitted': False, 'p8_admitted': False, 'second_round_run': True,
    'budget_changed': False, 'limits_source': 'Unchanged O1 B accepted reference design ceiling',
    'next_step': 'If proven_over_budget, retain this result and prepare remediation alternatives; no budget increase or performance mechanism is inferred.'})
print(json.dumps({'process': result, 'rating': analysis['rating'],
                  'checkpoints': analysis['checkpoints']}, indent=2))
