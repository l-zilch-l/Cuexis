from pathlib import Path

base = Path(__file__).resolve().parent

contract = (base / 'run-contracts.py').read_text(encoding='utf-8')
contract = contract.replace("contracts-v2", "contracts-v3").replace("build-v2", "build-v3")
contract = contract.replace("Execution observer*,Execution semantic roots*",
                            "Execution observer*,Execution semantic roots*,Execution semantic census*")
contract = contract.replace("('root-capacity', 'Execution semantic observer rejects root table exhaustion'),",
                            "('root-capacity', 'Execution semantic observer rejects root table exhaustion'),\n"
                            "    ('page-overrun', 'Execution semantic observer rejects a page span beyond its backing allocation'),")
contract = contract.replace("'maximum_processes': 3", "'maximum_processes': 4")
old = """if len(proofs['censuses']) != 1:
    raise ValueError('expected exactly one alias contract census')
proof = proofs['censuses'][0]['proof']
if proof['requested_cpp_bytes'] != 12345 + 512 or proof['live_count'] != 2:
    raise ValueError('C++ unique alias census did not match contract sizes')"""
new = """observed = {(row['proof']['lower_bound_requested_cpp_bytes'], row['proof']['live_count'])
            for row in proofs['censuses']}
if len(proofs['censuses']) != 2 or observed != {(12345 + 496, 2), (8192, 1)}:
    raise ValueError('C++ overlapping aliases or actual standard allocator census mismatch')
vector = next(row for row in proofs['censuses'] if row['proof']['live_count'] == 1)
if vector['proof']['backing_requested_cpp_bytes'] <= 8192 or not vector['spans'][0]['offset']:
    raise ValueError('MSVC interior-aligned allocation was not actually exercised')"""
assert old in contract
contract = contract.replace(old, new)
with (base / 'run-contracts-v3.py').open('x', encoding='utf-8') as stream:
    stream.write(contract)

controller = (base / 'run-round-one.py').read_text(encoding='utf-8')
old = """if any(BASE.glob('round-*/registration.json')):
    raise ValueError('round one already consumed or ambiguous prior diagnostic')"""
new = """prior = list(BASE.glob('round-*/registration.json'))
if prior != [BASE / 'round-1/registration.json'] or not (BASE / 'round-1/tool-invalid.json').is_file():
    raise ValueError('exactly one preserved invalid first round is required')
first_registration = read(prior[0])
first_result = read(BASE / 'round-1/process-result.json')
from tools.verification.execution_acceptance.binding import verify_artifact
verify_artifact(first_result['stdout'])
verify_artifact(first_result['stderr'])
if first_registration['round'] != 1 or first_result['diagnostic_rounds_consumed_this_batch'] != 1:
    raise ValueError('first diagnostic ledger mismatch')"""
assert old in controller
controller = controller.replace(old, new)
controller = controller.replace('contracts-v2', 'contracts-v3').replace('build-v2', 'build-v3')
controller = controller.replace("output = BASE / 'round-1'", "output = BASE / 'round-2'")
controller = controller.replace("'round': 1,", "'round': 2,")
controller = controller.replace("'diagnostic_rounds_consumed_this_batch': 1", "'diagnostic_rounds_consumed_this_batch': 2")
controller = controller.replace("'remaining_diagnostic_rounds': 1", "'remaining_diagnostic_rounds': 0")
controller = controller.replace("'second_round_run': False", "'second_round_run': True")
controller = controller.replace("Stable registry subset plus actual component-page census, excluding swappable strings and scratch; root generation, unique IDs and actual release.",
    "Repair MSVC interior-aligned page matching; charge only the union of actual payload spans, preserve full backing rows, aliases and original invalid first round.")
controller = controller.replace("stop memory/P8; do not consume second round.",
                                "stop memory/P8; both authorized rounds are now consumed.")
controller = controller.replace("'Otherwise remain unrated; no formal acceptance, no upper-bound claim.'",
                                "'Otherwise remain unrated; stop this batch with no additional run. No formal acceptance or upper-bound claim.'")
controller = controller.replace("'formal_sampling': False, 'p8': False, 'entities_40000': False,",
    "'formal_sampling': False, 'p8': False, 'entities_40000': False,\n"
    "    'preceding_invalid_round': artifact(BASE / 'round-1/process-result.json'),\n"
    "    'correction': 'MSVC xmemory manually vector-aligned operator new prefix; conservative payload-only interval union.',")
with (base / 'run-round-two.py').open('x', encoding='utf-8') as stream:
    stream.write(controller)
print('Created new immutable v3 contract and round-two controllers; no native process launched.')
