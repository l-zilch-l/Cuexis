"""Stop this task's old candidate matrix at a completed-row boundary; preserve partial evidence."""
import json
from pathlib import Path
import subprocess
import time

ROOT = Path("D:/Cuexis-worktree")
MANIFEST = ROOT / "out/evidence/r4/post-o1/final-matrix/20261105-171157-a26b312b/manifest.json"
PID = 18468
deadline = time.monotonic() + 600
while time.monotonic() < deadline:
    try:
        value = json.loads(MANIFEST.read_text(encoding="utf-8-sig"))
    except (json.JSONDecodeError, OSError):
        time.sleep(5)
        continue
    rows = value["rows"]
    if len(rows) >= 3 and all(row.get("status") == "local_pass" for row in rows[:3]):
        query = subprocess.run(["powershell", "-NoProfile", "-Command",
            f"Get-CimInstance Win32_Process -Filter 'ProcessId={PID}' | Select-Object -ExpandProperty CommandLine"],
            capture_output=True, text=True)
        command = query.stdout.strip()
        if "tools/verification/run_rpa_acceptance_matrix.py" not in command or "out/evidence/r4/post-o1/final-matrix" not in command:
            raise RuntimeError("old matrix PID identity no longer matches; did not stop anything")
        result = subprocess.run(["taskkill", "/PID", str(PID), "/T", "/F"], capture_output=True)
        record = {"source_sha": value["source"]["head"], "pid": PID, "command_line": command,
            "exit_code": result.returncode, "taskkill_output": result.stdout.decode(errors="replace"),
            "completed_rows": [row["name"] for row in rows[:3]],
            "reason": "Owner approved new semantic memory implementation after C22 freeze; preserve completed C22 preparation rows, stop further obsolete candidate builds before refreezing the next candidate.",
            "formal_attempts_consumed": 0, "candidate_source_modified": False,
            "partial_rows": [row["name"] for row in rows[3:]]}
        path = MANIFEST.parent / "owner-steering-interruption.json"
        with path.open("x", encoding="utf-8") as stream:
            json.dump(record, stream, ensure_ascii=False, indent=2)
        print(json.dumps(record, ensure_ascii=False), flush=True)
        break
    time.sleep(5)
else:
    raise RuntimeError("completed-row boundary was not reached within the bounded watch")
