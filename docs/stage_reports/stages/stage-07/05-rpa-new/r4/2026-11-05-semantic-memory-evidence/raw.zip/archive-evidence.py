import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path('D:/Cuexis-worktree')
SOURCE = ROOT / 'out/evidence/r4/post-o1/semantic-memory'
OUTPUT = ROOT / 'docs/stage_reports/stages/stage-07/05-rpa-new/r4/2026-11-05-semantic-memory-evidence'
OUTPUT.mkdir(exist_ok=True)
files = {}
with zipfile.ZipFile(OUTPUT / 'raw.zip', 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(SOURCE.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts:
            continue
        name = path.relative_to(SOURCE).as_posix()
        data = path.read_bytes()
        info = zipfile.ZipInfo(name, date_time=(2026, 11, 5, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, data, compresslevel=9)
        files[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
manifest = {'schema': 'rpa.execution.semantic-memory-archive.v1',
            'source_sha': '5fd1bd3c90ebba767e2b6ac54375d63f209c2504',
            'archive_sha256': hashlib.sha256((OUTPUT / 'raw.zip').read_bytes()).hexdigest(),
            'raw_file_count': len(files), 'raw_bytes': sum(item['bytes'] for item in files.values()),
            'files': files}
(OUTPUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: value for key, value in manifest.items() if key != 'files'}, indent=2))
