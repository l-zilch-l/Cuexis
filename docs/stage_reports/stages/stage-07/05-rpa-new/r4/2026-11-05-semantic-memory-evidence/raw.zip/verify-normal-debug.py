import json
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path('D:/Cuexis-worktree')
SOURCE = ROOT / 'out/sources/r4/semantic-memory'
sys.path.insert(0, str(SOURCE))
from tools.verification.execution_acceptance.binding import artifact, clean_source, read, write_once
from tools.verification.execution_acceptance.build_binding import verify

BASE = ROOT / 'out/evidence/r4/post-o1/semantic-memory'
OUTPUT = BASE / 'normal-debug-checks'
OUTPUT.mkdir(exist_ok=False)
identity = clean_source(SOURCE)
targets = ['cuexis_world_tests', 'cuexis_runtime_tests', 'cuexis_playback_tests']
bindings = [verify(read(BASE / ('normal-debug-build/' + target + '-build-binding.json')),
                   identity, 'normal') for target in targets]
write_once(OUTPUT / 'registration.json', {'source_sha': identity['sha'], 'targets': targets,
            'observer_enabled': False, 'formal_sampling': False,
            'full_final_matrix': False, 'controller': artifact(Path(__file__))})
results = []
for target, binding in zip(targets, bindings):
    command = [binding['binary']['path'], '--reporter', 'compact', '--rng-seed', '1']
    started = time.monotonic()
    log = OUTPUT / (target + '.log')
    with log.open('xb') as stream:
        process = subprocess.run(command, cwd=SOURCE, stdout=stream, stderr=subprocess.STDOUT,
                                 timeout=600)
    row = {'target': target, 'command': command, 'exit_code': process.returncode,
           'elapsed_seconds': time.monotonic() - started, 'log': artifact(log)}
    results.append(row)
    write_once(OUTPUT / (target + '.json'), row)
    process.check_returncode()
    text = log.read_text(encoding='utf-8')
    print(target, text.splitlines()[-3:], flush=True)
if clean_source(SOURCE) != identity:
    raise ValueError('source changed during normal regression')
write_once(OUTPUT / 'summary.json', {'source_sha': identity['sha'], 'results': results,
            'full_final_matrix': False, 'formal_attempts_consumed': 0})
