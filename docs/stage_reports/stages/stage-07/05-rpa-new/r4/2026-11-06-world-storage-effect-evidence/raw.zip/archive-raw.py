import hashlib
import json
from pathlib import Path
import sys
import zipfile

ROOT = Path('D:/Cuexis-worktree')
BASE = Path(__file__).resolve().parent
OUTPUT = ROOT / 'docs/stage_reports/stages/stage-07/05-rpa-new/r4/2026-11-06-world-storage-effect-evidence'
sys.path.insert(0, str(ROOT))
from tools.verification.execution_acceptance.binding import write_once

for name, source in [
    ('budget.json', ROOT / 'tools/verification/execution_acceptance/budget-proposal.v1.json'),
    ('o1-acceptance.json', ROOT / 'docs/stage_reports/stages/stage-07/05-rpa-new/r4/2026-11-05-o1-budget-acceptance.json'),
]:
    with (BASE / name).open('xb') as stream:
        stream.write(source.read_bytes())
write_once(BASE / 'independent-review.json', {
    'schema': 'rpa.execution.world-pages-readonly-review.v1',
    'reviewer': '/root/memory_root_cause',
    'method': 'Independent direct parsing of new stdout and old raw.zip; unique allocation IDs, span union, backing bounds, product final release and artifact hashes; no workload or file edits by reviewer.',
    'capacity_processes_launched_by_reviewer': 0,
    'findings': [],
    'verified_current_censuses': 3,
    'verified_unique_allocations_per_census': 25,
    'current_stable_registry_allocations': 22,
    'current_stable_registry_bytes': 77114,
    'current_component_payload_spans_bytes': [8192, 10240, 8192],
    'current_active_subset_bytes': 103738,
    'current_backing_requested_cpp_bytes': 103855,
    'current_backing_crt_storage_bytes': 105655,
    'historical_active_subset_bytes': 358241,
    'saved_subset_bytes': 254503,
    'checkpoints': 19, 'partitions_exact': True, 'observer_overflow': False,
    'tracked_root_released_after_close': True,
    'final_product_requested_and_storage_bytes': 0,
    'final_global_requested_bytes': 18864,
    'remaining_global_owner_domain': 'probe.fixture',
    'supports_same_subset_reduction_percent': 71.04239883207115,
    'supports_complete_memory_acceptance': False,
    'disposition': 'Stop after one capacity process; preserve original budget and historical failure; no second process or 40K/P8.'})
files = {}
with zipfile.ZipFile(OUTPUT / 'raw.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for path in sorted(BASE.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts:
            continue
        data = path.read_bytes()
        name = path.relative_to(BASE).as_posix()
        info = zipfile.ZipInfo(name, date_time=(2026, 11, 6, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        bundle.writestr(info, data, compresslevel=9)
        files[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
manifest = {'schema': 'rpa.execution.world-pages-archive.v1',
    'source_sha': 'e643cd5bf4f12d64752cdce7f33bf52a31be7da4',
    'baseline_source_sha': '5fd1bd3c90ebba767e2b6ac54375d63f209c2504',
    'archive_sha256': hashlib.sha256((OUTPUT / 'raw.zip').read_bytes()).hexdigest(),
    'raw_file_count': len(files), 'raw_bytes': sum(row['bytes'] for row in files.values()),
    'files': files}
write_once(OUTPUT / 'manifest.json', manifest)
print(json.dumps({key: value for key, value in manifest.items() if key != 'files'}, indent=2))
