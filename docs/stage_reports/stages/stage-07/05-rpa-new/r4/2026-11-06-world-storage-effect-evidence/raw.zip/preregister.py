import subprocess
import sys
from pathlib import Path

ROOT = Path('D:/Cuexis-worktree')
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from tools.verification.execution_acceptance.binding import artifact, write_once

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT).decode().strip()

if git('status', '--porcelain', '--untracked-files=all'):
    raise ValueError('clean committed candidate required')
write_once(BASE / 'authorization-and-plan.json', {
    'schema': 'rpa.execution.world-pages-remediation-authorization.v1',
    'date_local': '2026-11-06', 'timezone': 'Asia/Shanghai',
    'owner_message': '没关系，我允许适当提高内存预算，你先对当前优化效果进行验证，如果效果不好就继续优化，如果优化后的效果仍然不理想就向我汇报，我会考虑是否提高内存预算',
    'interpretation': 'Verify current page-size optimization; permit evidence-led further optimization if inadequate; report before choosing any raised budget.',
    'source_sha': git('rev-parse', 'HEAD'), 'source_tree': git('rev-parse', 'HEAD^{tree}'),
    'maximum_capacity_diagnostic_processes_this_batch': 2,
    'first_process': {'entities': 64, 'reuse': 'high', 'capsule_revision': 3,
                      'timeout_seconds': 120, 'maximum_processes': 1},
    'second_process': 'Only after a documented inadequate first result and concrete code/tool remediation, under a new registration and source identity; never silently replace a failed process.',
    'correctness_contracts': 'Four independent non-capacity allocator contracts, maximum 120 seconds each.',
    'comparison': 'Same workflow/observer/profile as preserved 5fd1bd3c round 2. Source implementation delta is only component page_size plus its test harness; version/report identity changes disclosed.',
    'budget_changed': False, 'formal_sampling': False, 'p8_authorized': False,
    'entities_40000_authorized': False, 'download_proxy': 'http://127.0.0.1:7890',
    'controller': artifact(BASE / 'verify-effect.py'),
    'stop_conditions': ['retain all errors and old failures',
                        'no third capacity process in this batch',
                        'no formal memory acceptance based on partial owning lower bounds',
                        'report residual cost and uncertainties before any budget change']})
print('Registered bounded post-remediation diagnostic before build and capacity execution.')
