import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('D:/Cuexis-worktree')
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from tools.verification.execution_acceptance.binding import artifact, read, write_once

comparison = read(BASE / 'round-1/comparison.json')
if comparison['after']['proof']['lower_bound_requested_cpp_bytes'] != 103738:
    raise ValueError('unexpected measured outcome')
baseline = ROOT / 'out/evidence/r4/post-o1/semantic-memory'
output = BASE / 'baseline'
output.mkdir(exist_ok=False)
for name, source in [
    ('registration.json', baseline / 'round-2/registration.json'),
    ('process-result.json', baseline / 'round-2/process-result.json'),
    ('analysis.json', baseline / 'round-2/analysis.json'),
    ('stdout.log', baseline / 'round-2/stdout.log'),
    ('stderr.log', baseline / 'round-2/stderr.log'),
    ('build-binding.json', baseline / 'build-v3/cuexis_pd_host_probe-build-binding.json'),
    ('build-source.json', baseline / 'build-v3/source.json'),
]:
    with (output / name).open('xb') as stream:
        stream.write(source.read_bytes())

before = read(output / 'build-binding.json')
after = read(BASE / 'build/cuexis_pd_host_probe-build-binding.json')
if before['toolchain_signature'] != after['toolchain_signature'] or before['options'] != after['options']:
    raise ValueError('non-comparable compiler/build options')
paths = subprocess.check_output(['git', 'diff', '--name-only',
    comparison['baseline_source_sha'], comparison['current_source_sha']], cwd=ROOT).decode().splitlines()
write_once(BASE / 'comparison-inputs.json', {
    'baseline_build': artifact(output / 'build-binding.json'),
    'current_build': artifact(BASE / 'build/cuexis_pd_host_probe-build-binding.json'),
    'same_toolchain_signature': True, 'same_instrumentation_options': True,
    'same_configuration': before['config'] == after['config'] == 'Release',
    'changed_files_between_sources': paths,
    'execution_memory_observer_and_capacity_workflow_changed': False,
    'product_implementation_change': 'Only seven nonempty World component page_size declarations. Other tracked changes are version metadata, page-boundary tests and reports.'})
write_once(BASE / 'final-disposition.json', {
    'schema': 'rpa.execution.world-pages-remediation-disposition.v1',
    'source_sha': comparison['current_source_sha'],
    'capacity_processes_run': 1, 'second_capacity_process_run': False,
    'reason_for_no_second_process': 'Same scoped owning subset decreased 71.04 percent and is below original cap. No evidence warrants an additional product storage mechanism now.',
    'formal_attempts_consumed': 0, 'p8_attempts_consumed': 0,
    'budget_changed': False, 'memory_admitted': False, 'p8_admitted': False,
    'entities_40000_run': False, 'historical_failure_preserved': True,
    'current_semantic_rating': 'unrated',
    'before_subset_bytes': 358241, 'after_subset_bytes': 103738,
    'saved_subset_bytes': 254503, 'original_world_cap_bytes': 327680,
    'next_step': 'Preserve 128-slot implementation. Complete semantic owning coverage and required multi-scale performance/compatibility gates before formal memory/P8 admission. No budget increase justified by this partial result.'})
print('Preserved immutable baseline bytes, comparison inputs and batch disposition.')
