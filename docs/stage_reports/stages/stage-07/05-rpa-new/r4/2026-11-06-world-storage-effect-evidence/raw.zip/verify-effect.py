import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('D:/Cuexis-worktree')
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from tools.verification.execution_acceptance.binding import (
    accepted_budget, artifact, clean_source, read, sha256, verify_artifact, write_once)
from tools.verification.execution_acceptance.build_binding import verify
from tools.verification.execution_acceptance.semantic_memory import analyze_workflow, collect


def identity_and_build():
    source = clean_source(ROOT)
    initial = read(BASE / 'authorization-and-plan.json')
    if source['sha'] != initial['source_sha'] or source['tree'] != initial['source_tree']:
        raise ValueError('candidate differs from preregistration')
    binding = read(BASE / 'build/cuexis_pd_host_probe-build-binding.json')
    verify(binding, source, 'memory')
    if binding['config'] != 'Release':
        raise ValueError('Release configuration required')
    return source, binding


def contracts():
    source, binding = identity_and_build()
    output = BASE / 'contracts'
    output.mkdir(exist_ok=False)
    cases = [
        ('positive', 'Execution observer*,Execution semantic roots*,Execution semantic census*'),
        ('unknown-root', 'Execution semantic observer rejects an unregistered owner'),
        ('root-capacity', 'Execution semantic observer rejects root table exhaustion'),
        ('page-overrun', 'Execution semantic observer rejects a page span beyond its backing allocation'),
    ]
    write_once(output / 'registration.json', {
        'kind': 'allocator_contract_tests', 'source_sha': source['sha'],
        'maximum_processes': 4, 'timeout_seconds_per_process': 120,
        'capacity_workflow': False, 'formal_sampling': False, 'cases': cases,
        'binary': binding['binary'], 'controller': artifact(Path(__file__))})
    results = []
    for name, case in cases:
        command = [binding['binary']['path'], case, '--reporter', 'compact', '--rng-seed', '1']
        with (output / (name + '.log')).open('xb') as log:
            started = time.monotonic()
            process = subprocess.run(command, cwd=ROOT, stdout=log,
                                     stderr=subprocess.STDOUT, timeout=120)
        row = {'case': name, 'exit_code': process.returncode,
               'elapsed_seconds': time.monotonic() - started,
               'log': artifact(output / (name + '.log'))}
        write_once(output / (name + '.json'), row)
        results.append(row)
        process.check_returncode()
    document = collect((output / 'positive.log').read_text(encoding='utf-8'))
    observed = {(row['proof']['lower_bound_requested_cpp_bytes'], row['proof']['live_count'])
                for row in document['censuses']}
    if len(document['censuses']) != 2 or observed != {(12345 + 496, 2), (8192, 1)}:
        raise ValueError('alias/aligned allocation contracts did not match')
    vector = next(row for row in document['censuses'] if row['proof']['live_count'] == 1)
    if vector['proof']['backing_requested_cpp_bytes'] <= 8192 or not vector['spans'][0]['offset']:
        raise ValueError('MSVC interior aligned backing not exercised')
    if clean_source(ROOT) != source:
        raise ValueError('source changed during contracts')
    write_once(output / 'summary.json', {'source_sha': source['sha'], 'results': results,
        'unique_alias_census_verified': True, 'capacity_diagnostic_rounds_used': 0})
    print('Allocator contracts passed; no capacity diagnostic process used.', flush=True)


def workflow():
    source, binding = identity_and_build()
    qualification = read(BASE / 'contracts/summary.json')
    if qualification['source_sha'] != source['sha'] or any(row['exit_code'] != 0 for row in qualification['results']):
        raise ValueError('unqualified observer')
    budget_file = ROOT / 'tools/verification/execution_acceptance/budget-proposal.v1.json'
    acceptance = ROOT / 'docs/stage_reports/stages/stage-07/05-rpa-new/r4/2026-11-05-o1-budget-acceptance.json'
    budget = accepted_budget(artifact(acceptance), artifact(budget_file))
    profile = next(row for row in budget['profiles'] if row['id'] == 'r4-reference-n64-v1')
    baseline = ROOT / 'out/evidence/r4/post-o1/semantic-memory/round-2'
    old_registration = read(baseline / 'registration.json')
    old_result = read(baseline / 'process-result.json')
    verify_artifact(old_result['stdout'])
    verify_artifact(old_result['stderr'])
    if artifact(budget_file)['sha256'] != old_registration['budget']['sha256']:
        raise ValueError('baseline and current budgets differ')
    old_analysis = analyze_workflow(Path(old_result['stdout']['path']).read_text(encoding='utf-8'), profile)
    environment = os.environ.copy()
    for name in list(environment):
        if name.startswith('CUEXIS_PD5_'):
            del environment[name]
    workload = {'CUEXIS_PD5_ENTITIES': '64', 'CUEXIS_PD5_REUSE': 'high',
                'CUEXIS_PD5_CAPSULE_REVISION': '3'}
    if workload != old_registration['workload_environment']:
        raise ValueError('workload differs from baseline')
    environment.update(workload)
    output = BASE / 'round-1'
    output.mkdir(exist_ok=False)
    command = [binding['binary']['path'], 'PD5 full content Snapshot Seek Replay boundary',
               '--reporter', 'compact', '--rng-seed', '1']
    write_once(output / 'registration.json', {
        'schema': 'rpa.execution.world-pages-effect.v1', 'round': 1,
        'maximum_processes': 1, 'timeout_seconds': 120,
        'source_sha': source['sha'], 'source_tree': source['tree'],
        'source': artifact(BASE / 'build/source.json'), 'binary': binding['binary'],
        'build_binding': artifact(BASE / 'build/cuexis_pd_host_probe-build-binding.json'),
        'controller': artifact(Path(__file__)), 'workload_environment': workload,
        'authorization': artifact(BASE / 'authorization-and-plan.json'),
        'baseline_registration': artifact(baseline / 'registration.json'),
        'baseline_result': artifact(baseline / 'process-result.json'),
        'budget': artifact(budget_file), 'profile': profile['id'], 'command': command,
        'formal_sampling': False, 'p8': False, 'entities_40000': False,
        'change_under_test': 'Type-local page_size=128 on seven nonempty World component types; observer and capacity workflow unchanged.',
        'stop_conditions': [
            'Failure, timeout or invalid accounting: retain output; no automatic replacement.',
            'If active lower bound improves and lies below original cap, report limited effect and stop; no complete-graph pass claim.',
            'If active lower bound still exceeds original cap, retain failure and investigate one bounded targeted optimization before a second preregistered process.',
            'No budget edit, formal sampling or P8. Preserve legal holders and release ladder.']})
    started = time.monotonic()
    timed_out = False
    with (output / 'stdout.log').open('xb') as stdout, (output / 'stderr.log').open('xb') as stderr:
        try:
            process = subprocess.run(command, cwd=ROOT, env=environment, stdout=stdout,
                                     stderr=stderr, timeout=120)
            code = process.returncode
        except subprocess.TimeoutExpired:
            timed_out, code = True, None
    result = {'exit_code': code, 'timed_out': timed_out,
              'elapsed_seconds': time.monotonic() - started, 'source_sha': source['sha'],
              'stdout': artifact(output / 'stdout.log'), 'stderr': artifact(output / 'stderr.log'),
              'formal_attempts_consumed': 0, 'diagnostic_processes_consumed_this_batch': 1,
              'maximum_additional_processes_after_preregistered_remediation': 1}
    write_once(output / 'process-result.json', result)
    if timed_out or code != 0:
        raise ValueError('diagnostic failed; preserve failure without automatic retry')
    if clean_source(ROOT) != source or sha256(binding['binary']['path']) != binding['binary']['sha256']:
        raise ValueError('source/binary changed during process')
    try:
        analysis = analyze_workflow((output / 'stdout.log').read_text(encoding='utf-8'), profile)
    except Exception as error:
        write_once(output / 'tool-invalid.json', {'error': str(error)})
        raise
    write_once(output / 'analysis.json', analysis)
    def active_summary(document):
        active = [row for row in document['proofs']['censuses'] if row['proof']['phase'] == 'active']
        if len(active) != 1:
            raise ValueError('expected one active census in fixed workflow')
        row = active[0]
        return {'proof': row['proof'], 'allocations': row['allocations'],
                'stable_registry_subset_bytes': sum(x['charged_cpp_bytes'] for x in row['allocations'] if x['membership'] == 'stable_registry_subset'),
                'actual_component_page_bytes': sum(x['charged_cpp_bytes'] for x in row['allocations'] if x['membership'] == 'actual_component_page')}
    before, after = active_summary(old_analysis), active_summary(analysis)
    old_bytes = before['proof']['lower_bound_requested_cpp_bytes']
    new_bytes = after['proof']['lower_bound_requested_cpp_bytes']
    comparison = {'baseline_source_sha': old_registration['source_sha'], 'current_source_sha': source['sha'],
        'before': before, 'after': after, 'saved_lower_bound_bytes': old_bytes - new_bytes,
        'saved_fraction_of_baseline_lower_bound': (old_bytes - new_bytes) / old_bytes,
        'world_original_limit_bytes': next(x['requested_bytes'] for x in profile['domains'] if x['id'] == 'state.world'),
        'budget_changed': False, 'formal_acceptance': False, 'complete_world_graph': False,
        'historical_failure_preserved': True, 'current_rating': analysis['rating']}
    write_once(output / 'comparison.json', comparison)
    print(json.dumps({'process': result, 'before_bytes': old_bytes, 'after_bytes': new_bytes,
        'saved_bytes': old_bytes-new_bytes, 'rating': analysis['rating']}, indent=2), flush=True)


if __name__ == '__main__':
    {'contracts': contracts, 'workflow': workflow}[sys.argv[1]]()
