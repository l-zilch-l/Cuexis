from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys, zipfile, runpy

ROOT=Path('D:/Cuexis-worktree');OUT=Path(__file__).resolve().parent
BASE=ROOT/'docs/stage_reports/stages/stage-07/05-rpa-new/r2'
REPORT=BASE/'2026-10-26-r2-technical-closure-review.md'
STATE=Path('C:/Users/Zilch/Desktop/Cuexis-Stage7-RPA-R3-接手实施文档-2026-10-26.现场核验.json')
DOC=STATE.with_name('Cuexis-Stage7-RPA-R3-接手实施文档-2026-10-26.md')
JSON=BASE/'2026-10-26-r2-technical-closure-audit.json'
ZIP=JSON.with_suffix('.zip')

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(name,data):
    with (OUT/name).open('x',encoding='utf-8') as f: json.dump(data,f,ensure_ascii=False,indent=2)
def git(*args,cwd=ROOT): return subprocess.check_output(['git',*args],cwd=cwd)

def pack():
    ns=runpy.run_path(str(ROOT/'out/r2-common-objects-20261026/window.py'),run_name='read_only_closure_binding')
    ns['check'](load(ROOT/'out/r2-common-objects-20261026/registration.json'))
    start=load(OUT/'start.json')
    original=BASE/'2026-10-26-r2-exit-evidence.zip'
    original_manifest=BASE/'2026-10-26-r2-exit-evidence.json'
    for p in [original,original_manifest]: assert sha(p)==start['files'][p.relative_to(ROOT).as_posix()]
    for label in ['third-incremental','cumulative-r2-code-only']:
        r=load(ROOT/f'out/r2e-20261026/rollback/{label}/verification.json')
        assert r['exact_forward_reverse'] and sha(r['patch'])==r['patch_sha256']
        for row in r['paths']:
            p=ROOT/row['path']; assert p.is_file()==row['end_exists']
            if p.is_file(): assert sha(p)==row['end_sha256']
    files=[p for p in OUT.iterdir() if p.suffix in ['.py','.json'] and p.is_file()]
    files+=list((OUT/'logs').glob('*.log'))+[REPORT]
    rows=[]
    for p in sorted(files):
        arc='report/'+p.name if p==REPORT else 'audit/'+p.relative_to(OUT).as_posix()
        rows.append(dict(source_path=str(p),archive_path=arc,bytes=p.stat().st_size,sha256=sha(p)))
    body=dict(schema='cuexis.r2-technical-closure-audit.v1',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        source_head=start['head'],R2_technical_work_complete=True,R2_owner_exit_accepted=False,
        R4_formal_accepted=False,new_product_changes=False,new_performance_windows=False,
        evidence_review=load(OUT/'evidence-audit.json'),fresh_regression=load(OUT/'fresh-regression.json'),
        original_evidence_archive=dict(path=str(original),sha256=sha(original),files=501,unchanged=True),
        original_evidence_manifest_sha256=sha(original_manifest),
        limitations='Scoped local implementation/validation exit review; no default-QoS, alternative-layout, formal, device or production performance acceptance',
        records=rows)
    raw=json.dumps(body,ensure_ascii=False,indent=2).encode('utf-8')
    with zipfile.ZipFile(ZIP,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        z.writestr('manifest.json',raw)
        for p,r in zip(sorted(files),rows): z.write(p,r['archive_path'])
    with zipfile.ZipFile(ZIP) as z:
        assert z.read('manifest.json')==raw
        for row in rows: assert hashlib.sha256(z.read(row['archive_path'])).hexdigest()==row['sha256']
    body.update(archive_path=str(ZIP),archive_sha256=sha(ZIP),payload_manifest_sha256=hashlib.sha256(raw).hexdigest())
    with JSON.open('x',encoding='utf-8') as f:json.dump(body,f,ensure_ascii=False,indent=2)
    save('package-verification.json',dict(files=len(rows),archive_sha256=sha(ZIP),readback_verified=True,old_archive_unchanged=True))
    print('New audit archive verified:',len(rows),'files; original 501-file archive unchanged')

def checks():
    env=dict(os.environ,CUEXIS_TARGETS_FILE=str(ROOT/'out/build/consolidated-default-docs-20261026/generated/cuexis-targets.txt'))
    for label,args in [('docs',[sys.executable,'-B','tools/check_docs.py']),('diff',['git','-c','core.safecrlf=false','diff','--check'])]:
        log=OUT/(label+'-final.log')
        with log.open('xb') as f:r=subprocess.run(args,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
        save(label+'-final.json',dict(args=args,exit=r.returncode,log=str(log),sha256=sha(log)))
        print(label,r.returncode,log.read_text(encoding='utf-8',errors='replace')[-2000:])
        assert r.returncode==0

def handoff():
    start=load(OUT/'start.json');data=load(STATE)
    changes={p:sha(ROOT/p) for p,h in start['files'].items() if sha(ROOT/p)!=h}
    assert all(p.startswith('docs/') and p.endswith('.md') for p in changes)
    allowed=set(changes)|{str(DOC)}
    for p,h in list(data['bound_files'].items()):
        actual=sha(p)
        if actual!=h:
            path=Path(p)
            relative=path.relative_to(ROOT).as_posix() if path.is_relative_to(ROOT) else str(path)
            assert relative in allowed,('unexpected bound evidence drift',p)
            data['bound_files'][p]=actual
    for p in [REPORT,JSON,ZIP,OUT/'evidence-audit.json',OUT/'fresh-regression.json',OUT/'package-verification.json',OUT/'docs-final.json',OUT/'diff-final.json']:
        data['bound_files'][str(p.resolve())]=sha(p)
    for tree in data['trees']:
        root=Path(tree['path'])
        tree['head']=git('rev-parse','HEAD',cwd=root).decode().strip()
        tree['status']=git('status','--porcelain=v1','-z',cwd=root).decode().split('\0')
        tree['worktree_clean']=not any(tree['status'])
    assert data['trees'][0]['head']==start['head']
    assert git('rev-parse','HEAD',cwd=Path('D:/Cuexis-pd5-40k-admission')).decode().strip()==start['historical_head']
    assert git('status','--porcelain=v1','-z',cwd=Path('D:/Cuexis-pd5-40k-admission')).decode()==start['historical_status']
    data['snapshot_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    data['request']='Continue and complete R2 technical closure; correct overbroad outstanding-gate classification, preserve historical results, refresh R3 handoff'
    data['R2_technical_work_complete']=True
    data['R2_owner_exit_accepted']=False
    data['R2_technical_closure_review']=dict(report=str(REPORT),audit=str(JSON),archive=str(ZIP),
        new_regression_checks=46,new_measurements=False,owner_confirmation_pending=True,uncommitted=True)
    data['commit_update']['current_worktree_clean']=False
    data['commit_update']['subsequent_document_change']='R2 technical closure review; pending commit'
    with STATE.open('w',encoding='utf-8') as f: json.dump(data,f,ensure_ascii=False,indent=2)
    save('handoff-updated.json',dict(document_sha256=sha(DOC),state_sha256=sha(STATE),
        R2_technical_work_complete=True,R2_owner_exit_accepted=False,head=start['head'],uncommitted=True))
    print('Desktop MD/JSON refreshed; main HEAD unchanged, documented pending changes, historical tree unchanged')

if __name__=='__main__':{'pack':pack,'checks':checks,'handoff':handoff}[sys.argv[1]]()
