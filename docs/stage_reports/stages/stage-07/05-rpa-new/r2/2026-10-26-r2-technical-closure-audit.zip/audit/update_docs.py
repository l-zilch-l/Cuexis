from pathlib import Path
import json

ROOT=Path('D:/Cuexis-worktree');OUT=Path(__file__).resolve().parent
BASE=ROOT/'docs/stage_reports/stages/stage-07/05-rpa-new'
REPORT=BASE/'r2/2026-10-26-r2-technical-closure-review.md'
DOC=Path('C:/Users/Zilch/Desktop/Cuexis-Stage7-RPA-R3-接手实施文档-2026-10-26.md')

def change(path, pairs):
    text=path.read_text(encoding='utf-8')
    for old,new in pairs:
        assert text.count(old)==1,(str(path),old[:90],text.count(old))
        text=text.replace(old,new,1)
    path.write_text(text,encoding='utf-8',newline='\n')

assert json.loads((OUT/'fresh-regression.json').read_text(encoding='utf-8'))['tests']==46
assert json.loads((OUT/'evidence-audit.json').read_text(encoding='utf-8'))['obligations']['new_reanchor_and_triggered_investigation_completed']
assert not REPORT.exists()
(OUT/'before/7-parent-README.md').write_bytes((BASE/'README.md').read_bytes())
REPORT.write_text('''# R2 技术收尾复核与退出范围

状态：technical work complete / owner exit review pending。

日期：2026-10-26（Asia/Shanghai）。本轮依据用户“R2 你能继续做完吗”继续完成技术收尾。
唯一实施树为 `D:/Cuexis-worktree`，分支 `stage-7`，起点 HEAD 为
`c4bc5d4456ffe4778a90f9bae410638c0016a8eb`。本轮未改变产品源码、候选机制或性能阈值，
没有执行新的性能窗口。当前阶段以 [CURRENT_STATUS](../../../../../CURRENT_STATUS.md) 为准。

## 1. 退出评审结论

按[整改计划 §4.1、§5.3、§7](../../../../../stage_plans/active/stage-07/05-rpa-new/plan.md)，
R2 的实现、适用正确性/架构/包边界、实际布局、限定回滚，以及新身份候选局部收益证据已齐备；
技术工作完成，可提交限定范围的 owner 退出确认。原正式读取验收仍在 R4。

上一份[退出评审报告](2026-10-26-r2-exit-report.md)把三类事项统称为“完整退出条件尚未闭合”，
没有充分区分已经完成的诊断义务、历史不确定结果和证据适用范围。这一状态分类由本报告更正：

- R2 首版已新登记并完成 A/B/Q4 重锚。Q4/A 触发 1.19 调查后，已复核源/构建与成本结构，
  停止沿用旧阶梯收益分解，按登记完成独立候选对照；这项工作不是“尚未做”。
- 旧窗口保持 noisy / inconclusive。原计划没有要求所有历史诊断都必须改判通过才能结束 R2；
  它要求保存失败、遵守调查出口，以及对当前候选提供独立证据。
- 最新共用未变目标文件配置是正常 allocator、无产品插桩的真实公开读取对照，四规模局部收益和不退化门通过。
  默认 QoS/其他布局没有由它获得性能接受，是证据范围限制；原计划没有把所有系统调度策略或所有构建布局
  的性能推广列为 R2 必须完成的矩阵。SHARED 及消费者继续承担兼容门，R4 承担正式性能门。

本次更正不追认旧窗口通过，不把不同窗口拼乘成相对 A 的接受结果，也不把受控进程策略改成产品默认。
owner 退出接受尚未登记，不能用技术评审代替 owner 的最终确认。

## 2. 本轮亲自执行的核验

证据根：`D:/Cuexis-worktree/out/r2-closure-audit-20261026/`。

| 项目 | 本轮结果 | 证据边界 |
| --- | --- | --- |
| 历史新 A/B/Q4 身份 | 归档及逐项哈希相符 | A 877、B 962、Q4 962 个源码输入；每角色 24 个构建/编译器输入；Q4 对 B 恰为原登记五路径差异 |
| 重锚原始数据复算 | 9 进程、72 块一致 | 每块至少 603.493 ms；三对进程中位数、固定 t(2) 95% 区间及 15% 噪声；仍为不确定诊断 |
| 1.19 调查出口 | 已完成并保留 | `reanchor-investigation.json` 核对构建与成本结构，停止旧阶梯分解；没有新增轮次或替换样本 |
| 当前 R2 输入与性能 binding | 相符 | 当前九输入、冻结源/库/工具/依赖、共同驱动、两侧原实现对象及二进制；只读检查，无重建 |
| 当前受控局部结果复算 | 6 读取进程、192 块一致 | 四规模全部通过原局部收益、不退化与重复性门；HighQoS、mask=4、共用未变对象配置 |
| 新执行适用回归 | 46 项通过、0 失败 | 四 STATIC 配置各 10 项，SHARED Release 6 项；直接执行原 CTest 命令，独立日志，不覆写历史 Testing 记录 |
| 原轻量证据包 | 501 文件逐项验证通过 | 原 ZIP/清单保持字节不变；包内旧文档为形成时快照，不要求与更新后的当前状态页相同 |

本轮未重新构建五套矩阵，也未重跑消费者全套；完整矩阵/消费者继续沿用已绑定的历史证据及原范围说明。
本轮新回归不是新性能测量，没有将非计时测试的运行时长用于任何性能接受。

## 3. 保留的结果及适用范围

历史新重锚 N64：B/A 为 1.5828，95% 区间 [0.7940, 3.1549]；Q4/A 为 1.2098，
区间 [0.7039, 2.0793]；Q4/B 为 0.7644，区间 [0.6171, 0.9467]。各组存在噪声限定，
不作为旧 Q4 已复现、正式预算通过或已定位机器调度根因的证据。

当前受控局部对照仍为原独立登记结果，本轮只作复算：

| 规模 | E/B | 95% 区间 | 本配置局部结论 |
| --- | --- | --- | --- |
| N1 | 0.9082 | [0.8567, 0.9627] | 收益及不退化通过 |
| N8 | 0.8333 | [0.8177, 0.8492] | 收益及不退化通过 |
| N64 | 0.8197 | [0.7772, 0.8646] | 收益及不退化通过 |
| N256 | 0.8197 | [0.8057, 0.8339] | 收益及不退化通过 |

原独立构建 HighQoS 窗口的 N1 区间 [0.7851, 1.2120] 保持 inconclusive；新配置不替换该组。
默认 QoS 下的状态变化根因、其他构建布局的性能推广及正式共同 A 对照均不由此获得接受。
未测得的配置/DTO 字节复制量不解释为零；R2 没有依赖这些未知量宣称收益归因，它们按原归属由相关后续决策承接。

## 4. 建议确认的具体退出结论

接受 R2 第三候选在“内部读取整改实现、适用正确性与兼容验证、受控配置局部收益证明”范围内退出，
保留全部失败/不确定记录和已验证代码回滚点。R2 不再承担让历史诊断改判通过或把局部结果推广成生产保证的任务。

R4 仍按原 pre-PD A、普通性能构建、每单元三窗口九对与原 15%/1.10/95% 规则独立接受。
默认系统策略和实际集成构建的可比较性在具体 R4 profile/binding 中明确，不能直接继承共用对象的局部成绩。
R3 的源状态恢复、Seek 性能和内存问题按其自身依赖门实施；40k、ETW、设备、生产、发布及 Stage 7 关闭保持各自接受边界。

本报告完成技术工作和退出范围的具体整理。owner 接受待确认；“继续完成 R2”没有被写成已经接受任何技术豁免。

## 5. 复核附件

- [技术收尾审计清单](2026-10-26-r2-technical-closure-audit.json)：本轮独立复算、46 项新回归、文件哈希及原样保留证据的索引。
- [本轮审计轻量包](2026-10-26-r2-technical-closure-audit.zip)：审计工具、复算结果、新回归日志及本报告，不包含新性能样本。
- [原退出证据清单](2026-10-26-r2-exit-evidence.json)与[原 501 文件证据包](2026-10-26-r2-exit-evidence.zip)：保持原字节。

桌面 R3 接手文档与现场 JSON 同步记录“R2 技术工作完成，owner 退出待确认”；未将本轮收尾写成 R3 已开始。
''',encoding='utf-8',newline='\n')

status=ROOT/'docs/CURRENT_STATUS.md'
change(status,[('''- **R2 退出评审**：第三候选的实现、适用正确性验证及受控配置下四规模局部收益已有证据，退出报告与证据包已编制。
  原独立构建 N1 inconclusive、R0/Q4 重锚及默认配置推广缺口仍需处置，完整退出条件尚未闭合。
  见[退出评审报告](stage_reports/stages/stage-07/05-rpa-new/r2/2026-10-26-r2-exit-report.md)。''', '''- **R2 退出确认**：技术工作及退出范围复核完成，待 owner 确认。新 A/B/Q4 对照和触发调查已有历史证据，
  本轮独立复算并新执行 46 项适用回归；四规模受控局部结果通过，旧不确定结果及性能适用范围保留。
  见[技术收尾与退出范围](stage_reports/stages/stage-07/05-rpa-new/r2/2026-10-26-r2-technical-closure-review.md)。'''),
('R1 已退出；R2 退出报告/证据包已编制，待评审；受控局部门通过，原独立构建 N1 和 R0/Q4 缺口未闭合，R2 退出/R4 正式、设备与生产接受均未登记',
 'R1 已退出；R2 技术工作及退出范围复核完成、owner 退出待确认；受控局部门通过，历史不确定结果和推广限制保留；R3 未开始，R4 正式、设备与生产接受未登记')])

plan=ROOT/'docs/stage_plans/active/stage-07/05-rpa-new/plan.md'
change(plan,[('R2 退出评审报告及证据包已编制；受控局部门通过，原独立构建 N1 与 R0/Q4 等完整退出条件仍有缺口，R2 owner 退出/R4 正式接受未登记。当前承接见 §7.10；原判据保持。',
 'R2 技术工作及退出范围复核完成，owner 退出待确认；受控局部门通过，旧不确定结果与证据范围限制保留，R4 正式接受未登记。当前承接见 §7.11；原判据保持。'),
('### 7.10 R2 退出报告与证据整理','### 7.10 R2 退出报告与证据整理（形成时记录，状态分类由 §7.11 更正）'),
('## 8. R3：按归因选择准备、动态复制与可信恢复子项','''### 7.11 R2 技术收尾与退出范围复核

用户要求继续完成 R2 后，已完成[技术收尾复核](../../../../stage_reports/stages/stage-07/05-rpa-new/r2/2026-10-26-r2-technical-closure-review.md)。
新 A/B/Q4 对照及 1.19 触发调查已在 R2 首版按本计划实施，并非尚未完成；本轮核对归档身份、
独立复算 72 个重锚块和 192 个当前局部对照块，新执行五配置共 46 项适用回归，均通过。

§7.10 对“完整退出缺口”的分类过宽：旧 N1/Q4 的不确定结果仍保持原结论，
默认 QoS/其他构建布局的推广仍未接受，但不新增“所有历史窗口必须改判通过”或“所有调度策略必须通过”的 R2 门。
本节技术工作完成，可按内部整改与受控局部证据范围提交 owner 退出确认；owner 接受未登记。
R4 原共同 A、三窗口九对、15%/1.10/95% 门及设备/生产接受均不由局部成绩代替。
本轮无新产品机制、新构建或性能窗口，旧原始证据/501 文件归档保持不变。

## 8. R3：按归因选择准备、动态复制与可信恢复子项'''),
('R1 已退出，R0 保持历史残余。R2 当前位置为 §7.10：退出报告与证据包已编制，待评审；受控局部门通过，但原独立构建 N1、R0/Q4 等完整退出条件仍有缺口，owner 退出未登记。旧窗口不重跑或补样，不将内部消融替代公开提帧接受。R2/R4 未退出，R3、正式窗口、40k、ETW 和设备接受仍独立。下列原设计顺序保留为历史来源，不作为当前未完成的 R1 清单：',
 'R1 已退出，R0 保持历史残余。R2 当前位置为 §7.11：技术工作及退出范围复核完成，owner 退出待确认；新重锚/触发调查已经完成，旧不确定结果保留，当前四规模受控局部结果通过。旧窗口不重跑或补样，不将内部消融替代公开提帧接受。R4、R3、正式窗口、40k、ETW 和设备接受仍按各自边界判断。下列原设计顺序保留为历史来源，不作为当前未完成的 R1 清单：')])

change(BASE/'r2/2026-10-26-r2-exit-report.md',[
('状态：candidate / exit review pending；实现及受控局部验证已有证据，完整退出条件尚未闭合。',
 '''状态：historical review snapshot / superseded status classification。

本报告形成时将历史限制统称为退出缺口。后续[技术收尾复核与退出范围](2026-10-26-r2-technical-closure-review.md)
已核实新重锚/触发调查的完成证据，并更正该分类；当前为“技术工作完成，owner 退出待确认”。
以下保留当时评审文本，原证据包保持原字节；当前结论以上述后续报告及 CURRENT_STATUS 为准。''')])

change(BASE/'r2/README.md',[
('退出核对入口：[2026-10-26 · R2 退出评审报告与证据汇总](2026-10-26-r2-exit-report.md)。报告请求不等于退出接受。',
 '退出核对入口：[2026-10-26 · R2 技术收尾复核与退出范围](2026-10-26-r2-technical-closure-review.md)。技术工作完成，owner 退出待确认；原评审报告保留形成时记录。'),
('| 日期 / 报告 | 证据附件 |','| 日期 / 报告 | 证据附件 |'),
('| [2026-10-26 · R2 退出评审报告与证据汇总](2026-10-26-r2-exit-report.md) | [SHA-256 清单](2026-10-26-r2-exit-evidence.json)、[轻量证据包](2026-10-26-r2-exit-evidence.zip) |',
 '| [2026-10-26 · R2 退出评审报告与证据汇总](2026-10-26-r2-exit-report.md) | [SHA-256 清单](2026-10-26-r2-exit-evidence.json)、[轻量证据包](2026-10-26-r2-exit-evidence.zip) |\n| [2026-10-26 · R2 技术收尾复核与退出范围](2026-10-26-r2-technical-closure-review.md) | [审计清单](2026-10-26-r2-technical-closure-audit.json)、[审计轻量包](2026-10-26-r2-technical-closure-audit.zip) |')])
change(BASE/'README.md',[('| `r2` | 7 / 2 |','| `r2` | 8 / 4 |')])
with (BASE/'evidence-catalog.md').open('a',encoding='utf-8',newline='\n') as f:
    f.write('| [R2 技术收尾复核与退出范围](r2/2026-10-26-r2-technical-closure-review.md) | [审计清单](r2/2026-10-26-r2-technical-closure-audit.json)、[审计轻量包](r2/2026-10-26-r2-technical-closure-audit.zip)；`D:/Cuexis-worktree/out/r2-closure-audit-20261026/`；历史新重锚原始材料 `D:/Cuexis-pd5-40k-admission/out/rpa-r2-20261025/diagnostic/` |\n')

change(DOC,[('状态：handoff / R3 implementation not started；R2 exit review pending。',
 '状态：handoff / R3 implementation not started；R2 technical work complete / owner exit confirmation pending。'),
('已将 `docs/CURRENT_STATUS.md` 的“当前任务”精简提交，当前主树核验为干净。',
 '已将 `docs/CURRENT_STATUS.md` 的“当前任务”精简提交；随后完成 R2 技术收尾复核，当前有本轮文档与审计附件改动尚未提交。'),
('R1 已退出。R2 第三候选 direct borrowed Result 保留，退出报告/证据整理完成，但完整退出条件尚未闭合，\n未记录 owner 退出接受。该状态不因用户要求准备 R3 文档而改变。',
 'R1 已退出。R2 第三候选 direct borrowed Result 保留；技术工作及退出范围复核完成，owner 退出待确认。\n新 A/B/Q4 对照及触发调查已核验完成；旧不确定结果与性能适用范围保留，不再将其统称为尚未完成的 R2 技术门。'),
('R2 剩余状态见 §7.10，正式矩阵见 §9。','R2 当前状态见 §7.11，正式矩阵见 §9。'),
('4. `D:/Cuexis-worktree/docs/stage_reports/stages/stage-07/05-rpa-new/r2/2026-10-26-r2-exit-report.md`：\n   退出条件表、复用证据与缺口；同目录 `2026-10-26-r2-exit-evidence.json/.zip` 是 501 文件轻量归档。',
 '4. `D:/Cuexis-worktree/docs/stage_reports/stages/stage-07/05-rpa-new/r2/2026-10-26-r2-technical-closure-review.md`：\n   技术收尾、原要求与证据范围核对；同目录原退出报告/501 文件归档为历史快照，新 technical-closure-audit.json/.zip 是本轮审计材料。'),
('原独立构建 HighQoS 窗口 N1 仍 inconclusive（区间上界 1.2120），\nR0/Q4 历史重锚缺口、默认 QoS/其他构建布局推广与 R4 正式接受均未闭合，不能仅补一份批准代替技术证据。',
 '原独立构建 HighQoS 窗口 N1 仍 inconclusive（区间上界 1.2120）。\n首版 R2 新重锚及 1.19 调查已完成；本轮复核 72 个重锚块、192 个受控局部块并新执行 46 项适用回归，全部核验相符/通过。\n默认 QoS/其他构建布局的性能推广和 R4 正式接受仍无此组证据；这些范围限制不新增为所有历史窗口必须通过的 R2 门。'),
('同名 `.现场核验.json` 已在提交后刷新，登记新 HEAD 与干净主树；不是脚本、源备份或测试通过证明。',
 '同名 `.现场核验.json` 已在 R2 技术收尾后刷新，登记 HEAD 与本轮未提交文档状态；不是脚本、源备份或测试通过证明。')])
print('Updated technical closure report, current status, plan and Desktop handoff; owner acceptance remains pending')
