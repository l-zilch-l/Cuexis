"""Read-only R2 closure evidence review; never rerun historical windows/builds."""
from pathlib import Path
import datetime, hashlib, json, math, statistics, subprocess, sys, zipfile, re, os

ROOT = Path('D:/Cuexis-worktree')
OUT = Path(__file__).resolve().parent
HIST = Path('D:/Cuexis-pd5-40k-admission/out/rpa-r2-20261025')
COMMON = ROOT/'out/r2-common-objects-20261026'
ARCHIVES = Path('D:/Cuexis-worktree-evidence/cleanup/20261025-worktree-cleanup-7e49c2')
DESKTOP = Path('C:/Users/Zilch/Desktop')
HANDOFF = DESKTOP/'Cuexis-Stage7-RPA-R3-接手实施文档-2026-10-26.md'

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''): h.update(b)
    return h.hexdigest()

def load(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(name, value):
    p = OUT/name
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('x', encoding='utf-8') as f: json.dump(value, f, indent=2, ensure_ascii=False)
def git(*args, cwd=ROOT): return subprocess.check_output(['git', *args], cwd=cwd)
def snapshot():
    names = git('ls-files', '--cached', '--others', '--exclude-standard', '-z').decode().split('\0')
    return {n: sha(ROOT/n) for n in sorted(set(names)) if n and (ROOT/n).is_file()}

def prepare():
    assert not git('status', '--porcelain=v1', '-z').strip()
    docs = [ROOT/'docs/CURRENT_STATUS.md', ROOT/'docs/stage_plans/active/stage-07/05-rpa-new/plan.md',
        ROOT/'docs/stage_reports/stages/stage-07/05-rpa-new/r2/README.md',
        ROOT/'docs/stage_reports/stages/stage-07/05-rpa-new/r2/2026-10-26-r2-exit-report.md',
        ROOT/'docs/stage_reports/stages/stage-07/05-rpa-new/evidence-catalog.md',
        HANDOFF, HANDOFF.with_suffix('.现场核验.json')]
    for i, p in enumerate(docs):
        (OUT/'before').mkdir(exist_ok=True)
        (OUT/'before'/f'{i}-{p.name}').write_bytes(p.read_bytes())
    save('start.json', dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        head=git('rev-parse','HEAD').decode().strip(), files=snapshot(),
        historical_head=git('rev-parse','HEAD',cwd=HIST.parents[1]).decode().strip(),
        historical_status=git('status','--porcelain=v1','-z',cwd=HIST.parents[1]).decode(),
        desktop={str(p):sha(p) for p in docs[-2:]}, request='Continue and complete R2',
        method='Check original obligations and evidence without adding acceptance gates or replacing samples'))
    print('Preserved clean start and document bytes', flush=True)

def interval(values):
    x = [math.log(v) for v in values]
    m = statistics.mean(x)
    half = 4.302653 * statistics.stdev(x) / math.sqrt(3)
    return math.exp(m), [math.exp(m-half), math.exp(m+half)]

def reduce_group(directory, result_name, anchor=False):
    result = load(directory/result_name)
    plan = load(directory/'registration.json')
    assert result['status']=='complete' and result['formal_measurement'] is False
    roles = ['A','B','Q4'] if anchor else ['B','E']
    scales = [64] if anchor else [1,8,64,256]
    orders = plan['protocol']['reanchorOrders' if anchor else 'pairs']
    assert [(r['round'],r['role']) for r in result['processes']] == [(i, r) for i,o in enumerate(orders,1) for r in o]
    fixture = load(directory/'fixture-validation.json')['records']['A']['identities'] if anchor else plan['fixture']
    data = {}; count = 0; minimum = math.inf
    for r in result['processes']:
        log = Path(r['log']); assert sha(log)==r['sha256']
        warm = Path(r['warmupLog'] if anchor else r['outputs']['warmup']['log'])
        assert sha(warm)==(r['warmupSha256'] if anchor else r['outputs']['warmup']['sha256'])
        assert '"seconds":30' in warm.read_text(encoding='utf-8')
        blocks = {}; ids = {}; current = None; environments=[]
        for line in log.read_text(encoding='utf-8').splitlines():
            if line.startswith('PD_R2_SCALE '):
                current = json.loads(line[12:])['objects']; assert current not in blocks; blocks[current]=[]
            elif line.startswith('PD_V2 '):
                row = json.loads(line[6:])
                if row['kind']!='read_long': continue
                assert row['group']==len(blocks[current])
                assert row['operations']==int(plan['protocol']['reads'][str(current)])
                us=row['sample']['wall_us']; assert us>=100000
                minimum=min(minimum,us); count+=1
                blocks[current].append(us/row['operations']*1000)
            elif line.startswith('PD_FORMAL_ID '):
                row=json.loads(line[len('PD_FORMAL_ID '):]); assert row['objects']==current
                assert row['allocator']=='normal' and row['metrics_compile_enabled'] is False
                expected=next(x for x in fixture if x['objects']==current)
                for key in ['digest','packed_sha256','snapshot_sha256','replay_sha256']: assert row[key]==expected[key]
                ids[current]=row
            elif line.startswith('PD_ENV '): environments.append(json.loads(line[7:]))
        assert list(blocks)==scales and set(ids)==set(scales)
        assert len(environments)==2*len(scales)
        assert all(e['process_affinity']==4 and e['process_affinity_error']==0 for e in environments)
        for n, values in blocks.items():
            assert len(values)==8
            median=statistics.median(values); spread=(max(values)-min(values))/median
            assert values==r['scales'][str(n)]['blocksNs'] and median==r['scales'][str(n)]['medianNs']
            data[(r['round'],r['role'],n)]=(median,spread)
    summaries={}
    for n in scales:
        noise={}
        for role in roles:
            medians=[data[i,role,n][0] for i in [1,2,3]]
            within=[data[i,role,n][1] for i in [1,2,3]]
            between=(max(medians)-min(medians))/statistics.median(medians)
            noise[role]=dict(within=within,between=between,failed=between>.15 or max(within)>.15)
        for candidate, baseline in ([('B','A'),('Q4','A'),('Q4','B')] if anchor else [('E','B')]):
            key=f'reanchor/N{n}/{candidate}/{baseline}' if anchor else f'N{n}/{candidate}/{baseline}'
            ratios=[data[i,candidate,n][0]/data[i,baseline,n][0] for i in [1,2,3]]
            ratio, ci=interval(ratios); old=result['contrasts'][key]
            assert abs(ratio-old['paired']['geometric_ratio'])<1e-12
            assert all(abs(a-b)<1e-12 for a,b in zip(ci,old['paired']['ci95']))
            noisy=noise[candidate]['failed'] or noise[baseline]['failed']; assert noisy==old['noisy']
            summaries[key]=dict(ratio=ratio,ci95=ci,noisy=noisy,local_nonregression=not noisy and ci[1]<=1.1,
                local_benefit=not noisy and ci[1]<1)
    return dict(processes=len(result['processes']),blocks=count,min_block_us=minimum,
        registration_sha256=sha(directory/'registration.json'),contrasts=summaries,noise=noise,
        results_sha256=sha(directory/result_name),raw_readback=True)

def evidence():
    registration=load(HIST/'diagnostic/registration.json')
    archive_manifest=load(ARCHIVES/'archive-complete.json')
    bindings={}
    for role in ['A','B','Q4']:
        b=registration['bindings'][role]; root=Path(b['root'])
        entry=next(x for x in archive_manifest['targets'] if Path(x['archive']).name==root.name+'.zip')
        archive=Path(entry['archive']); assert sha(archive)==entry['archive_sha256']
        print('Reading archived source/build identity',role,flush=True)
        with zipfile.ZipFile(archive) as z:
            for rel,h in b['sourceFiles'].items(): assert hashlib.sha256(z.read(root.name+'/'+rel)).hexdigest()==h
            build_count=0
            for name,h in b['buildFiles'].items():
                path=Path(name)
                if path.is_relative_to(root):
                    actual=hashlib.sha256(z.read(root.name+'/'+path.relative_to(root).as_posix())).hexdigest()
                else: actual=sha(path)
                assert actual==h,(role,name); build_count+=1
        bindings[role]=dict(archive=str(archive),archive_sha256=sha(archive),
            source_files=len(b['sourceFiles']),build_files=build_count)
    migration=load(HIST/'q4-migration.json')
    delta=[p for p,h in registration['bindings']['B']['sourceFiles'].items() if registration['bindings']['Q4']['sourceFiles'].get(p)!=h]
    assert sorted(delta)==sorted(x['path'] for x in migration['changes']) and len(delta)==5
    anchor=reduce_group(HIST/'diagnostic','reanchor-results.json',True)
    assert anchor['blocks']==72
    investigation=load(HIST/'diagnostic/reanchor-investigation.json')
    assert investigation['sourceBuildBindingReviewed'] and investigation['costStructureReviewed']
    assert anchor['contrasts']['reanchor/N64/Q4/A']['ratio']>=1.19
    assert 'Do not use the old ladder' in investigation['disposition']
    print('Independently reduced historical A/B/Q4: 9 processes, 72 blocks; inconclusive retained',flush=True)
    common=reduce_group(COMMON,'results.json')
    assert common['blocks']==192 and all(x['local_benefit'] for x in common['contrasts'].values())
    p=load(COMMON/'registration.json')
    for name,h in p['main_r2_inputs'].items(): assert sha(ROOT/name)==h
    for name,h in p['common_artifacts'].items(): assert sha(name)==h
    build=load(COMMON/'build.json')
    for role,b in build['roles'].items():
        for name,o in b['objects'].items(): assert sha(name)==o['sha256'] and sha(o['original_library'])==o['original_library_sha256']
    reg=load(ROOT/'out/r2e-20261026/regression.json')
    for r in reg['fresh_focused_regression']: assert r['exit']==0 and sha(r['log'])==r['sha256']
    save('evidence-audit.json',dict(archived_reanchor_bindings=bindings,q4_delta=delta,
        historical_reanchor=anchor,investigation_sha256=sha(HIST/'diagnostic/reanchor-investigation.json'),
        common_object_local_performance=common,current_inputs=len(p['main_r2_inputs']),
        obligations=dict(new_reanchor_and_triggered_investigation_completed=True,
            historical_inconclusive_must_become_pass=False,default_QoS_performance_claim=False,
            local_performance_scope='Release STATIC, HighQoS, mask4, normal allocator, common unchanged objects',
            owner_exit_acceptance=False,r4_acceptance=False),new_measurements=False))
    print('Current nine inputs and all four-scale local gates verified; no new measurement',flush=True)

def regression():
    previous=load(ROOT/'out/r2e-20261026/regression.json')
    pattern=re.compile(r'^R2 (borrowed|warmed|consumer|materializer|public|preserves|camera|original)|^cuexis_architecture_tests$')
    rows=[]
    env={k:v for k,v in os.environ.items() if not k.startswith('CUEXIS_')}
    scratch=OUT/'scratch';scratch.mkdir(exist_ok=False)
    env.update(TEMP=str(scratch),TMP=str(scratch),TMPDIR=str(scratch),PYTHONDONTWRITEBYTECODE='1')
    for old in previous['fresh_focused_regression']:
        label=old['label']; directory=old['args'][old['args'].index('--test-dir')+1]
        raw=subprocess.check_output(['ctest','--test-dir',directory,'--show-only=json-v1'],env=env)
        (OUT/(label+'-test-list.json')).write_bytes(raw)
        tests=[t for t in json.loads(raw)['tests'] if pattern.search(t['name'])]
        assert len(tests)==(6 if label.startswith('shared') else 10)
        for i,t in enumerate(tests):
            properties={p['name']:p['value'] for p in t['properties']}
            assert 'command' in t and not properties.get('DISABLED')
            log=OUT/'logs'/f'{label}-{i+1}.log';log.parent.mkdir(exist_ok=True)
            cwd=properties.get('WORKING_DIRECTORY',directory)
            runenv=dict(env)
            for entry in properties.get('ENVIRONMENT',[]):
                k,v=entry.split('=',1); runenv[k]=v
            before=sha(t['command'][0]) if Path(t['command'][0]).is_file() else None
            with log.open('xb') as f:
                p=subprocess.run(t['command'],cwd=cwd,env=runenv,stdout=f,stderr=subprocess.STDOUT,timeout=180)
            assert p.returncode==0,(label,t['name'],log.read_text(encoding='utf-8',errors='replace')[-2000:])
            assert before is None or before==sha(t['command'][0])
            rows.append(dict(configuration=label,name=t['name'],command=t['command'],cwd=cwd,
                exit=p.returncode,log=str(log),sha256=sha(log),binary_sha256=before))
        print(label,len(tests),'checks passed; frozen CTest logs not overwritten',flush=True)
    assert len(rows)==46
    save('fresh-regression.json',dict(tests=46,failures=0,rows=rows,
        method='Execute the selected original CTest commands directly; preserve frozen Testing logs; no rebuild or timing inference'))

if __name__=='__main__': {'prepare':prepare,'evidence':evidence,'regression':regression}[sys.argv[1]]()
