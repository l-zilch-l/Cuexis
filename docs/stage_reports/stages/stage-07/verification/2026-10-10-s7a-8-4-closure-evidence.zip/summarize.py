import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
HEAD = '1ebcbdc92d92fa9d45e4e1f835e5a1f338e7fc2d'
BASE = '3076948ce403ea0da6fbe389835b6a4c9defbcd3'
TREE = '90f930a97ee2e2980fec12de3334b687ac529064'
IDS = [37956834652, 37956834670, 37956834625, 37956834723,
       37956824754, 37956824929, 37956824742]

def read(name):
    return json.loads((OUT / name).read_text(encoding='utf-8-sig'))

pr = read('pr.json')
assert pr['headRefOid'] == HEAD and pr['baseRefOid'] == BASE
assert pr['headRefName'] == 'stage-7' and pr['state'] == 'OPEN'
checks = pr['statusCheckRollup']
assert len(checks) == 41
assert sum(c['conclusion'] == 'SUCCESS' for c in checks) == 39
assert sum(c['conclusion'] == 'SKIPPED' for c in checks) == 2
assert all(c['status'] == 'COMPLETED' for c in checks)
runs = [r for r in read('runs.json')['workflow_runs'] if r['head_sha'] == HEAD]
assert {r['id'] for r in runs} == set(IDS)
assert all(r['status'] == 'completed' and r['conclusion'] == 'success' for r in runs)
assert subprocess.check_output(['git', 'rev-parse', HEAD + '^{tree}'], cwd=ROOT, text=True).strip() == TREE
approval = read('approval.json')
expected = dict(repository='l-zilch-l/Cuexis', pr=32, base_sha=BASE,
                candidate_sha=HEAD, candidate_tree_sha=TREE,
                **{'from': '0.7.0', 'to': '0.7.1', 'utc_date': '2026-10-09'})
assert approval['user']['login'] == 'l-zilch-l' and approval['user']['type'] == 'User'
assert approval['created_at'] == approval['updated_at']
assert approval['body'].startswith('cuexis-sdk-api-approval-v1\n')
assert json.loads(approval['body'].split('\n', 1)[1]) == expected
records = [json.loads(s) for s in (OUT / 'owner-approval-records.jsonl').read_text(encoding='utf-8-sig').splitlines() if s]
assert max(r['id'] for r in records if r['user'] == 'l-zilch-l') == approval['id'] == 6084640280
gate_log = (OUT / 'version-gate.log').read_text(encoding='utf-8-sig')
pass_line = next(s for s in gate_log.splitlines() if 'version.gate.pass:' in s)
assert all(s in pass_line for s in ['context=live', BASE, HEAD, 'trusted_utc_date=2026-10-09',
                                  'sdk_owner_approval_comment_id=6084640280'])
all_jobs = []
for run in runs:
    name = 'version-jobs.json' if run['id'] == IDS[0] else f"jobs-{run['id']}.json"
    data = read(name)
    assert data['total_count'] == len(data['jobs'])
    assert all(j['head_sha'] == HEAD and j['status'] == 'completed' for j in data['jobs'])
    all_jobs += data['jobs']
assert len(all_jobs) == 41
assert sum(j['conclusion'] == 'success' for j in all_jobs) == 39
skips = [j for j in all_jobs if j['conclusion'] == 'skipped']
assert {j['name'] for j in skips} == {'Version advancement (post-merge audit)',
                                    'Version advancement (historical revalidation)'}
assert all(not j['steps'] for j in skips)
gate_job = next(j for j in all_jobs if j['name'] == 'Version advancement (pre-merge)')
assert any(s['name'] == 'Run trusted version-gate tests and checker' and s['conclusion'] == 'success'
           for s in gate_job['steps'])
rules = read('ruleset.json')
assert rules['enforcement'] == 'active' and not rules['bypass_actors']
assert rules['current_user_can_bypass'] == 'never'
assert rules['conditions']['ref_name'] == {'include': ['refs/heads/master'], 'exclude': []}
by_type = {r['type']: r for r in rules['rules']}
assert {'pull_request', 'deletion', 'non_fast_forward', 'required_status_checks'} <= by_type.keys()
checks_rule = by_type['required_status_checks']['parameters']
assert checks_rule['strict_required_status_checks_policy']
assert {'context': 'Version advancement (pre-merge)', 'integration_id': 15368} in checks_rule['required_status_checks']
classic = read('classic-protection.json')
assert classic['enforce_admins']['enabled'] and classic['required_status_checks']['strict']
assert not classic['allow_force_pushes']['enabled'] and not classic['allow_deletions']['enabled']
summary = dict(acceptance_head=HEAD, tree=TREE, base=BASE, sdk='0.7.1', build='26.10.09-2',
               approval_comment_id=approval['id'], successful_runs=7, successful_jobs=39,
               skipped_jobs=[j['name'] for j in skips],
               runs=[{k:r[k] for k in ['id','name','event','head_sha','run_attempt','status','conclusion','updated_at']} for r in runs],
               actual_version_pass=pass_line, source_exception='accepted 2026-10-10; ordinary PR only; queue disabled',
               limitations=['No new local C++ build or device validation',
                            'RPA product implementation not authorized', 'S7A-9 final acceptance not performed'])
(OUT / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
files = sorted(p for p in OUT.iterdir() if p.is_file() and p.name != 'SHA256SUMS.txt')
(OUT / 'SHA256SUMS.txt').write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}\n' for p in files), encoding='utf-8')
archive = ROOT / 'docs/stage_reports/stages/stage-07/verification/2026-10-10-s7a-8-4-closure-evidence.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for p in files + [OUT / 'SHA256SUMS.txt']:
        z.write(p, p.name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
print('PASS: exact acceptance tuple, 7 successful runs, 39 successful jobs, 2 event-only skips, approval, trusted gate, protection')
print(f'Evidence ZIP: {archive}; bytes={archive.stat().st_size}')
