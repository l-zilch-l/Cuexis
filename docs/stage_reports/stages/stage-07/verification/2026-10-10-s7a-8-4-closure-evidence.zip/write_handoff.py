from pathlib import Path

desktop = Path('C:/Users/Zilch/Desktop')
target = desktop / 'Cuexis-Stage7-RPA-审核接手-2026-10-10.md'
text = r'''# Cuexis Stage 7-RPA 审核接手

快照日期：2026-10-10（Asia/Shanghai）。这是接手快照，当前状态唯一来源仍为仓库docs/CURRENT_STATUS.md。

## 下次对话目标与授权

下一次对话以审核Stage 7-RPA子阶段为目标。先查实际代码和现行合同，复验架构与命名审查输入，
给出合同缺口、可选择方案、影响面、验证设计与实施准入顺序。继续遵守“只规划，不进行实施”；
除非owner另行明确授权，不启动产品代码重构、线程化、时钟变更或诊断码迁移。
不把已有候选推荐当作字段冻结，不扩大生产预算，不借审核重开已完成S7A-3/4/5/6规则。

## 已核验的7/8基线

- 工作目录：D:\Cuexis-worktree，现有stage-7分支、现有PR #32；不另建PR，不reset/force push。
- 验收HEAD：1ebcbdc92d92fa9d45e4e1f835e5a1f338e7fc2d。
- 验收tree：90f930a97ee2e2980fec12de3334b687ac529064。
- 可信master/base：3076948ce403ea0da6fbe389835b6a4c9defbcd3。
- SDK0.7.1，日期构建26.10.09-2；本次核对时本地10-10、UTC仍10-09，日期构建遵循UTC。
- owner精确审批评论6084640280，八字段绑定上述head/tree/base及0.7.0→0.7.1/UTC2026-10-09。
- 七个run全部success：PR Version37956834652、Linux37956834670、MSVC37956834625、MinGW37956834723；
  push Linux37956824754、MSVC37956824929、MinGW37956824742。
- 39个job成功；post-merge audit/historical revalidation两job不适用PR事件而skip，不冒充实际执行。
- Version Gate真实日志为context=live，从可信base取checker/tests，采用审批6084640280。
- owner于本轮明确要求关闭8.4；S7A-8.4已退出，S7A-7/8受限批次完成；Stage7A仍active。
- 关闭报告：docs/stage_reports/stages/stage-07/verification/2026-10-10-s7a-8-4-closure.md。
- 原始证据ZIP与报告同目录；工作输出out/s7a84-closeout-20261010/。
- 本次关闭记录只证明验收HEAD，不能证明后续文档提交的CI成功；最终交付绑定见文末追加。

## 保护与审批边界

ruleset24799746 active，仅master；必须PR、strict Version advancement (pre-merge)/App15368，
禁止强推/删除、无bypass；classic protection保留。个人单人仓库不能指定workflow来源，owner已明确接受
VERSIONING的有范围例外；不再将该项列为8.4阻断。真实base checker、准确审批、实际日志核对保持，queue禁用。
新增维护者、改变服务/仓库归属或启用queue时重审。例外不等于不可伪造来源保证。
使用已授权审批助手tools/prepare_sdk_approval.cmd可直接发布并回读，代理固定127.0.0.1:7890；
新HEAD必须重新绑定，不能复用旧评论。本轮不合并、发行、修改master或继续改保护。

## 必须读取的权威顺序

1. AGENTS.md、docs/CURRENT_STATUS.md（历史AGENTS产品阶段描述可能滞后，以现状和CURRENT_STATUS为准）。
2. docs/stage_plans/active/stage-07/plan.md：产品边界、冻结顺序及7A/RPA/7B+关系。
3. 同目录plan-a.md §3.1、§3.4.18–22；7/8关闭报告及其引用的10-08 C78/R78逐行合同/验收表。
4. 同目录plan-rpa.md：RPA唯一active分册；plan-b.md及Stage8计划用于验证后续依赖。
5. docs/adr/0046-realtime-playback-coordination.md（candidate，线程模型未正式冻结）。
6. docs/api/realtime-host-boundary.md（candidate，TB-01–07未闭合）。
7. docs/stage_reports/stages/stage-07/readiness/2026-10-09-realtime-architecture-review.md。
8. 同目录2026-10-09-diagnostic-phase-name-audit.md。
9. 按首次消费逐项查Gameplay V2 Spec/ABI、execution/author profile、Replay/Recovery/Snapshot、
   Playback lifecycle/control、Audio、Animation/Presentation、Entry/Graph/Capsule/CXC和VERSIONING。
10. 实际Player主循环/输入适配、Playback推进/表现采样、Kernel/Fold/journal/owning结果、
    Audio服务/设备观察和Renderer资源所有权代码；与报告反例对照，不只复述规划。

## RPA审核要解决什么

架构线RPA-A0已有审查输入；A1–A3仍需字段/验证设计/线程选择。五项责任为输入捕获、音频服务、
确定性执行、表现采样和设备提交，责任数不等于线程数。先比较所有权与调度，不能默认三线程/无锁解决一切。
检查每帧完整Replay、journal/RuntimeState/公开result复制和长期retention的实际增长成本，
避免仅把增长成本搬入worker。Prepared/renderer跨域、资源版本、控制fence和关闭/分配失败先写合同。

- TB-01：捕获/交付/准入时点及canonical Tick来源，原始时间重建若改变语义须明确修订。
- TB-02：输入交付进度与advance许可，不误把watermark当输入完整性，不回改sealed Miss。
- TB-03：真实同Tick碰撞支持；当前拒绝规则仍适用，不能在adapter偷偷加Tick绕过。
- TB-04：mixed/consumed/presented estimate、有效性/误差/欠载/恢复及一致快照。
- TB-05：44.1k/48k有理换算、offset归属与一次舍入，防重复补偿和整数越界。
- TB-06：无音频、暂停、失效时钟、音轨结束与尾判完成的独立边界。
- TB-07：暂停期间真实release和Resume/focus策略，候选未选，不伪造/丢弃release。

命名线：已审计67个定义，66个正式命名迁移候选和1个占位处置。
复核定义/消费者/动态构造/公共投影/严格恢复校验，不能靠阶段前缀决定公开性。
检查sourceCode、旧owning结果、Recovery/Replay旧新bytes/digest与revision、SDK patch/minor影响；
历史报告和算法版本不能批量改名。当前命名仍有效，审核阶段不实际替换字符串。

验证设计分开：只改渲染节奏、已捕获输入延迟交付、输入本身延迟捕获。
只有同admission/control轨迹可无条件比较完整确定性结果；其他按捕获/late-policy合同验收。
人工golden、独立oracle（不调用生产推进）、故障注入、完整ReplayEvaluation比较、长历史成本均需明确。
100/500ms等只作故障注入，不能默认成为生产容忍阈值。设备证据独立，不能用Replay=same代替听音/物理输入。

## 后续阶段与停止边界

RPA是Stage7内子阶段，不放future；canonical为active/stage-07/plan-rpa.md，不另造active计划副本。
实体DFJK/Hold、真实听音、设备失效恢复、GPU反馈像素、卡顿/刷新率与音频判定表现同步均归RPA。
真实Player失速和同步问题仍未修复；历史设备失败与未执行项原样交接，不把7/8关闭当设备通过。
S7A-9仅保留原内核/公共消费者范围的最终矩阵、预算/容量及owner交接验收；本次只累计测量准备。
RPA和S7A-9不互相代验；审核RPA不要求先关闭Stage7A。
Stage7B+独立高级能力线保留（包括高级校准），Stage8消费7A、RPA和明确选入已验收的7B+能力，
不要求整个7B+先结束。不得跳入S7B+/S7C实施、Stage8正式发行或Stage7A关闭。

保留单一实际kernel/Fold、完整ReplayEvaluation、exact H按F(H)、watermark/工作Tick分离、
future pending/lastObservedTick/archive/cut/H checkpoint/惰性分支、sealed Fact/失败Tick无token、
faulted只读不改画面、mutation generation/projection scope分离、恢复重取当前绑定资源、
Graph整数不经f64及正确层重复键/count/bounds拒绝、不安装内部Kernel/Recovery、不扩大既有物理限额。

## 预期审核产物和文档规则

给出带代码/合同定位的最小反例、影响模块、首用修订清单、候选与取舍、可执行依赖顺序及验证缺口；
区分已核验、候选推荐、未冻结、未执行。先完善A1–A3/N1准入，不将审核结论写成产品实施成功。
当前状态只更新CURRENT_STATUS；决策归plan-rpa与所属合同；审核证据归带日期报告并加入索引；
同步本桌面接手。文档修改跑check_docs、适用合同测试、diff --check；产品未变不虚构C++测试。
保留用户已有改动；先检查实际branch/HEAD/status/diff，文末SHA仅为接手快照，不reset到历史提交。

## 下次对话可直接使用的指令

阅读桌面接手文档C:\Users\Zilch\Desktop\Cuexis-Stage7-RPA-审核接手-2026-10-10.md。
在D:\Cuexis-worktree现有stage-7分支、PR #32上，以审核Stage7-RPA子阶段为本轮目标。
先核对branch/HEAD/status/diff并保留未提交改动；依接手顺序阅读权威文档和实际代码。
复验RA反例，审核TB-01–07、A1–A3/N1、命名兼容与独立验证设计，给出首用合同缺口、
可比较方案、影响面、实施准入及依赖顺序，写回canonical规划和dated审核报告。
只规划不实施，不扩大预算，不重开已完成规则，不另建PR、不改master/保护、不合并/发行，
不开展S7A-9最终关闭或进入7B+/Stage8实施。保持7A/RPA/7B+完整路线和真实设备未通过事实。
'''
target.write_text(text, encoding='utf-8')
old = desktop / 'Cuexis-S7A-7-8-接手文档-2026-10-07.md'
with old.open('a', encoding='utf-8', newline='') as f:
    f.write('\n\n## 2026-10-10 S7A-8.4关闭与下一子阶段审核（最新入口）\n\n')
    f.write('owner要求关闭8.4；已核验1ebcbdc的七个run全部success、39个job成功/2个事件skip，\n')
    f.write('准确审批6084640280、trusted base实际日志及保护/来源例外均收齐，S7A-8.4退出，7/8受限批次完成。\n')
    f.write('Stage7A保持active；设备/同步及架构/命名归RPA，S7A-9最终验收未执行，Stage7B+保留。\n')
    f.write('下一次对话目标为审核Stage7-RPA，继续只规划、不实施。详细接手入口：\n')
    f.write(str(target) + '\n')
    f.write('关闭报告：docs/stage_reports/stages/stage-07/verification/2026-10-10-s7a-8-4-closure.md。\n')
print(target)
