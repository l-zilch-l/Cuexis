Version Gate and RPA/7B+ documentation verification, 2026-10-09.
Baseline d33c64b15575a945e50948ad70acb88f05117dce; trusted master 3076948ce403ea0da6fbe389835b6a4c9defbcd3.
Live API before changes rejects latest owner approval 6078336026 because it binds 1afe382, not current HEAD. This is expected security behavior, not a bypassable checker defect.
Trusted tools are exact git-show bytes; Windows trusted 19-test run includes one shell failure; Linux same tools 19/19 pass. Candidate Windows 26 tests pass with 2 skips.
Only docs/evidence are committed. Final approval draft is created after commit, outside the repository, so it cannot claim to authorize itself. Owner must post it; no owner comment or approval was sent by agent. No master/branch protection changes.
