### 3.4.18 实时架构重审与规划（2026-10-09）

**本轮范围。** owner要求先重审整体架构，再明确共同时间、所有权/快照发布边界，最后依据证据决定
线程模型；随后明确只规划、不实施产品代码。本节只安排未来实施，不授权本轮改变任何产品实现。
现有S7A-3/4/5/6规则、§3.4.16/17的受限测试桥及历史证据保持；新实时宿主桥须显式区分测试模式。
旧受限验收不证明实时音乐同步，推荐登记不等于字段冻结、功能实施或设备门禁退出。

**依据。** [架构重审报告](../../../stage_reports/stages/stage-07/readiness/2026-10-09-realtime-architecture-review.md)
给出当前调用/owner/阻塞图、RA-01–16反例与基线证据；
[ADR 0046](../../../adr/0046-realtime-playback-coordination.md)选择责任解耦与线程候选；
[实时宿主边界草案](../../../api/realtime-host-boundary.md)登记首用字段职责及TB-01–07待定项。
后三者不替代V2 Spec/ABI、execution profile与Playback/Audio/Presentation的权威合同。

#### 对既有小目标和C78/R78的影响

| 归属 | 必须补足的工作 | 关联首用行/既有边界 |
| --- | --- | --- |
| S7A-7.1 | 校准会话时钟、输入准入与推进顺序、明确H/T/RuntimeFrame；控制、推进/表现采样和恢复边界 | C78-01–04/08；R78-01–05，保留sealed前缀、faulted只读、generation/scope区分 |
| S7A-7.3 | 可控时钟和延迟交付fixture、独立时间oracle、同轨迹完整Replay/Seek验证 | C78-03/08/09；不能用生产推进函数充当oracle |
| S7A-7.4 | Player实际输入、音频服务/渲染调度解耦、热路径Replay整改、快照与资源代数一致 | C78-03/04/07/11；R78-06/07，resolver层域和typed lifetime保持 |
| S7A-7.5、8.1 | 任何新公共边界的ON/OFF、owner、ASCII及static/shared安装消费 | C78-08/10/12；无内部Kernel/Recovery安装，无默认生产新能力 |
| S7A-8.3 | Reference Host同协议六动词加tick，typed clock供给与拒绝矩阵 | C78-04/11；fixture步进保留显式用途，不伪称实时设备模式 |
| S7A-8.4 | 按最终公共差异重审patch/minor与owner/保护/hosted材料 | C78-12；当前0.7.1不预先约束未来API，门禁仍未退出 |
| S7A-7.2、8.2 | 保留已完成source/assembler闭包；新时间profile若影响identity则定向回归 | C78-05/06，R78-08/09沿既有Graph/发布合同；不趁机重写格式 |
| S7A-6.1–6.5关联回归 | 执行状态、journal和owning结果存储整改的完整语义回归 | 完整ReplayEvaluation、archive/cut/H、future pending、lastObservedTick、惰性分支不变 |

RA-02/03/04是真实语义或产品支持范围问题，不作为“普通表示”交给代码自行决定。若选择原始事件
时刻重建、改变碰撞支持或新的推进fence，必须先明确Spec/ABI/profile/identity/稳定诊断修订，列出
被替换文字和影响测试；不因大范围重构建议而默认重开全部S7A-2–6规则。

#### 规划和未来实施顺序

| 步骤 | 必需产物及完成条件 | 后续依赖 |
| --- | --- | --- |
| RT78-0 架构审查 | 实际代码/合同/平台约束、RA反例、复制清单、证据限制；本轮交付报告 | 是设计输入，不是产品修复 |
| RT78-1 边界设计与typed review | 完成TB-01–07，逐字段补owner、单位、捕获/准入时点、profile/identity、控制矩阵与失败码；现有语义和候选修订明确分开 | 时间消费者实施前置；未闭合项目继续标open |
| RT78-2 调度与存储验证设计 | 定义可比较的输入/admission/control轨迹，准备计时/复制/保留内存/队列积压的测量方案；设计fake clock、独立oracle和设备试验 | 不预设线程数、无锁或生产阈值；本轮只保留基线测量 |
| RT78-3 线程模型选择 | 比较ADR0046候选；音频独立服务为优先方向，Playback worker须先通过Prepared/renderer跨域、提交fence与输入采集可行性审查 | 选择需成本及平台证据；当前不冻结三线程为正式实现 |
| RT78-4 后续热路径整改 | 移出每帧完整Replay，处理journal/RuntimeState/公开result复制与retention；完整恢复和故障注入回归 | 不能只把同样的增长成本搬到worker；需另轮实施 |
| RT78-5 后续时钟与发布实施 | 实施已冻结typed bridge；解开判定推进与表现采样频率；资源/快照/控制消息有版本和owner | I78-2/3补充；每个提交可独立验证，保留旧显式测试桥兼容 |
| RT78-6 后续owner调度实施 | 按已选择拓扑创建/析构对象，音频不等GPU；有界可靠输入/控制及可合并frame通道 | 不跨线程使用Prepared，不因队列满丢键，不把新容量默认为生产接受 |
| RT78-7 后续消费者验收 | Headless/Player/Host/安装树、同SHA平台矩阵、真实设备；回填§3.1和C78对应行 | I78-4/5；准确保留未退出项，之后才进入S7A-9最终验收 |

本轮完成RT78-0和RT78-1/2/3的规划文本，不把后续typed冻结、原型测量或线程选择写成已完成。
原有I78-0–5继续是7/8主顺序；上述RT78是其整改子任务，不是新的active计划或Stage7A关闭批次。

#### 验证设计与后续阶段分工

验收区分三类：只改变渲染节奏；已捕获输入延迟交付；输入本身延迟捕获。第一类在同admission/control
前提下比较完整结果；后两类按明确捕获与late-policy合同验收，不能无条件要求与无延迟相同。
100ms/500ms等停顿只作故障注入输入，不能成为生产容忍值。额外覆盖音轨末尾尾判、44.1k/48k转换、
offset重复补偿、Pause/Seek、跨代旧帧、设备欠载、队列满、关闭与分配失败、长历史和owning对象寿命。
GPU/window/audio/实体键盘证据单列，不能用Replay=same代替。

S7A-9.1/9.2收敛最终矩阵，9.3接受代表/最坏内容数值预算，9.4交接/owner接受；本轮I78-6只累计
测量输入。S7C-1扩展CalibrationProfile与设备策略，不能替换canonical来源或承接本轮基本同步缺口。
Stage8消费已验证合同并做发行兼容；Stage12做规模/平台优化，不承担首次修复基础播放失速。
当前状态只回填CURRENT_STATUS，dated报告存证，桌面handoff同步摘要。


### 3.4.19 诊断码去阶段命名规划（2026-10-09）

owner要求全面检查阶段诊断码并采用judgement.input.same_tick_collision等正式名称。
只读子代理审计见[阶段码审计报告](../../../stage_reports/stages/stage-07/readiness/2026-10-09-diagnostic-phase-name-audit.md)。
共67个定义：66个去阶段命名候选、1个未调用占位删除候选；公共13、明确src-only13、其余内部41。
本轮仅登记命名方向和迁移工作，未修改现行码串、合同语义或产品实现。

| 顺序 | 首用修订/实施要求 | 验收边界 |
| --- | --- | --- |
| DN78-0 审计 | 保留逐码映射、定义/消费者/测试/合同，排除历史、算法版本和fixture ID | 本轮已完成审计，未实施 |
| DN78-1 合同 | Spec/ABI/集中码表与execution/Recovery/Replay兼容、VERSIONING逐项证明 | 正式名称不提升公开性，不扩九类别/R编号，不默认接受旧恢复bytes |
| DN78-2 消费者 | source_codes、s7a4动态构造、Playback显式投影、严格恢复验证及工具预期同步 | 不靠阶段前缀决定公开性，保留sourceCode、故障边界和完整结果 |
| DN78-3 验证 | 新码负例、投影、旧owning结果、故障注入和新旧恢复字节/digest、消费者及平台矩阵 | 新SHA证据；历史日志保留原码；门禁缺项准确登记 |

与S7A-7.1/7.5/8.1/8.4及C78-08/12关联；现有实时RT78顺序保持。
命名迁移另批实施，不改变kernel/Fold或重开S7A-2–6判定规则；S7A-9阈值与阶段关闭不进入。
