# Cuexis Documentation Policy

状态：已接受的文档整理政策

更新日期：2026-11-23

<!-- cuexis-meta
id: GUIDE-DOC-POLICY
status: accepted
authority: owns
-->

## 文档角色

每份文档必须拥有一个主要角色：

| 角色 | 允许内容 | 不应承担的内容 |
| --- | --- | --- |
| ADR | 背景、备选方案、决策、影响和接受门禁 | 当前构建结果、完整字段参考、逐次测试日志 |
| Spec | 字段、语义、版本、预算、错误和兼容合同 | 阶段进度、机器环境和一次性验证输出 |
| Plan | 目标、范围、批次、依赖、门禁和交接 | 重新定义已接受字段，复制全部 ADR 正文 |
| Task | 一个独立任务的目标、输入、写域、步骤、验收、证据和停止条件 | 重复维护阶段依赖或擅自改变计划/ADR 合同 |
| Report | 某个时间点的实施、审查和证据 | 把历史快照冒充当前状态 |
| Guide/Policy | 操作步骤、编码规则、依赖和版本维护规则 | 维护产品路线图的第二份副本 |
| Index/Status | 导航和当前摘要 | 复制完整技术合同 |
| API Reference | 已发布 SDK 的入口、生命周期、可观察结果、错误与兼容约定 | 把内部实现类型描述为宿主 API，或复制完整头文件声明 |

`AGENTS.md` 只写路由与硬约束，不复述阶段、版本、预算或能力状态；这些事实由
`docs/MAP.md`、`docs/CURRENT_STATUS.md`、代码与生成页承载。`AGENTS.md` 顶部的
`CUEXIS_STATE` 块是生成物，`check_docs.py` 只校验它的指针与规则片段是否存在。

## 权威顺序

同一事实冲突时，按以下顺序处理：

```text
代码与 schema -> 当前状态页 -> 已接受 ADR -> 生产 Spec -> 当前 Stage Plan -> 最新完成/审查 Report -> 历史材料
```

代码、schema、`cmake/CuexisVersion.cmake` 始终高于文档；文档之间才按上面的顺序裁决。
“当前状态页”只负责当前摘要，不能替代 ADR 或 Spec。候选格式必须同时标记 candidate、提案
或未实现，不能使用“已支持”或“生产格式”。

## 状态字段

新文档顶部至少写明：

```text
状态：active / candidate / future / deferred / completed / historical / superseded / archived
更新日期：YYYY-MM-DD
```

ADR 还要写决策状态；Spec 还要写实现状态；Report 还要写快照日期和后续关闭证据。中文正文
可以保留，但状态值和文件名应使用稳定、可搜索的英文枚举或固定词汇。

## 链接和重复

- 每份文档必须从某个索引或权威文档可达。
- 相对链接必须指向实际文件；移动文件时保留旧路径跳转页至少一个整理周期。
- 一个字段合同只能有一个权威 Spec。
- 摘要不得复制完整表格、完整诊断矩阵或当前阶段结论。
- 历史文档不得删除；应标记 `historical` 或 `superseded`，并链接替代文件。
- **行号锚只能作为带日期的定版证据，不得作为活合同来源。** 活引用一律写章节名或符号名；确需引用具体行时，
  必须写在**带日期的证据记录**里，并同时注明所依据的**文档版本或提交标识 / 快照哈希**，使该行号可被复核到
  某一个定版。理由有实测依据：`engine/judgement/src/source_codes.hpp` 的 13 处行号锚在并行实现线新增注释后
  **已全部漂移 1 行**（令牌仍在被引范围的最后一行），说明行号随文档增删必然失效。

## 目录和命名

稳定入口保持在 `docs/` 根目录：`README.md`、`CURRENT_STATUS.md`、`PROJECT_GUIDE.md`、
`HANDOFF.md`、
`ROADMAP.md` 和本文。根目录不承载格式、阶段计划、阶段报告或 API 正文。其余现行文档按角色归档到
以下目录：

```text
docs/architecture/  Runtime、模块和宿主边界
docs/formats/       Chart、CXC、CXT、动画和表现格式
docs/guides/        构建、编码、依赖和版本指南
docs/adr/           架构决策记录
docs/stage_plans/   阶段计划
docs/stage_reports/ 阶段证据
docs/proposals/     候选与延期设计
docs/examples/      评审和验证样例
docs/archive/       历史材料
docs/api/           已发布 SDK 与内部技术参考
```

提案目录按生命周期继续细分为 `proposals/research/`、`proposals/implementation-input/` 和
`proposals/deferred/`；已并入主路线的旧阶段计划统一放在
`stage_plans/historical-inputs/`，不再混入 `future/` 或 `deferred/`。

阶段计划和阶段报告按阶段或跨阶段专题归档，而不是按生成日期平铺：

```text
docs/stage_plans/active/<stage>/
docs/stage_plans/completed/<stage>/
docs/stage_plans/future/<stage>/
docs/stage_plans/deferred/<stage>/
docs/stage_plans/reviews/<topic>/
docs/stage_plans/historical/<topic>/

docs/stage_reports/stages/<stage>/
docs/stage_reports/reviews/<topic>/
docs/stage_reports/sdk-transition/
```

新的 canonical Markdown 文件名使用小写 kebab-case。阶段目录中的主计划文件命名为 `plan.md`；
带日期的报告使用 `YYYY-MM-DD-topic.md`；ADR 继续使用 `NNNN-short-title.md`。根目录稳定入口和
旧路径兼容页是明确例外，不要求改名。

已启动阶段的任务卡放在 `stage_plans/active/<stage>/tasks/T-xx.md`，使用七段任务模板；任务依赖只在同阶段 `schedule.md` 维护。新 ADR 使用 `docs/templates/adr.md` 起草；未接受前标记为 candidate/none，接受后同步更新决策状态、元数据权威级别及 ADR 索引。

单个文档移动可以保留旧路径兼容短页至少一个整理周期。兼容页只链接 canonical 文档，不复制正文，并标记
`状态：compatibility entry`。但是，批量 stage plan/report 重组不得用大量单页 stub 重新制造平铺目录；
应在相应目录的 `legacy-paths.md` 中把旧逻辑路径以代码文字映射到 canonical 文档。该映射不承诺旧的
逐文件 URL 继续存在。`docs/` 根目录不保留单文件 compatibility entry；其历史路径统一写入
[legacy-paths.md](legacy-paths.md)。

README 只用于稳定入口、顶层文档角色或包含多份需要独立导航的正文集合。单文件目录和由上级索引即可
清楚列出的叶目录不创建 README；上级索引直接链接 canonical 文档。所有 Markdown 仍必须从
[docs/README.md](README.md) 可达。

同一阶段的报告数量较多时，可在`stage_reports/stages/<stage>/`下按用途细分，例如
`readiness/`（准入与基线）、`decisions/`（带日期裁定）、`implementation/`（设计/实施推进）、
`verification/`（验证与审计）、`handoffs/`（交接与规划修订）。阶段README直接列出各类正文，
总报告索引只链接阶段入口；不在总索引复制完整裁定计数和测试矩阵。
这些目录不改变报告的历史角色，现行决策归ADR/Spec、当前范围归plan、当前进度归CURRENT_STATUS。
分类目录不是每个阶段的必建模板；少量报告仍由最近索引直接导航。

写作模板在 [templates/](templates/README.md)：新 plan / 报告复制对应模板，模板中的固定 H2 标题
是 `check_docs.py` 的检查对象。`docs/HANDOFF.md` 是**对话级交接**，记录当前任务、下一步、阻塞与
验证状态，不是阶段权威；active 阶段超过 7 天未更新时 `check_docs_facts.py` 只给警告。

计划分两级：`stage_plans/active/**` 用详细模板（任务看板、入场门禁、验收矩阵、回滚条件）；
`stage_plans/future/**` 只用提纲模板（目标、边界、入口条件、待决问题），启动时再重写为详细计划，
避免提前写下会过期的批次与数值。

`docs/api/` 以发布的 Playback SDK 为首要对象，说明入口、生命周期、线程、资源、帧观察、诊断、
capability 和兼容边界。内部模块资料必须显式标为 internal，不能把 Runtime、World、EnTT、SDL、
OpenGL 或 JSON DOM 写成宿主可依赖的 API。

API 文档使用中文标题、章节和解释性文字；类型名、函数名、枚举值、capability ID 和其他代码标识保持
源码拼写并使用反引号。专题页依次给出元数据、权威头文件、“快速结论”、速查表或标准流程、失败与边界；
索引页先给核心规则，再按任务导航。不得使用完整英文自然语言标题或在各页发明不同的章节结构。

## 元数据约定

现行 Spec、Guide、Index、Status、Plan 和 API Reference 使用：

```text
状态：<stable English value>
更新日期：YYYY-MM-DD
```

ADR 使用其决策日期和决策状态；历史 Report 使用其证据日期或快照日期及后续关闭证据。整理不得把
历史日期改写为当前日期，也不得以统一字段名掩盖原始证据时点。

### 机器可读元数据块

合同、计划与证据文档在 H1 之后带一个 `cuexis-meta` 注释块，供 `tools/verification/gen_docs_map.py`
生成路由页与状态块，避免人肉维护索引：

```text
<!-- cuexis-meta
id: ADR-0027            # 稳定标识：ADR-<编号> / API-<名> / FORMAT-<名> / ARCH-<名> / GUIDE-<名> / PLAN-<路径> / EVIDENCE-<路径>
status: accepted        # 权威状态：current / active / accepted / candidate / future / deferred / completed / historical / evidence / unverified
authority: owns         # owns（拥有该主题）/ summarizes（摘要）/ references（引用）/ index / none（证据）
-->
```

- `status` 表达“是否还权威”，`authority` 表达“是否拥有该主题”。证据文档固定为
  `status: evidence` + `authority: none`；索引为 `authority: index`。
- 文件名带 `YYYY-MM-DD` 的证据报告额外写 `date`，取文件名中的日期，不改写正文时点。
- `docs/CURRENT_STATUS.md` 的元数据额外带 `current_stage`，它是“当前阶段”的唯一机器可读来源。
- 块由脚本批量补齐，正文一字不改；新增文档必须自行带上该块，否则 MAP 中显示 `unverified`。

## 脚本边界

运行时脚本和逐帧脚本回调无限期延后。任何文档不得为它们预留字段、extension、capability、
字节码或隐式执行入口。离线创作生成器若未来进入讨论，必须作为单独的 authoring tool 合同，
不能混入 CXT、CXC 或 Playback 文档。

## 自动检查

文档移动、归档、阶段更名或候选示例修改后运行：

```powershell
python tools/check_docs.py
```

检查器验证 Markdown 相对链接、单一 H1、从 `docs/README.md` 可达、目录索引和完整阶段索引、
Stage Chart Format Update 名称、运行时脚本边界、Stage 4-12 计划的目标/验收/归档来源，以及
候选 JSON/CXT 的解析、CXC entry 顺序和 CXT import 一致性。

生成物与事实检查（修改任何 `docs/` 文档后运行）：

```powershell
python -B tools/verification/gen_docs_map.py          # 重新生成 docs/MAP.md 与 AGENTS.md 状态块
python -B tools/verification/gen_docs_map.py --check   # 只校验是否过期
python -B tools/verification/check_docs_facts.py       # 校验生成物新鲜度与版本字面量漂移
```

- `docs/MAP.md` 与 `AGENTS.md` 的 `CUEXIS_STATE_BEGIN/END` 块是**生成物**，不得手改；`--check` 过期即失败。
- `check_docs_facts.py` 把 `docs/` 里的构建版本与 SDK API 字面量与 `cmake/CuexisVersion.cmake` 对比；
  历史叙述行（含“历史/归档/baseline/此前”等标记）豁免，其余差异作为警告列出。
- 证据目录（`docs/stage_reports/**`、`docs/archive/**`）不参与版本字面量检查：它们是当时的证据，不是当前事实。
